/* Splunk Web prepends i18n_register(...) to app scripts; this frame has no i18n library. */
function i18n_register() {}
'use strict';
/* ============================================================
   Helpers
   ============================================================ */
const $ = (s, r = document) => r.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const isObj = v => v !== null && typeof v === 'object' && !Array.isArray(v);
const fmt = v => v === undefined ? '' : (typeof v === 'string' ? v : JSON.stringify(v));
const uniq = a => [...new Set(a)];
const plural = (n, s, p) => `${n} ${n === 1 ? s : (p || s + 's')}`;

/* ============================================================
   Running inside the Splunk app: libraries from the app, and loading straight from Splunk
   The app's dashboard embeds this page as
     inventory.html?splunkd=/<locale>/splunkd/__raw&app=<app>&page=/<locale>/app/<app>/inventory
   Only GET requests are made, with the viewer's own Splunk session and permissions.
   ============================================================ */
const SPLUNK = (() => {
  try {
    const q = new URLSearchParams(location.search);
    const d = q.get('splunkd') || '', page = q.get('page') || '';
    if (!/^\/[\w\-./]*splunkd\/__raw$/.test(d)) return null;
    return { splunkd: d, app: (q.get('app') || '').replace(/[^\w.\-]/g, ''), page: /^\/[\w\-./]*$/.test(page) ? page : '' };
  } catch { return null; }
})();
// Library location: inside the app from its own folder (no outside connections), otherwise from jsDelivr.
const libUrl = (cdn, local) => SPLUNK ? local : cdn;
async function splunkGet(path, params = {}) {
  const q = new URLSearchParams({ output_mode: 'json', count: '0' });
  for (const [k, v] of Object.entries(params)) for (const x of [].concat(v)) q.append(k, x);
  const r = await fetch(SPLUNK.splunkd + path + '?' + q.toString(), { credentials: 'same-origin', headers: { 'X-Requested-With': 'XMLHttpRequest', Accept: 'application/json' } });
  if (!r.ok) throw new Error(r.status === 403 ? 'permission denied' : r.status === 404 ? 'not found' : `HTTP ${r.status}`);
  return r.json();
}
const splunkState = { apps: [], app: '', views: [], selected: new Set(), loading: false, error: '' };
async function initSplunkLoader() {
  if (!SPLUNK) return;
  $('#splunk-loader').hidden = false;
  splunkState.loading = true; renderSplunkLoader();
  try {
    const r = await splunkGet('/services/apps/local', { f: ['label', 'visible'] });
    splunkState.apps = (r.entry || []).filter(e => e.content?.visible !== false && e.content?.visible !== '0')
      .map(e => ({ name: e.name, label: e.content?.label || e.name })).sort((a, b) => a.label.localeCompare(b.label));
    const want = splunkState.apps.some(a => a.name === SPLUNK.app) && SPLUNK.app !== 'dashboard_inventory' ? SPLUNK.app : 'search';
    splunkState.app = splunkState.apps.some(a => a.name === want) ? want : splunkState.apps[0]?.name || '';
    await loadSplunkViews();
  } catch (e) { splunkState.loading = false; splunkState.error = `Couldn't list the apps in Splunk (${e.message}). You can still paste or choose a dashboard below.`; renderSplunkLoader(); }
}
async function loadSplunkViews() {
  splunkState.loading = true; splunkState.error = ''; splunkState.views = []; splunkState.selected.clear(); renderSplunkLoader();
  try {
    const app = splunkState.app;
    const r = await splunkGet(`/servicesNS/-/${encodeURIComponent(app)}/data/ui/views`, { f: ['label', 'version', 'isDashboard', 'isVisible'] });
    splunkState.views = (r.entry || [])
      .filter(e => e.acl?.app === app && e.content?.isDashboard !== false && e.content?.isDashboard !== '0' && !(app === 'dashboard_inventory' && e.name === 'inventory'))
      .map(e => ({ name: e.name, label: e.content?.label || e.name, kind: String(e.content?.version) === '2' ? 'Studio' : 'Classic', sharing: e.acl?.sharing || '' }))
      .sort((a, b) => a.label.localeCompare(b.label));
  } catch (e) { splunkState.error = `Couldn't list the dashboards in this app (${e.message}).`; }
  splunkState.loading = false; renderSplunkLoader();
}
function renderSplunkLoader() {
  const box = $('#splunk-loader');
  if (!box) return;
  const S = splunkState, n = S.selected.size;
  box.innerHTML = `<h2>Load from Splunk</h2>
    <p class="small muted" style="margin-top:0">Pick dashboards from any app you can see. The page only reads them; nothing in Splunk is changed.</p>
    <div class="loader-actions">
      <label>App <select id="sp-app" ${S.loading && !S.apps.length ? 'disabled' : ''}>${S.apps.map(a => `<option value="${esc(a.name)}" ${a.name === S.app ? 'selected' : ''}>${esc(a.label)}</option>`).join('')}</select></label>
      <input class="search" id="sp-filter" type="search" placeholder="Filter dashboards…" aria-label="Filter dashboards">
    </div>
    ${S.error ? `<div class="error">${esc(S.error)}</div>` : ''}
    ${S.loading ? '<p class="muted">Loading…</p>' : S.views.length ? `<div class="sp-list" role="group" aria-label="Dashboards">${S.views.map(v => `<label class="sp-item"><input type="checkbox" data-spview="${esc(v.name)}" ${S.selected.has(v.name) ? 'checked' : ''}> <span><b>${esc(v.label)}</b> <span class="muted small">${esc(v.name)}${v.kind ? ' · ' + v.kind : ''}${v.sharing ? ' · ' + esc(v.sharing) : ''}</span></span></label>`).join('')}</div>` : (S.error ? '' : '<p class="muted">There are no dashboards in this app that you can see.</p>')}
    <label class="small" style="display:block;margin:8px 0"><input type="checkbox" id="sp-config" checked> Also load the macros, saved searches and data models visible in this app, so the page can look inside them</label>
    <div class="loader-actions">
      <button class="btn primary" id="sp-load" ${n ? '' : 'disabled'}>${n ? `Load ${plural(n, 'dashboard')}` : 'Choose dashboards to load'}</button>
      ${S.views.length ? '<button class="btn small" id="sp-all">Select all shown</button><button class="btn small" id="sp-none">Clear</button>' : ''}
    </div>`;
}
const confLine = (k, v) => `${k} = ${String(v ?? '').replace(/\r?\n/g, ' \\\n')}`;
// The app's macros and saved searches as .conf text, and its data models as JSON, for the expansion features.
async function splunkConfig(app) {
  const ns = `/servicesNS/-/${encodeURIComponent(app)}`;
  const [mac, sav, dm] = await Promise.allSettled([
    splunkGet(ns + '/configs/conf-macros', { f: ['definition', 'args', 'iseval'] }), // Splunk Web does not pass /admin/ paths
    splunkGet(ns + '/saved/searches', { f: ['search', 'dispatch.earliest_time', 'dispatch.latest_time', 'cron_schedule'] }),
    splunkGet(ns + '/datamodel/model', { f: ['eai:data'] }),
  ]);
  const notes = [];
  let conf = '';
  if (mac.status === 'fulfilled') for (const e of mac.value.entry || []) {
    const c = e.content || {};
    conf += `[${e.name}]\n${c.args ? confLine('args', c.args) + '\n' : ''}${confLine('definition', c.definition)}\n${/^(1|true)$/i.test(String(c.iseval)) ? 'iseval = 1\n' : ''}\n`;
  } else notes.push('macros: ' + mac.reason.message);
  if (sav.status === 'fulfilled') for (const e of sav.value.entry || []) {
    const c = e.content || {};
    conf += `[${e.name}]\n${confLine('search', c.search)}\n${c['dispatch.earliest_time'] ? confLine('dispatch.earliest_time', c['dispatch.earliest_time']) + '\n' : ''}${c['dispatch.latest_time'] ? confLine('dispatch.latest_time', c['dispatch.latest_time']) + '\n' : ''}${c.cron_schedule ? confLine('cron_schedule', c.cron_schedule) + '\n' : ''}\n`;
  } else notes.push('saved searches: ' + sav.reason.message);
  const dmText = dm.status === 'fulfilled' ? JSON.stringify({ entry: (dm.value.entry || []).map(e => ({ content: { 'eai:data': e.content?.['eai:data'] } })) }) : '';
  if (dm.status !== 'fulfilled') notes.push('data models: ' + dm.reason.message);
  return { conf, dm: dmText, notes };
}
async function loadFromSplunk() {
  const S = splunkState, app = S.app, names = S.views.map(v => v.name).filter(n => S.selected.has(n));
  if (!names.length) return;
  const btn = $('#sp-load'); if (btn) { btn.disabled = true; btn.textContent = 'Loading…'; }
  const errors = [];
  const files = (await Promise.all(names.map(async name => {
    try {
      const r = await splunkGet(`/servicesNS/-/${encodeURIComponent(app)}/data/ui/views/${encodeURIComponent(name)}`, { f: ['eai:data'] });
      const text = r.entry?.[0]?.content?.['eai:data'];
      if (!text) throw new Error('no source returned');
      return { name, text };
    } catch (e) { errors.push(`${name}: ${e.message}`); return null; }
  }))).filter(Boolean);
  if ($('#sp-config')?.checked) {
    const c = await splunkConfig(app);
    $('#ldr-conf').value = c.conf; $('#ldr-dm').value = c.dm;
    applyConfig(c.conf, c.dm);
    if (c.notes.length) errors.push('Some configuration could not be read (' + c.notes.join('; ') + '). Expansion uses what was read.');
  } else applyConfig($('#ldr-conf').value, $('#ldr-dm').value);
  if (btn) { btn.disabled = false; btn.textContent = `Load ${plural(names.length, 'dashboard')}`; }
  if (!files.length) { const err = $('#load-error'); err.textContent = errors.join('\n') || 'Nothing was loaded.'; err.hidden = false; return; }
  loadDashboards(files);
  if (errors.length) { LOAD_ERRORS.push(...errors); toast(errors.join(' '), 10000); if (view === 'app') render(); }
}


const KINDS = {
  dashboard: { label: 'Dashboard', plural: 'Dashboard' },
  tab:       { label: 'Tab / canvas', plural: 'Tabs' },
  input:     { label: 'Input', plural: 'Inputs' },
  defaults:  { label: 'Defaults', plural: 'Defaults' },
  token:     { label: 'Token', plural: 'Tokens' },
  condition: { label: 'Visibility condition', plural: 'Conditions' },
  ds:        { label: 'Data source', plural: 'Data sources' },
  viz:       { label: 'Visualization', plural: 'Visualizations' },
  index:     { label: 'Index', plural: 'Indexes' },
  sourcetype:{ label: 'Sourcetype', plural: 'Sourcetypes' },
  lookup:    { label: 'Lookup', plural: 'Lookups' },
  datamodel: { label: 'Data model', plural: 'Data models' },
  macro:     { label: 'Macro', plural: 'Macros' },
  command:   { label: 'SPL command', plural: 'Commands' },
};
const DS_TYPES = {
  'ds.search': 'Search', 'ds.chain': 'Chain search', 'ds.savedSearch': 'Saved search (report)',
  'ds.test': 'Test data', 'ds.sim': 'Simulated data'
};
const dsTypeLabel = t => DS_TYPES[t] || t || 'unknown';
const shortType = t => String(t || '').replace(/^(splunk|input|ds|viz|abslayout)\./, '');

// Relationship types. Edges always point in data-flow direction (from → to).
const REL = {
  'sets':           { fwd: 'Sets token',                    rev: 'Set by input',                 group: 'token' },
  'drilldown-sets': { fwd: 'Sets token on click',           rev: 'Set by drilldown on',          group: 'token' },
  'default':        { fwd: 'Sets default value of',         rev: 'Default value from',           group: 'token' },
  'smart-source':   { fwd: 'Provides smart-source token',   rev: 'Provided by smart source',     group: 'token' },
  'uses-token':     { fwd: 'Used by',                       rev: 'Uses token',                   group: 'token' },
  'extends':        { fwd: 'Extended by chain search',      rev: 'Extends base search',          group: 'data' },
  'feeds':          { fwd: 'Feeds visualization',           rev: 'Gets data from',               group: 'data' },
  'populates':      { fwd: 'Populates options of input',    rev: 'Options populated by',         group: 'data' },
  'inherits':       { fwd: 'Applies defaults to',           rev: 'Inherits defaults from',       group: 'data' },
  'visibility':     { fwd: 'Controls visibility of',        rev: 'Visibility controlled by',     group: 'vis' },
  'searches':       { fwd: 'Searched by',                   rev: 'Reads from',                   group: 'data' },
  'lookup-read':    { fwd: 'Read by',                       rev: 'Reads lookup',                 group: 'data' },
  'lookup-write':   { fwd: 'Writes lookup',                 rev: 'Written by',                   group: 'data' },
  'datamodel-read': { fwd: 'Read by',                       rev: 'Reads data model',             group: 'data' },
  'macro-used':     { fwd: 'Used by',                       rev: 'Uses macro',                   group: 'data' },
  'command-used':   { fwd: 'Used by',                       rev: 'Uses command',                 group: 'spl' },
  'contains':       { fwd: 'Placed on',                     rev: 'Contains',                     group: 'layout' },
};

/* ============================================================
   Parsing the source
   ============================================================ */
// Where the JSON value starting at `start` ends (string-aware bracket matching); -1 if it never closes.
function jsonValueEnd(t, start) {
  let depth = 0, inStr = false;
  for (let i = start; i < t.length; i++) {
    const c = t[i];
    if (inStr) { if (c === '\\') i++; else if (c === '"') inStr = false; continue; }
    if (c === '"') inStr = true;
    else if (c === '{' || c === '[') depth++;
    else if (c === '}' || c === ']') { depth--; if (depth === 0) return i + 1; }
  }
  return -1;
}
// Remove // and /* */ comments and trailing commas, outside strings.
function stripJsonExtras(t) {
  let out = '', inStr = false, comments = 0, commas = 0;
  for (let i = 0; i < t.length; i++) {
    const c = t[i];
    if (inStr) { out += c; if (c === '\\') out += t[++i] ?? ''; else if (c === '"') inStr = false; continue; }
    if (c === '"') { inStr = true; out += c; continue; }
    if (c === '/' && t[i + 1] === '/') { while (i < t.length && t[i] !== '\n') i++; out += '\n'; comments++; continue; }
    if (c === '/' && t[i + 1] === '*') { const e = t.indexOf('*/', i + 2); i = e < 0 ? t.length : e + 1; comments++; continue; }
    if (c === ',') { let j = i + 1; while (/\s/.test(t[j] || '')) j++; if (t[j] === '}' || t[j] === ']') { commas++; continue; } }
    out += c;
  }
  return { text: out, comments, commas };
}
// Remove a byte-order mark and Markdown code fences left over from copying.
function cleanText(text, repairs) {
  let t = String(text ?? '');
  if (t.charCodeAt(0) === 0xFEFF) { t = t.slice(1); repairs.push('Removed a byte-order mark at the start.'); }
  t = t.trim();
  const fenced = t.match(/^```[\w-]*[ \t]*\r?\n([\s\S]*?)\r?\n?[ \t]*```$/);
  if (fenced) { t = fenced[1].trim(); repairs.push('Removed the Markdown code fence (```) around the definition.'); }
  else {
    if (/^```[\w-]*[ \t]*\r?\n/.test(t)) { t = t.replace(/^```[\w-]*[ \t]*\r?\n/, '').trim(); repairs.push('Removed a stray Markdown code fence (```) at the start.'); }
    if (/```$/.test(t)) { t = t.replace(/\s*```$/, '').trim(); repairs.push('Removed a stray Markdown code fence (```) at the end.'); }
  }
  return t;
}
// JSON.parse, then progressively more forgiving: comments, trailing commas, extra text, curly quotes.
function lenientJson(t, repairs) {
  let firstErr;
  try { return JSON.parse(t); } catch (e) { firstErr = e; }
  let cur = t; const notes = [];
  const s = stripJsonExtras(cur);
  if (s.comments || s.commas) {
    cur = s.text;
    if (s.comments) notes.push(`Removed ${plural(s.comments, 'comment')}.`);
    if (s.commas) notes.push(`Removed ${plural(s.commas, 'trailing comma')}.`);
  }
  try { const v = JSON.parse(cur); repairs.push(...notes); return v; } catch { /* keep trying */ }
  const start = cur.search(/[{[]/), end = start >= 0 ? jsonValueEnd(cur, start) : -1;
  if (end > 0 && cur.slice(end).trim()) {
    try {
      const v = JSON.parse(cur.slice(start, end));
      const extra = cur.slice(end).trim();
      repairs.push(...notes, `Ignored extra text after the closing bracket: "${extra.length > 40 ? extra.slice(0, 40) + '…' : extra}".`);
      return v;
    } catch { /* keep trying */ }
  }
  if (/[“”]/.test(cur)) {
    try { const v = JSON.parse(cur.replace(/[“”]/g, '"')); repairs.push(...notes, 'Replaced curly quotes (“ ”) with straight quotes.'); return v; } catch { /* give up */ }
  }
  throw new Error('The JSON could not be parsed: ' + firstErr.message);
}
// Returns every dashboard found in one pasted text or file: [{ def, format, name, repairs, notes, xmlText, classic } | { error, name }]
function parseSources(text, name = '') {
  const repairs = [];
  const t = cleanText(text, repairs);
  if (!t) throw new Error('There is nothing to analyze. Paste a dashboard definition or choose a file.');
  let list;
  if (t[0] === '{' || t[0] === '[') list = fromObject(lenientJson(t, repairs), name);
  else if (t[0] === '<') list = [fromXml(t, name)];
  else throw new Error('Unrecognised format. Paste Dashboard Studio JSON, dashboard XML (Studio or Classic), or a REST API response.');
  for (const s of list) if (!s.error) s.repairs = [...repairs, ...(s.repairs || [])];
  return list;
}
function fromObject(obj, name) {
  if (Array.isArray(obj?.entry)) {
    const out = [];
    for (const entry of obj.entry) {
      const data = entry?.content?.['eai:data'];
      if (typeof data !== 'string' || !data.trim()) continue;
      try { const r = fromXml(data.trim(), entry.name || name); r.format = 'REST API, ' + r.format; out.push(r); }
      catch (e) { out.push({ error: e.message, name: entry.name || name }); }
    }
    if (!out.length) throw new Error('The REST response has no dashboards (no entry with content["eai:data"]).');
    return out;
  }
  if (Array.isArray(obj)) return obj.flatMap((d, i) => fromObject(d, `${name || 'item'} #${i + 1}`));
  if (isObj(obj) && (obj.visualizations || obj.dataSources || obj.layout || obj.inputs)) return [{ def: obj, format: 'Dashboard Studio JSON', name }];
  throw new Error('This JSON does not look like a Dashboard Studio definition: it has no visualizations, dataSources, inputs or layout.');
}
function fromXml(text, name = '') {
  const doc = new DOMParser().parseFromString(text, 'application/xml');
  if (doc.getElementsByTagName('parsererror').length) throw new Error('The XML could not be parsed. Check that you copied the whole file.');
  const root = doc.documentElement;
  const child = n => [...root.children].find(c => c.nodeName.toLowerCase() === n);
  const defEl = child('definition') || doc.getElementsByTagName('definition')[0];
  if (!defEl) {
    if (/^(dashboard|form)$/i.test(root.nodeName)) return { ...convertClassic(root, name), xmlText: text };
    throw new Error('No <definition> block was found in the XML.');
  }
  const repairs = [];
  let def;
  try { def = lenientJson(cleanText(defEl.textContent, repairs), repairs); }
  catch (e) { throw new Error('The <definition> block is not valid JSON: ' + e.message.replace(/^The JSON could not be parsed: /, '')); }
  return {
    def, name, repairs, xmlText: text,
    format: 'Dashboard XML (version ' + (root.getAttribute('version') || '?') + ')',
    xmlLabel: child('label')?.textContent || '', xmlDescription: child('description')?.textContent || ''
  };
}

/* ---------- Classic Simple XML → Studio model ---------- */
// Maps searches, inputs, panels, drilldowns and depends/rejects to their Studio equivalents so the rest of
// the page can analyse a Classic dashboard. Positions are approximate: each row is split evenly.
function convertClassic(root, name) {
  const kids = (el, ...names) => el ? [...el.children].filter(c => names.includes(c.nodeName.toLowerCase())) : [];
  const first = (el, n) => kids(el, n)[0];
  const txt = el => (el?.textContent ?? '').trim();
  const def = {
    title: txt(first(root, 'label')) || name || 'Untitled dashboard', description: txt(first(root, 'description')),
    inputs: {}, dataSources: {}, visualizations: {}, defaults: { tokens: { default: {} } }, expressions: { conditions: {} },
    layout: { type: 'grid', options: {}, structure: [], globalInputs: [] }
  };
  const notes = ['Converted from a Classic Simple XML dashboard. Searches, inputs, panels, drilldowns and depends/rejects rules are mapped to their Dashboard Studio equivalents. Panel positions are approximate: each row is split evenly.'];
  let seq = 0;
  const nid = p => `${p}_${++seq}`;
  const setsOf = el => kids(el, 'set', 'eval', 'unset').map(s => ({ token: s.getAttribute('token'), value: txt(s), op: s.nodeName.toLowerCase() }))
    .filter(s => s.token).concat(kids(el, 'condition').flatMap(c => setsOf(c)));
  const condKeys = new Map();
  const visOf = (...els) => {
    const dep = [], rej = [];
    for (const el of els) {
      if (!el) continue;
      for (const [attr, list] of [['depends', dep], ['rejects', rej]]) {
        const v = el.getAttribute(attr);
        if (v) list.push(...v.split(',').map(s => s.trim().replace(/^\$|\$$/g, '')).filter(Boolean));
      }
    }
    if (!dep.length && !rej.length) return undefined;
    const key = dep.join(',') + '|' + rej.join(',');
    if (!condKeys.has(key)) {
      const id = nid('cond');
      condKeys.set(key, id);
      const parts = [];
      if (dep.length) parts.push('depends=' + dep.map(t => '$' + t + '$').join(','));
      if (rej.length) parts.push('rejects=' + rej.map(t => '$' + t + '$').join(','));
      def.expressions.conditions[id] = { name: parts.join(' '), value: parts.join(' '), _classic: { depends: dep, rejects: rej } };
    }
    return { visibility: { showConditions: [condKeys.get(key)] } };
  };
  function addSearch(sEl, hint) {
    const sid = sEl.getAttribute('id') || nid('search');
    const qp = {};
    for (const k of ['earliest', 'latest', 'refresh']) { const v = txt(first(sEl, k)); if (v) qp[k] = v; }
    const base = sEl.getAttribute('base'), ref = sEl.getAttribute('ref');
    const q = txt(first(sEl, 'query'));
    let d;
    if (ref) d = { type: 'ds.savedSearch', name: hint || ref, options: { ref } };
    else if (base) d = { type: 'ds.chain', name: hint || sid, options: { extend: base, query: q && !/^\s*\|/.test(q) ? '| ' + q : q } };
    else d = { type: 'ds.search', name: hint || sid, options: { query: q } };
    if (sEl.getAttribute('app')) d.options.app = sEl.getAttribute('app');
    if (Object.keys(qp).length) d.options.queryParameters = qp;
    const sets = ['done', 'progress', 'finalized', 'preview', 'cancelled', 'error', 'fail']
      .flatMap(h => kids(sEl, h).flatMap(el => setsOf(el).filter(s => s.op !== 'unset').map(s => ({ ...s, when: h }))));
    if (sets.length) d._classicSets = sets;
    def.dataSources[sid] = d;
    return sid;
  }
  for (const s of kids(root, 'search')) addSearch(s);
  const init = first(root, 'init');
  if (init) for (const s of setsOf(init)) if (s.op !== 'unset') def.defaults.tokens.default[s.token] = { value: s.value };
  const ITYPE = { dropdown: 'input.dropdown', multiselect: 'input.multiselect', time: 'input.timerange', text: 'input.text', radio: 'input.radio', checkbox: 'input.checkbox', link: 'input.radio' };
  function addInput(iEl) {
    const t = (iEl.getAttribute('type') || 'text').toLowerCase();
    const id = iEl.getAttribute('id') || nid('input');
    const o = {};
    if (iEl.getAttribute('token')) o.token = iEl.getAttribute('token');
    const dEl = first(iEl, 'default') || first(iEl, 'initialvalue');
    if (t === 'time') { if (dEl) o.defaultValue = `${txt(first(dEl, 'earliest'))},${txt(first(dEl, 'latest'))}`; }
    else if (dEl) { const v = txt(dEl); o.defaultValue = (t === 'multiselect' || t === 'checkbox') ? v.split(',').map(x => x.trim()) : v; }
    const choices = kids(iEl, 'choice').map(c => ({ label: txt(c), value: c.getAttribute('value') ?? txt(c) }));
    if (choices.length) o.items = choices;
    for (const [tag, key] of [['prefix', 'prefix'], ['suffix', 'suffix'], ['valueprefix', 'valuePrefix'], ['valuesuffix', 'valueSuffix'], ['delimiter', 'delimiter'], ['fieldforlabel', 'fieldForLabel'], ['fieldforvalue', 'fieldForValue']]) {
      const el = first(iEl, tag);
      if (el) o[key] = el.textContent;
    }
    const d = { type: ITYPE[t] || 'input.' + t, title: txt(first(iEl, 'label')) || o.token || id, options: o };
    const sEl = first(iEl, 'search');
    if (sEl) d.dataSources = { primary: addSearch(sEl, (d.title || id) + ' options') };
    const change = first(iEl, 'change');
    if (change) { const s = setsOf(change).filter(x => x.op !== 'unset'); if (s.length) d._classicSets = s.map(x => ({ ...x, when: 'change' })); }
    const vis = visOf(iEl);
    if (vis) d.containerOptions = vis;
    def.inputs[id] = d;
    return id;
  }
  for (const fs of kids(root, 'fieldset')) for (const i of kids(fs, 'input')) def.layout.globalInputs.push(addInput(i));
  const VTYPE = { table: 'splunk.table', single: 'splunk.singlevalue', event: 'splunk.events', map: 'splunk.map', html: 'splunk.markdown' };
  const CHART = { radialGauge: 'splunk.singlevalueradial', fillerGauge: 'splunk.fillergauge', markerGauge: 'splunk.markergauge' };
  const htmlText = el => [...el.childNodes].map(n => n.nodeType === 3 ? n.textContent
    : /^h[1-6]$/i.test(n.nodeName) ? '\n### ' + n.textContent.trim() + '\n'
    : n.textContent + (/^(p|div|li|br|ul|ol|table|tr)$/i.test(n.nodeName) ? '\n' : '')).join('').replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
  let y = 0;
  for (const row of kids(root, 'row')) {
    let panels = kids(row, 'panel');
    if (!panels.length) panels = [row]; // very old dashboards put elements straight into a row
    const w = Math.floor(1200 / panels.length);
    let rowH = 0;
    panels.forEach((p, pi) => {
      const x = pi * w, pw = pi === panels.length - 1 ? 1200 - x : w;
      let py = y;
      const pTitle = p === row ? '' : txt(first(p, 'title'));
      const els = kids(p, 'chart', 'table', 'single', 'event', 'map', 'html', 'viz');
      for (const i of kids(p, 'input')) {
        def.layout.structure.push({ item: addInput(i), type: 'input', position: { x, y: py, w: pw, h: 80 } });
        py += 80;
      }
      for (const el of els) {
        const tag = el.nodeName.toLowerCase();
        const id = el.getAttribute('id') || nid('viz');
        const opts = {};
        for (const op of kids(el, 'option')) opts[op.getAttribute('name')] = txt(op);
        let type = VTYPE[tag];
        if (tag === 'chart') { const c = opts['charting.chart'] || 'column'; type = CHART[c] || 'splunk.' + c; }
        if (tag === 'viz') type = 'splunk.' + String(el.getAttribute('type') || 'viz').split('.').pop();
        const v = { type, title: txt(first(el, 'title')) || (els.length === 1 ? pTitle : '') };
        if (tag === 'html') v.options = { markdown: htmlText(el) };
        else if (Object.keys(opts).length) v.options = { classicOptions: opts };
        const sEl = first(el, 'search');
        if (sEl) v.dataSources = { primary: addSearch(sEl, v.title || id) };
        const dd = first(el, 'drilldown');
        if (dd) {
          const all = setsOf(dd), handlers = [];
          const sets = all.filter(s => s.op !== 'unset');
          if (sets.length) handlers.push({
            type: 'drilldown.setToken', options: {
              tokens: sets.map(s => {
                const m = s.value.match(/^\$((?:row|click)\.[^$]+)\$$/);
                return m ? { token: s.token, key: m[1].startsWith('row.') ? m[1] + '.value' : m[1] } : { token: s.token, value: s.value };
              })
            }
          });
          const uns = all.filter(s => s.op === 'unset');
          if (uns.length) handlers.push({ type: 'drilldown.unsetToken', options: { tokens: uns.map(s => ({ token: s.token })) } });
          for (const l of [...dd.getElementsByTagName('link')]) handlers.push({ type: 'drilldown.customUrl', options: { url: txt(l), newTab: l.getAttribute('target') === '_blank' } });
          if (handlers.length) v.eventHandlers = handlers;
        }
        const vis = visOf(row, p === row ? null : p, el);
        if (vis) v.containerOptions = vis;
        def.visualizations[id] = v;
        const h = tag === 'single' ? 150 : tag === 'html' ? 140 : 300;
        def.layout.structure.push({ item: id, type: 'block', position: { x, y: py, w: pw, h } });
        py += h;
      }
      rowH = Math.max(rowH, py - y);
    });
    y += rowH;
  }
  if (!Object.keys(def.defaults.tokens.default).length) delete def.defaults;
  if (!Object.keys(def.expressions.conditions).length) delete def.expressions;
  return { def, name, notes, repairs: [], classic: true, format: 'Classic Simple XML (' + root.nodeName.toLowerCase() + '), converted to the Studio model' };
}
// Internal fields added by the Classic converter; removed when a definition is exported.
function stripInternal(o) {
  if (Array.isArray(o)) o.forEach(stripInternal);
  else if (isObj(o)) for (const k of Object.keys(o)) { if (k.startsWith('_classic')) delete o[k]; else stripInternal(o[k]); }
  return o;
}

/* ============================================================
   Token scanning
   ============================================================ */
// Matches, in order: an escaped "$$"; a smart-source token "$<ds name>:result.field$" / "$<ds name>:job.prop$"
// (the data source name may contain spaces); or a normal token "$name$" with optional |s |h |u |n filters.
const TOKEN_RE = /\$\$|\$([^$\n:"]{1,120}):((?:result|job)\.[\w.\-]+)((?:\|[a-z]+)*)\$|\$([A-Za-z0-9_][\w.:\-]*)((?:\|[a-z]+)*)\$/gi;
function walk(v, path, cb) {
  if (typeof v === 'string') cb(v, path);
  else if (Array.isArray(v)) v.forEach((x, i) => walk(x, `${path}[${i}]`, cb));
  else if (isObj(v)) for (const [k, x] of Object.entries(v)) walk(x, path ? `${path}.${k}` : k, cb);
}
function scanTokens(obj, basePath = '') {
  const out = [];
  walk(obj, basePath, (str, path) => {
    TOKEN_RE.lastIndex = 0;
    let m;
    while ((m = TOKEN_RE.exec(str))) {
      if (m[0] === '$$') continue;
      if (m[2]) out.push({ path, raw: m[0], smart: { ds: m[1].trim(), prop: m[2] }, filters: m[3] || '' });
      else out.push({ path, raw: m[0], name: m[4], filters: m[5] || '' });
    }
  });
  return out;
}
function getPath(obj, path) {
  if (!path) return obj;
  let cur = obj;
  for (const k of path.replace(/\[(\d+)\]/g, '.$1').split('.')) {
    if (cur == null || typeof cur !== 'object') return undefined;
    cur = cur[k];
  }
  return cur;
}
// Tokens Splunk provides inside drilldown handlers (row.<field>.value, click.value, …).
const DRILL_BUILTIN = /^(row|click|trellis)(\.|$)|^(name|value|name2|value2|earliest|latest)$/;

/* ============================================================
   Indexes and sourcetypes in SPL
   ============================================================ */
// Reads index / sourcetype terms from a query: field=value, field::value, field!=value,
// NOT field=value and field IN (a, b). Values may be quoted, wildcarded or tokens.
// Also notes macros, data models, lookups and REST calls, which can hide the real source.
function extractSources(q) {
  const out = { index: [], sourcetype: [], other: [], lookups: [], macros: [], datamodels: [], commands: [] };
  if (!q) return out;
  q = q.replace(/```[\s\S]*?```/g, ' ');
  const add = (field, raw, excluded) => {
    const value = String(raw).trim().replace(/^(["'])(.*)\1$/, '$2');
    if (!value) return;
    const list = out[field.toLowerCase()];
    if (!list.some(x => x.value === value && x.excluded === excluded)) list.push({ value, excluded });
  };
  const negated = end => /\bNOT\s*$/i.test(q.slice(0, end));
  let m;
  const FIELD = /(^|[^\w.])(index|sourcetype)\s*(!=|=|::)\s*("[^"]*"|'[^']*'|\$[^$\s]+\$|[^\s()|,\]]+)/gi;
  // index= inside | collect / mcollect / meventcollect / tscollect is where results are written, not read.
  const writeCmd = end => (q.slice(0, end).match(/(?:^|\|)\s*(collect|mcollect|meventcollect|tscollect)\b[^|]*$/i) || [])[1];
  while ((m = FIELD.exec(q))) {
    const w = writeCmd(m.index + m[1].length);
    if (w) { const v = 'writes to ' + m[2] + ' ' + m[4].replace(/^["']|["']$/g, '') + ' (' + w + ')'; if (!out.other.includes(v)) out.other.push(v); continue; }
    add(m[2], m[4], m[3] === '!=' || negated(m.index + m[1].length));
  }
  const IN = /(^|[^\w.])(index|sourcetype)\s+IN\s*\(([^)]*)\)/gi;
  while ((m = IN.exec(q))) { const neg = negated(m.index + m[1].length); for (const v of m[3].match(/"[^"]*"|'[^']*'|[^\s,]+/g) || []) add(m[2], v, neg); }
  const other = (re, label) => { re.lastIndex = 0; while ((m = re.exec(q))) { const v = label(m); if (!out.other.includes(v)) out.other.push(v); } };
  out.lookups = extractLookups(q);
  out.macros = extractMacros(q);
  out.datamodels = extractDatamodels(q);
  out.commands = splCommands(q);
  other(/\|\s*rest\s+(?:\w+=\S+\s+)*"?([^\s"|]+)/gi, m => 'REST ' + m[1]);
  return out;
}

// Macro calls: `name` or `name(arg1, arg2)`. Splunk identifies a macro by name plus argument count, e.g. name(2).
function splitArgs(s) {
  const args = []; let cur = '', depth = 0, quote = false;
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (quote) { cur += c; if (c === '\\') { cur += s[++i] || ''; } else if (c === '"') quote = false; continue; }
    if (c === '"') { quote = true; cur += c; continue; }
    if (c === '(') depth++; else if (c === ')') depth--;
    if (c === ',' && depth === 0) { args.push(cur.trim()); cur = ''; continue; }
    cur += c;
  }
  if (cur.trim() || args.length) args.push(cur.trim());
  return args;
}
function extractMacros(q) {
  const out = [];
  const re = /`([^`]+)`/g;
  let m;
  while ((m = re.exec(q))) {
    const call = m[1].trim();
    const mm = call.match(/^([\w:.\-]+)\s*(?:\(([\s\S]*)\))?$/);
    if (!mm) continue;
    const args = mm[2] !== undefined ? splitArgs(mm[2]) : [];
    const key = mm[2] !== undefined ? `${mm[1]}(${args.length})` : mm[1];
    if (!out.some(x => x.key === key && x.call === call)) out.push({ key, name: mm[1], args, call });
  }
  return out;
}
// Data models: tstats … from datamodel=Model.Dataset, | from datamodel:Model.Dataset,
// | datamodel Model Dataset search, | pivot Model Dataset …
function extractDatamodels(q) {
  const out = [];
  const add = (raw, dataset, command) => {
    const v = String(raw).replace(/^"(.*)"$/, '$1');
    const i = v.indexOf('.');
    const model = i > 0 ? v.slice(0, i) : v;
    const ds = dataset ? String(dataset).replace(/^"(.*)"$/, '$1') : (i > 0 ? v.slice(i + 1) : '');
    if (!model) return;
    if (!out.some(x => x.model === model && x.dataset === ds && x.command === command)) out.push({ model, dataset: ds, command });
  };
  const V = String.raw`("[^"]+"|\$[^$\s]+\$|[\w.:\-]+)`;
  let m;
  const TS = new RegExp(String.raw`\bdatamodel\s*=\s*` + V, 'gi');
  while ((m = TS.exec(q))) add(m[1], '', /\btstats\b/i.test(q) ? 'tstats' : 'datamodel=');
  const FROM = new RegExp(String.raw`\bfrom\s+datamodel\s*:\s*` + V, 'gi');
  while ((m = FROM.exec(q))) add(m[1], '', 'from');
  const DM = new RegExp(String.raw`(?:^|\||\[)\s*datamodel\s+` + V + String.raw`(?:\s+` + V + ')?', 'gi');
  while ((m = DM.exec(q))) add(m[1], m[2] && !/^(search|flat|acceleration_search|summariesonly=\S*)$/i.test(m[2]) ? m[2] : '', 'datamodel');
  const PV = new RegExp(String.raw`(?:^|\||\[)\s*pivot\s+` + V + String.raw`\s+` + V, 'gi');
  while ((m = PV.exec(q))) add(m[1], m[2], 'pivot');
  return out;
}

// Every command in the pipeline, in order, including subsearches. A query that does not start with "|"
// begins with an implicit search command.
const CMD_CATEGORY = (() => {
  const c = {};
  'search tstats mstats mcatalog inputlookup inputcsv makeresults rest metadata metasearch datamodel pivot from dbinspect eventcount loadjob savedsearch gentimes multisearch searchtxn'.split(' ').forEach(x => c[x] = 'Generating');
  'stats chart timechart top rare xyseries contingency geostats sichart sistats sitimechart sitop sirare tstats associate correlate'.split(' ').forEach(x => c[x] ||= 'Transforming');
  'collect mcollect meventcollect tscollect sendemail sendalert delete script run outputlookup outputcsv outputtext sendresults'.split(' ').forEach(x => c[x] = 'Writes data / side effect');
  return c;
})();
const SIDE_EFFECT = new Set(['collect', 'mcollect', 'meventcollect', 'tscollect', 'sendemail', 'sendalert', 'delete', 'script', 'run', 'outputtext', 'sendresults']);
function splCommands(q) {
  const out = [];
  const walk = (text, sub) => {
    const segs = [], subs = []; let seg = '', quote = false, br = 0, subStart = 0;
    for (let i = 0; i < text.length; i++) {
      const c = text[i];
      if (quote) { seg += c; if (c === '\\') seg += text[++i] || ''; else if (c === '"') quote = false; continue; }
      if (c === '"') { quote = true; seg += c; continue; }
      if (c === '$') { const t = text.slice(i).match(/^\$[^$\s]+\$/); if (t) { seg += t[0]; i += t[0].length - 1; continue; } } // $tok|s$
      if (c === '[') { if (br === 0) subStart = i + 1; br++; seg += c; continue; }
      if (c === ']' && br > 0) { br--; if (br === 0) (subs[segs.length] ||= []).push(text.slice(subStart, i)); seg += c; continue; }
      if (c === '|' && br === 0) { segs.push(seg); seg = ''; continue; }
      seg += c;
    }
    segs.push(seg);
    const leadingPipe = /^\s*\|/.test(text);
    segs.forEach((sg, idx) => {
      const t = sg.trim();
      if (t) {
        if (idx === 0 && !leadingPipe) {
          const w = (t.match(/^([A-Za-z_]\w*)\b/) || [])[1];
          out.push({ name: 'search', implicit: !(w && w.toLowerCase() === 'search'), sub, text: t });
        } else if (t[0] !== '`') { // a macro in command position is listed under macros
          const w = (t.match(/^([A-Za-z_]\w*)\b/) || [])[1];
          if (w) out.push({ name: w.toLowerCase(), implicit: false, sub, text: t });
        }
      } else if (!(idx === 0 && leadingPipe)) out.empty = (out.empty || 0) + 1;
      for (const st of subs[idx] || []) walk(st, true); // subsearches run inside this command
    });
  };
  walk(q, false);
  return out;
}

// Lookups a query reads (lookup, inputlookup, inputcsv, from lookup:) or writes (outputlookup, outputcsv).
// The comment-stripped query is passed in by extractSources.
function extractLookups(q) {
  const out = [];
  const NAME = String.raw`("[^"]+"|\$[^$\s]+\$|[^\s|\]\[()]+)`;
  const OPTS = String.raw`((?:[\w-]+=\S+\s+)*)`;
  const rules = [
    ['inputlookup', 'read'], ['lookup', 'read'], ['inputcsv', 'read'],
    ['outputlookup', 'write'], ['outputcsv', 'write'],
  ];
  for (const [cmd, mode] of rules) {
    const re = new RegExp(String.raw`(?:^|\||\[)\s*` + cmd + String.raw`\s+` + OPTS + NAME, 'gi');
    let m;
    while ((m = re.exec(q))) {
      const name = m[2].replace(/^"(.*)"$/, '$1');
      const opts = m[1].trim();
      if (!out.some(x => x.name === name && x.mode === mode && x.command === cmd)) out.push({ name, mode, command: cmd, options: opts });
    }
  }
  const FROM = /\bfrom\s+(?:input)?lookup:("[^"]+"|[\w.\-]+)/gi;
  let m;
  while ((m = FROM.exec(q))) { const name = m[1].replace(/^"(.*)"$/, '$1'); if (!out.some(x => x.name === name && x.mode === 'read')) out.push({ name, mode: 'read', command: 'from', options: '' }); }
  return out;
}

/* ============================================================
   Splunk configuration: macros.conf, savedsearches.conf, data models
   ============================================================ */
let CONFIG = { conf: '', dm: '', macros: new Map(), saved: new Map(), datamodels: new Map(), errors: [] };
const hasConfig = () => CONFIG.macros.size + CONFIG.saved.size + CONFIG.datamodels.size > 0;
// .conf files: [stanza] lines, key = value, values continued with a trailing backslash.
function parseConf(text) {
  const stanzas = [];
  let cur = null;
  const lines = String(text || '').split(/\r?\n/);
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (!line.trim() || /^\s*[#;]/.test(line)) continue;
    const st = line.match(/^\s*\[(.+)\]\s*$/);
    if (st) { cur = { name: st[1].trim(), kv: {} }; stanzas.push(cur); continue; }
    const kv = line.match(/^\s*([^=]+?)\s*=\s?(.*)$/);
    if (!kv || !cur) continue;
    let val = kv[2];
    while (/\\\s*$/.test(val) && i + 1 < lines.length) val = val.replace(/\\\s*$/, '\n') + lines[++i];
    cur.kv[kv[1].trim()] = val.trim();
  }
  return stanzas;
}
// Data model JSON: a model file ({modelName, objects}), a REST response, or several of either back to back.
function parseDatamodels(text, errors) {
  const out = new Map();
  const t = String(text || '').trim();
  const add = m => {
    if (typeof m === 'string') { try { m = JSON.parse(m); } catch { return; } }
    if (isObj(m) && m.modelName && Array.isArray(m.objects)) {
      out.set(m.modelName, {
        name: m.modelName, displayName: m.displayName || m.modelName,
        objects: m.objects.map(o => ({
          name: o.objectName, parent: o.parentName || '',
          constraints: (o.constraints || []).map(c => c?.search).filter(Boolean),
          fields: (o.fields || []).map(f => f?.fieldName).filter(Boolean)
        }))
      });
    } else if (isObj(m) && Array.isArray(m.entry)) m.entry.forEach(en => add(en?.content?.['eai:data']));
    else if (Array.isArray(m)) m.forEach(add);
  };
  let i = 0;
  while (i < t.length) {
    const rel = t.slice(i).search(/[{[]/);
    if (rel < 0) break;
    const s = i + rel, e = jsonValueEnd(t, s);
    if (e < 0) { errors.push('A data model JSON block is never closed.'); break; }
    try { add(JSON.parse(t.slice(s, e))); } catch (err) { errors.push('Data model JSON could not be parsed: ' + err.message); }
    i = e;
  }
  return out;
}
function applyConfig(conf, dm) {
  const errors = [], macros = new Map(), saved = new Map();
  for (const st of parseConf(conf)) {
    if (st.name === 'default') continue;
    if ('definition' in st.kv) {
      const m = st.name.match(/^(.*?)\((\d+)\)$/);
      macros.set(st.name, {
        key: st.name, name: m ? m[1] : st.name, arity: m ? +m[2] : 0,
        args: (st.kv.args || '').split(',').map(s => s.trim()).filter(Boolean),
        definition: st.kv.definition, iseval: /^(1|true)$/i.test(st.kv.iseval || '')
      });
    } else if ('search' in st.kv) {
      saved.set(st.name, { name: st.name, search: st.kv.search, earliest: st.kv['dispatch.earliest_time'] || '', latest: st.kv['dispatch.latest_time'] || '', cron: st.kv.cron_schedule || '' });
    }
  }
  CONFIG = { conf, dm, macros, saved, datamodels: parseDatamodels(dm, errors), errors };
}
// Expand macro calls recursively. Records what was expanded, missing, or looping in `info`.
function expandMacros(q, info, depth = 0, stack = []) {
  return String(q).replace(/`([^`]+)`/g, (all, call) => {
    const mm = call.trim().match(/^([\w:.\-]+)\s*(?:\(([\s\S]*)\))?$/);
    if (!mm) return all;
    const args = mm[2] !== undefined ? splitArgs(mm[2]) : [];
    const key = mm[2] !== undefined ? `${mm[1]}(${args.length})` : mm[1];
    const m = CONFIG.macros.get(key);
    if (!m) {
      if (!info.missing.some(x => x.key === key)) info.missing.push({ key, other: [...CONFIG.macros.values()].filter(x => x.name === mm[1]).map(x => x.key) });
      return all;
    }
    if (stack.includes(key) || depth > 10) { if (!info.loops.includes(key)) info.loops.push(key); return all; }
    if (depth > 0 && !info.nested.some(x => x.key === key)) info.nested.push({ key, call: call.trim(), in: stack[stack.length - 1] });
    if (!info.used.includes(key)) info.used.push(key);
    if (m.iseval) { if (!info.evalMacros.includes(key)) info.evalMacros.push(key); return ' '; }
    let body = m.definition;
    m.args.forEach((a, i) => { body = body.split('$' + a + '$').join(args[i] ?? ''); });
    return ' ' + expandMacros(body, info, depth + 1, [...stack, key]) + ' ';
  });
}
// The text a data source really runs, for analysis: macros expanded, saved searches inlined,
// and the constraint searches of the data models it reads appended.
function expandForAnalysis(n) {
  const info = { used: [], nested: [], missing: [], loops: [], evalMacros: [], saved: [], savedMissing: [], datamodels: [], datasetMissing: [] };
  const parts = [];
  if (n.type === 'ds.savedSearch') {
    const s = CONFIG.saved.get(n.ref);
    if (s) { parts.push(s.search); info.saved.push(n.ref); } else if (CONFIG.saved.size) info.savedMissing.push(n.ref);
  } else parts.push(n.query || '');
  for (const m of String(n.query || '').matchAll(/(?:^|\||\[)\s*savedsearch\s+("([^"]+)"|[^\s|\]]+)/gi)) {
    const name = m[2] || m[1];
    const s = CONFIG.saved.get(name);
    if (s) { parts.push(s.search); info.saved.push(name); } else if (CONFIG.saved.size) info.savedMissing.push(name);
  }
  let text = expandMacros(parts.join('\n'), info);
  for (const d of extractDatamodels(text)) {
    const model = CONFIG.datamodels.get(d.model);
    if (!model) continue;
    const want = (d.dataset || '').split('.').pop();
    let o = want ? model.objects.find(x => x.name === want) : model.objects.find(x => !x.parent || /^Base(Event|Search|Transaction)$/.test(x.parent));
    if (!o) { info.datasetMissing.push(`${d.model}.${d.dataset}`); continue; }
    const constraints = [];
    const seen = new Set();
    while (o && !seen.has(o.name)) { seen.add(o.name); constraints.unshift(...o.constraints); o = model.objects.find(x => x.name === o.parent); }
    info.datamodels.push({ model: d.model, dataset: d.dataset, constraints });
    if (constraints.length) text += '\n' + expandMacros(constraints.join(' '), info);
  }
  return { text, info };
}
// Add what only the expanded text revealed to a search's sources, labelled with how it was found.
function mergeExpanded(own, ex, via) {
  for (const f of ['index', 'sourcetype']) for (const v of ex[f]) if (!own[f].some(x => x.value === v.value && x.excluded === v.excluded)) own[f].push({ ...v, via });
  for (const l of ex.lookups) if (!own.lookups.some(x => x.name === l.name && x.mode === l.mode)) own.lookups.push({ ...l, via });
  for (const d of ex.datamodels) if (!own.datamodels.some(x => x.model === d.model && x.dataset === d.dataset)) own.datamodels.push({ ...d, via });
  for (const c of ex.commands) if (!own.commands.some(x => x.name === c.name)) own.commands.push({ ...c, via });
  for (const o of ex.other) if (!own.other.includes(o)) own.other.push(o);
}

/* ============================================================
   SPL checks
   ============================================================ */
const KNOWN_CMDS = new Set(`abstract accum addcoltotals addinfo addtotals analyzefields anomalies anomalousvalue anomalydetection append appendcols
appendpipe apply arules associate audit autoregress bin bucket bucketdir chart cluster cofilter collect concurrency contingency convert correlate
datamodel dbinspect dbxquery dedup delete delta diff dump erex eval eventcount eventstats extract fieldformat fields fieldsummary filldown fillnull
findtypes fit folderize foreach format from gauge gentimes geom geomfilter geostats head highlight history iconify inputcsv inputlookup iplocation
join kmeans kv kvform ldapfilter ldapsearch loadjob localize localop lookup makecontinuous makemv makeresults map mcatalog mcollect metadata metasearch
meventcollect mpreview msearch mstats multikv multisearch mvcombine mvexpand nomv outlier outputcsv outputlookup outputtext overlap pivot predict
rangemap rare redistribute regex reltime rename replace require rest return reverse rex rtorder run sample savedsearch score script scrub search
searchtxn selfjoin sendalert sendemail set setfields sichart sirare sistats sitimechart sitop sort spath stats strcat streamstats summary table tags
tail timechart timewrap tojson top transaction transpose trendline tscollect tstats typeahead typelearner typer union uniq untable walklate where
x11 xmlkv xmlunescape xpath xyseries`.split(/\s+/));
const STATS_LIKE = new Set(['stats', 'eventstats', 'streamstats', 'chart', 'timechart', 'sistats', 'sichart', 'sitimechart', 'tstats', 'mstats', 'geostats']);
const FIELD_FUNCS = /^(sum|avg|mean|max|min|median|mode|stdev|stdevp|var|varp|range|sumsq|first|last|list|values|dc|distinct_count|estdc|estdc_error|earliest|latest|earliest_time|latest_time|rate|rate_avg|rate_sum|per_second|per_minute|per_hour|per_day|p\d{1,2}|perc\d{1,2}|exactperc\d{1,2}|upperperc\d{1,2})$/i;
const NEEDS_ARGS = new Set(['eval', 'where', 'rename', 'rex', 'lookup', 'inputlookup', 'outputlookup', 'table', 'fields', 'dedup', 'sort', 'bin', 'bucket',
  'stats', 'eventstats', 'streamstats', 'chart', 'timechart', 'tstats', 'top', 'rare', 'append', 'appendcols', 'join', 'regex', 'convert', 'makemv',
  'mvexpand', 'collect', 'sendemail', 'inputcsv', 'outputcsv', 'xyseries', 'strcat', 'fieldformat', 'datamodel', 'pivot', 'from', 'savedsearch', 'loadjob', 'map', 'foreach']);
const GENERATING = new Set(['inputlookup', 'inputcsv', 'makeresults', 'tstats', 'mstats', 'mcatalog', 'rest', 'datamodel', 'pivot', 'metadata', 'metasearch',
  'from', 'loadjob', 'savedsearch', 'dbinspect', 'eventcount', 'gentimes', 'multisearch', 'dbxquery', 'ldapsearch']);
const TRANSFORMING = new Set(['stats', 'chart', 'timechart', 'top', 'rare', 'tstats', 'mstats', 'xyseries', 'geostats', 'contingency', 'sistats', 'sichart', 'sitimechart']);
const NO_EVENT_TIME = new Set(['inputlookup', 'inputcsv', 'makeresults', 'rest', 'gentimes']);
const prependPipe = q => '| ' + String(q).replace(/^\s+/, '');
// Returns problems in one search's SPL: [{ severity, message, fixLabel?, fix?(query) }]
function lintSpl(q, isChain) {
  const out = [];
  const add = (severity, message, fixLabel, fix) => { if (!out.some(x => x.message === message)) out.push({ severity, message: 'SPL: ' + message, fixLabel, fix }); };
  if (!q || !q.trim()) return out;
  const clean = q.replace(/```[\s\S]*?```/g, m => ' '.repeat(m.length));
  let inStr = false, open = { '(': 0, '[': 0 }, close = { ')': 0, ']': 0 }, early = { ')': false, ']': false }, ticks = 0;
  for (let i = 0; i < clean.length; i++) {
    const c = clean[i];
    if (inStr) { if (c === '\\') i++; else if (c === '"') inStr = false; continue; }
    if (c === '"') inStr = true;
    else if (c === '(' || c === '[') open[c]++;
    else if (c === ')' || c === ']') { close[c]++; const o = c === ')' ? '(' : '['; if (close[c] > open[o]) early[c] = true; }
    else if (c === '`') ticks++;
  }
  if (inStr) add('error', 'a double quote (") is never closed.');
  if (open['('] !== close[')'] || early[')']) add('error', `unbalanced parentheses: ${open['(']} "(" and ${close[')']} ")".`);
  if (open['['] !== close[']'] || early[']']) add('error', `unbalanced square brackets: ${open['[']} "[" and ${close[']']} "]".`);
  if (ticks % 2) add('error', 'a backtick (`) around a macro is never closed.');
  const cmds = splCommands(clean);
  if (cmds.empty) add('error', 'there is an empty command: two pipes with nothing between them, or a pipe at the end.', 'Remove the empty command',
    s => s.replace(/\|\s*(?=\|)/g, '').replace(/\|\s*$/, '').trimEnd());
  const firstWord = (clean.trim().match(/^([A-Za-z_]\w*)/) || [])[1]?.toLowerCase();
  if (isChain && !/^\s*\|/.test(clean)) add('warning', 'a chain search should start with a pipe (|), for example "| stats count".', 'Add the leading pipe', prependPipe);
  else if (!isChain && firstWord && GENERATING.has(firstWord)) add('error', `${firstWord} is a generating command, so the search must start with a pipe: "| ${firstWord} …".`, 'Add the leading pipe', prependPipe);
  for (const c of cmds) {
    if (c.implicit || !c.text) continue;
    const args = c.text.replace(/^\s*[A-Za-z_]\w*/, '').trim();
    if (!KNOWN_CMDS.has(c.name)) add('info', `| ${c.name} isn't a built-in SPL command. It may be a custom command from an app, or a typo.`);
    if (NEEDS_ARGS.has(c.name) && !args) add('error', `| ${c.name} has nothing after it.`);
    else if (c.name === 'rename' && !/\bas\b/i.test(args)) add('error', '| rename needs "old_name AS new_name".');
    else if (c.name === 'eval' && !args.includes('=')) add('error', '| eval needs an assignment, for example "| eval total = a + b".');
    else if (STATS_LIKE.has(c.name)) {
      const words = args.match(/"[^"]*"|\S+/g) || [];
      for (let i = 0; i < words.length; i++) {
        const lw = words[i].toLowerCase().replace(/,$/, '');
        if (/^(by|over|from|where|groupby)$/.test(lw)) break;
        if (lw === 'as') { i++; continue; }
        if (lw.includes('=')) continue;
        if (FIELD_FUNCS.test(lw)) add('error', `| ${c.name} ${lw} needs a field to work on, for example ${lw}(bytes). Splunk rejects "${lw}" on its own.`);
      }
    }
  }
  return out;
}

/* ============================================================
   Definition checks: names, types and values Splunk won't recognise
   ============================================================ */
const setOf = s => new Set(s.split(/\s+/).filter(Boolean));
const TOP_KEYS = setOf('title description visualizations dataSources inputs layout defaults expressions applicationProperties');
const VIZ_TYPES = setOf(`splunk.area splunk.bar splunk.bubble splunk.choropleth.svg splunk.choropleth.map splunk.column splunk.ellipse splunk.events splunk.fillergauge
  splunk.image splunk.line splunk.linkgraph splunk.map splunk.markdown splunk.markergauge splunk.parallelcoordinates splunk.pie splunk.punchcard splunk.rectangle
  splunk.sankey splunk.scatter splunk.singlevalue splunk.singlevalueicon splunk.singlevalueradial splunk.table abslayout.line`);
const INPUT_TYPES = setOf('input.dropdown input.multiselect input.timerange input.text input.number input.checkbox input.radio');
const HANDLER_TYPES = setOf('drilldown.setToken drilldown.unsetToken drilldown.linkToDashboard drilldown.linkToSearch drilldown.linkToReport drilldown.linkToUrl drilldown.customUrl');
const VIZ_KEYS = setOf('type title description dataSources options context eventHandlers containerOptions showProgressBar showLastUpdated encoding');
const INPUT_KEYS = setOf('type title options dataSources context containerOptions encoding');
const DS_KEYS = setOf('type name options meta');
const DS_OPTION_KEYS = setOf('query queryParameters extend ref app enableSmartSources refresh refreshType data');
const QP_KEYS = setOf('earliest latest refresh refreshType sampleRatio');
const INPUT_OPTION_KEYS = setOf(`token defaultValue items valuePrefix valueSuffix delimiter prefix suffix selectFirstSearchResult clearDefaultOnSelection placeholder
  min max step size initialValue`);
const OPTION_KEYS = setOf(`backgroundColor majorValue majorColor majorFontSize trendValue trendColor trendDisplay trendFontSize sparklineValues sparklineDisplay
  sparklineStrokeColor sparklineAreaColor sparklineHighlightDots sparklineHighlightSegments showSparklineAreaGraph showSparklineTooltip numberPrecision unit unitPosition
  shouldUseThousandSeparators shouldAbbreviateTrendValue underLabel underLabelColor underLabelFontSize x y y2 xField yFields seriesColors seriesColorsByField legendDisplay
  legendTruncation legendLabels legendMode stackMode showSplitSeries showIndependentYRanges xAxisTitleText xAxisTitleVisibility yAxisTitleText yAxisTitleVisibility
  xAxisLabelRotation xAxisLabelVisibility yAxisLabelVisibility xAxisMajorTickVisibility yAxisMajorTickVisibility xAxisLineVisibility yAxisLineVisibility xAxisMajorTickSize
  yAxisScale yAxisMin yAxisMax yAxisMajorTickInterval y2AxisTitleText y2AxisScale overlayFields showOverlayY2Axis lineWidth lineDashStyle nullValueDisplay
  showYMajorGridLines showXMajorGridLines dataValuesDisplay areaOpacity barSpacing seriesSpacing resultLimit showYAxisWithZero showY2MajorGridLines xAxisMaxLabelParts
  count columnFormat headerVisibility showRowNumbers showInternalFields tableFormat fontSize fontFamily fontColor rowBackgroundColors headerBackgroundColor rowColors
  markdown customFontSize src preserveAspectRatio fillColor fillOpacity strokeColor strokeWidth strokeDashStyle strokeOpacity rx labelDisplay showDonutHole
  collapseThreshold collapseLabel showTooltip majorValueField icon iconColor iconOpacity gaugeColor gaugeRanges value label`);
const ENUMS = {
  legendDisplay: ['right', 'left', 'top', 'bottom', 'off'], stackMode: ['auto', 'stacked', 'stacked100'], sparklineDisplay: ['before', 'after', 'below', 'off'],
  trendDisplay: ['absolute', 'percent', 'off'], legendTruncation: ['ellipsisEnd', 'ellipsisMiddle', 'ellipsisStart', 'ellipsisOff'], dataValuesDisplay: ['off', 'all', 'minmax'],
  unitPosition: ['before', 'after'], labelDisplay: ['values', 'valuesAndPercentage', 'off'], yAxisScale: ['linear', 'log'], nullValueDisplay: ['gaps', 'zero', 'connect'],
  headerVisibility: ['none', 'fixed', 'inline'],
};
const NUMBER_KEYS = setOf('count majorFontSize trendFontSize underLabelFontSize fontSize numberPrecision lineWidth fillOpacity strokeWidth areaOpacity rx collapseThreshold');
const BOOL_KEYS = setOf('showDonutHole showRowNumbers showInternalFields shouldUseThousandSeparators shouldAbbreviateTrendValue showSparklineAreaGraph showSparklineTooltip showTooltip preserveAspectRatio showSplitSeries showIndependentYRanges showYAxisWithZero showOverlayY2Axis');
function editDistance(a, b) {
  if (Math.abs(a.length - b.length) > 2) return 9;
  const d = Array.from({ length: a.length + 1 }, (_, i) => [i]);
  for (let j = 1; j <= b.length; j++) d[0][j] = j;
  for (let i = 1; i <= a.length; i++) for (let j = 1; j <= b.length; j++) d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
  return d[a.length][b.length];
}
// The known name a misspelling most likely meant (case differences count as a match).
function closestName(word, known) {
  if (String(word).length < 4) return null;
  let best = null, bd = 3;
  for (const k of known) { const dd = editDistance(String(word).toLowerCase(), k.toLowerCase()); if (dd < bd) { bd = dd; best = k; } }
  return bd <= 2 ? best : null;
}
const renameKey = (obj, from, to) => { if (obj && Object.prototype.hasOwnProperty.call(obj, from) && !Object.prototype.hasOwnProperty.call(obj, to)) { obj[to] = obj[from]; delete obj[from]; } };
const isDynamic = v => typeof v === 'string' && (v.trim().startsWith('>') || v.includes('$'));
function checkDefinition(def, issue, ids) {
  const D = (sev, msg, ref, fix) => issue(sev, 'Definition: ' + msg, ref, fix);
  // Unknown key: flagged only when it looks like a misspelling of a known one, with a rename fix.
  // `what` names the kind of key, e.g. "Option". The rename is offered only if the right name isn't already there.
  const keyCheck = (obj, known, what, ref, path) => {
    if (!isObj(obj)) return;
    for (const k of Object.keys(obj)) {
      if (known.has(k)) continue;
      const c = closestName(k, known);
      if (!c) continue;
      const clash = Object.prototype.hasOwnProperty.call(obj, c);
      D('warning', `${what} "${k}" isn't one Splunk recognises. Did you mean "${c}"?${clash ? ` There is also a "${c}", so merge the two by hand.` : ''}`, ref,
        clash ? undefined : { label: `Rename "${k}" to "${c}"`, apply: d => renameKey(path(d), k, c) });
    }
  };
  const an = w => /^[aeiou]/i.test(w) ? 'an ' + w : 'a ' + w;
  const typeCheck = (type, known, what, ref, path, customOk) => {
    if (!type) { D('error', `this ${what} has no "type".`, ref); return; }
    if (known.has(type)) return;
    const c = closestName(type, known);
    if (c) D('error', `"${type}" isn't ${an(what)} type. Did you mean "${c}"?`, ref, { label: `Change the type to "${c}"`, apply: d => { const o = path(d); if (o) o.type = c; } });
    else if (!customOk) D('warning', `"${type}" isn't a built-in ${what} type.`, ref);
    else D('info', `"${type}" isn't a built-in ${what} type. It may be a custom visualization from an app.`, ref);
  };
  keyCheck(def, TOP_KEYS, 'Top-level key', 'dashboard:root', d => d);
  const sections = [['visualizations', 'viz'], ['inputs', 'input'], ['dataSources', 'ds']];
  const seen = new Map();
  for (const [sec, kind] of sections) for (const id of Object.keys(isObj(def[sec]) ? def[sec] : {})) {
    if (seen.has(id) && seen.get(id) !== kind) D('warning', `the ID "${id}" is used in both ${seen.get(id) === 'viz' ? 'visualizations' : seen.get(id) === 'input' ? 'inputs' : 'dataSources'} and ${sec}, so references to it are ambiguous.`, kind + ':' + id);
    seen.set(id, kind);
  }
  // Visualizations
  for (const [id, v] of Object.entries(isObj(def.visualizations) ? def.visualizations : {})) {
    const ref = 'viz:' + id, at = d => d.visualizations?.[id];
    if (!isObj(v)) { D('error', 'this visualization is not an object.', ref); continue; }
    typeCheck(v.type, VIZ_TYPES, 'visualization', ref, at, true);
    keyCheck(v, VIZ_KEYS, 'Key', ref, at);
    if (v.dataSources !== undefined && !isObj(v.dataSources)) D('error', '"dataSources" should be an object such as { "primary": "ds_id" }.', ref);
    else for (const [k, x] of Object.entries(v.dataSources || {})) if (typeof x !== 'string') D('error', `dataSources.${k} should be a data source ID (text).`, ref);
    if (isObj(v.options)) {
      keyCheck(v.options, OPTION_KEYS, 'Option', ref, d => at(d)?.options);
      for (const [k, x] of Object.entries(v.options)) {
        if (isDynamic(x)) continue;
        if (ENUMS[k] && !ENUMS[k].includes(String(x))) D('warning', `option ${k} is "${fmt(x)}", which isn't one of ${ENUMS[k].join(', ')}.`, ref);
        if (NUMBER_KEYS.has(k) && typeof x !== 'number' && !(typeof x === 'string' && /^-?\d+(\.\d+)?$/.test(x.trim()))) D('warning', `option ${k} should be a number, not ${JSON.stringify(x)}.`, ref);
        if (BOOL_KEYS.has(k) && typeof x !== 'boolean') D('warning', `option ${k} should be true or false, not ${JSON.stringify(x)}.`, ref,
          (x === 'true' || x === 'false') ? { label: `Make ${k} ${x} (not "${x}")`, apply: d => { const o = at(d)?.options; if (o) o[k] = x === 'true'; } } : undefined);
      }
    } else if (v.options !== undefined) D('error', '"options" should be an object.', ref);
    if (v.eventHandlers !== undefined && !Array.isArray(v.eventHandlers)) D('error', '"eventHandlers" should be a list.', ref);
    else (v.eventHandlers || []).forEach((h, i) => typeCheck(h?.type, HANDLER_TYPES, 'drilldown', ref, d => at(d)?.eventHandlers?.[i], false));
  }
  // Inputs
  for (const [id, n] of Object.entries(isObj(def.inputs) ? def.inputs : {})) {
    const ref = 'input:' + id, at = d => d.inputs?.[id];
    if (!isObj(n)) { D('error', 'this input is not an object.', ref); continue; }
    typeCheck(n.type, INPUT_TYPES, 'input', ref, at, false);
    keyCheck(n, INPUT_KEYS, 'Key', ref, at);
    const o = isObj(n.options) ? n.options : {};
    keyCheck(o, INPUT_OPTION_KEYS, 'Input option', ref, d => at(d)?.options);
    const dv = o.defaultValue;
    if (n.type === 'input.timerange' && dv !== undefined && !isDynamic(dv) && !(typeof dv === 'string' && dv.includes(','))) D('warning', `a time range default should be "earliest,latest" (for example "-24h@h,now"), not ${JSON.stringify(dv)}.`, ref);
    if (n.type === 'input.number' && dv !== undefined && !isDynamic(dv) && isNaN(Number(dv))) D('warning', `a number input's default should be a number, not ${JSON.stringify(dv)}.`, ref);
    if ((n.type === 'input.multiselect' || n.type === 'input.checkbox') && dv !== undefined && !Array.isArray(dv) && !isDynamic(dv)) D('info', `a ${shortType(n.type)} default is usually a list, for example ["a", "b"].`, ref);
    if (o.items !== undefined && (!Array.isArray(o.items) || o.items.some(it => !isObj(it) || it.value === undefined))) D('warning', '"items" should be a list of { "label": …, "value": … } choices.', ref);
  }
  // Data sources
  for (const [id, s] of Object.entries(isObj(def.dataSources) ? def.dataSources : {})) {
    const ref = 'ds:' + id, at = d => d.dataSources?.[id];
    if (!isObj(s)) { D('error', 'this data source is not an object.', ref); continue; }
    typeCheck(s.type, new Set(Object.keys(DS_TYPES)), 'data source', ref, at, false);
    keyCheck(s, DS_KEYS, 'Key', ref, at);
    const o = isObj(s.options) ? s.options : {};
    keyCheck(o, DS_OPTION_KEYS, 'Data source option', ref, d => at(d)?.options);
    keyCheck(o.queryParameters, QP_KEYS, 'Query parameter', ref, d => at(d)?.options?.queryParameters);
    if ((s.type === 'ds.search' || s.type === 'ds.chain') && !(typeof o.query === 'string' && o.query.trim())) D('error', 'this search has no query.', ref);
    if (s.type === 'ds.savedSearch' && !o.ref) D('error', 'this saved search data source has no "ref" (the report name).', ref);
  }
  // Layout: types, positions, overlaps and canvas bounds
  const L = isObj(def.layout) ? def.layout : {};
  const canvases = isObj(L.layoutDefinitions) ? Object.entries(L.layoutDefinitions).map(([k, v]) => [k, v, d => d.layout?.layoutDefinitions?.[k]]) : (L.structure ? [['main', L, d => d.layout]] : []);
  for (const [key, c, at] of canvases) {
    if (!isObj(c)) continue;
    const ref = ids.has('tab:' + key) ? 'tab:' + key : 'dashboard:root';
    const type = c.type || L.type;
    if (type && type !== 'grid' && type !== 'absolute') {
      const g = closestName(type, new Set(['grid', 'absolute']));
      D('error', `layout type "${type}" should be "grid" or "absolute".`, ref, g ? { label: `Change it to "${g}"`, apply: d => { const o = at(d); if (o) o.type = g; } } : undefined);
    }
    const blocks = (Array.isArray(c.structure) ? c.structure : []).filter(b => isObj(b?.position) && ['x', 'y', 'w', 'h'].every(k => b.position[k] !== undefined));
    for (const b of blocks) {
      const p = b.position;
      if (['x', 'y', 'w', 'h'].some(k => typeof p[k] !== 'number')) { D('warning', `"${b.item}" has a position with non-numeric values.`, ref); continue; }
      if (p.w <= 0 || p.h <= 0) D('warning', `"${b.item}" has zero or negative width or height, so it can't be seen.`, ref);
      if (type === 'absolute') {
        const W = Number(c.options?.width) || 1440, H = Number(c.options?.height) || 960;
        if (p.x < 0 || p.y < 0 || p.x + p.w > W || p.y + p.h > H) D('warning', `"${b.item}" extends outside the ${W}×${H} canvas, so part of it is cut off.`, ref);
      } else if (type === 'grid' && p.x + p.w > 1200) D('warning', `"${b.item}" extends past the 1,200-pixel grid width.`, ref);
    }
    if (type === 'grid') {
      for (let i = 0; i < blocks.length; i++) for (let j = i + 1; j < blocks.length; j++) {
        const a = blocks[i].position, bb = blocks[j].position;
        if (a.x < bb.x + bb.w && bb.x < a.x + a.w && a.y < bb.y + bb.h && bb.y < a.y + a.h)
          D('warning', `"${blocks[i].item}" and "${blocks[j].item}" overlap on the grid. Grid layouts don't allow overlapping panels.`, ref);
      }
    }
  }
}

/* ============================================================
   Accessibility (added to the recommendations)
   ============================================================ */
function hexToRgb(h) {
  const m = String(h).trim().match(/^#([0-9a-f]{3}|[0-9a-f]{6})([0-9a-f]{2})?$/i);
  if (!m) return null;
  let s = m[1]; if (s.length === 3) s = s.split('').map(c => c + c).join('');
  return [0, 2, 4].map(i => parseInt(s.slice(i, i + 2), 16));
}
const luminance = rgb => { const [r, g, b] = rgb.map(v => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }); return 0.2126 * r + 0.7152 * g + 0.0722 * b; };
const contrastRatio = (a, b) => { const la = luminance(a), lb = luminance(b); return (Math.max(la, lb) + 0.05) / (Math.min(la, lb) + 0.05); };
function hueSat(rgb) {
  const [r, g, b] = rgb.map(v => v / 255), mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2, d = mx - mn;
  if (!d) return { h: 0, s: 0, l };
  const s = d / (1 - Math.abs(2 * l - 1));
  let h = mx === r ? ((g - b) / d) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4;
  h = (h * 60 + 360) % 360;
  return { h, s, l };
}
const isRed = c => { const x = hueSat(c); return x.s >= 0.35 && x.l > 0.15 && x.l < 0.85 && (x.h >= 340 || x.h <= 20); };
const isGreen = c => { const x = hueSat(c); return x.s >= 0.25 && x.l > 0.12 && x.l < 0.85 && x.h >= 75 && x.h <= 165; };
// The page colour behind the panels: the panel's own background, the canvas background, or the dashboard theme.
function dashboardBackground() {
  const canvasBg = M.byKind('tab').map(t => t.options?.backgroundColor).find(c => hexToRgb(c));
  if (canvasBg) return { rgb: hexToRgb(canvasBg), label: canvasBg };
  const theme = (String(M.src.xmlText || '').match(/<dashboard[^>]*\btheme="(\w+)"/) || [])[1] || M.src.def?.applicationProperties?.theme || 'light';
  return theme === 'dark' ? { rgb: [23, 29, 33], label: 'the dark theme' } : { rgb: [255, 255, 255], label: 'the light theme' };
}
function accessibilityRecs(add) {
  const bg = dashboardBackground();
  const TEXT_KEYS = /^(majorColor|fontColor|textColor|underLabelColor|trendColor|color|iconColor)$/;
  const low = [], redGreen = [], small = [];
  for (const v of M.byKind('viz')) {
    const o = isObj(v.raw?.options) ? v.raw.options : {}, ctx = isObj(v.raw?.context) ? v.raw.context : {};
    const own = hexToRgb(o.backgroundColor) || bg.rgb;
    // Colours a text option uses: a fixed colour, or the colours of the context config a dynamic option picks from.
    const colorsFor = val => {
      if (hexToRgb(val)) return [val];
      const m = typeof val === 'string' && val.match(/(?:rangeValue|matchValue|pick|gradient)\((\w+)\)/);
      const cfg = m && ctx[m[1]];
      return Array.isArray(cfg) ? cfg.map(x => (isObj(x) ? x.value : x)).filter(x => hexToRgb(x)) : [];
    };
    for (const [k, val] of Object.entries(o)) {
      if (!TEXT_KEYS.test(k)) continue;
      const large = /^(majorColor|trendColor|iconColor)$/.test(k);
      for (const c of colorsFor(val)) {
        const r = contrastRatio(hexToRgb(c), own);
        if (r < (large ? 3 : 4.5)) low.push({ id: v.id, text: `${v.label}: ${k} ${c} on ${hexToRgb(o.backgroundColor) ? o.backgroundColor : bg.label} is ${r.toFixed(1)}:1` });
      }
    }
    const all = [];
    walk({ o, ctx }, '', s => { for (const m of String(s).matchAll(/#[0-9a-f]{6}\b|#[0-9a-f]{3}\b/gi)) all.push(hexToRgb(m[0])); });
    if (all.some(c => c && isRed(c)) && all.some(c => c && isGreen(c))) redGreen.push(v.id);
    for (const k of ['fontSize', 'majorFontSize', 'trendFontSize', 'underLabelFontSize']) if (typeof o[k] === 'number' && o[k] < 12) small.push(v.id);
  }
  add('Medium', 'Accessibility', 'Raise colour contrast',
    `Some text colours are hard to read against their background (checked against ${bg.label} where a panel has no background of its own). WCAG asks for at least 4.5:1 for normal text and 3:1 for large numbers.`,
    'Pick darker text on light backgrounds (or lighter on dark), or change the background. Check pairs with a contrast checker.',
    low.map(x => x.id), low.length ? low.map(x => x.text).join('\n') : undefined);
  add('Medium', 'Accessibility', 'Don\'t rely on red versus green alone',
    'These panels use both red and green colours, often for good versus bad. About 1 in 12 men can\'t tell them apart.',
    'Add another cue: an arrow or sign on trends, a label or icon, or a colour-blind-safe pair such as blue and orange.', redGreen,
    'Safer pairs: #1F77B4 (blue) and #FF7F0E (orange), or #0072B2 and #D55E00');
  const mdIssues = [], imgNoText = [];
  for (const v of M.byKind('viz')) {
    const t = shortType(v.type);
    if (t === 'image' && !v.title && !v.raw?.description) imgNoText.push(v.id);
    if (t === 'markdown') {
      const md = String(v.raw?.options?.markdown ?? '');
      if (/!\[\s*\]\(/.test(md)) mdIssues.push(v.id);
      let last = 0;
      for (const m of md.matchAll(/^(#{1,6})\s/gm)) { const lv = m[1].length; if (last && lv > last + 1) { mdIssues.push(v.id); break; } last = lv; }
    }
  }
  add('Low', 'Accessibility', 'Describe image panels',
    'Image panels with no title or description give screen-reader users nothing to go on.',
    'Give each image a title, or a "description" saying what it shows.', imgNoText);
  add('Low', 'Accessibility', 'Fix markdown images and headings',
    'These markdown panels have images with empty alt text (![](…)), or headings that skip a level (for example # then ###), which confuses screen readers.',
    'Describe each image in the brackets, ![like this](url), and step headings down one level at a time.', uniq(mdIssues));
  add('Low', 'Accessibility', 'Avoid very small text',
    'Font sizes under 12 pixels are hard to read, especially on wall displays and for people with low vision.',
    'Use 12 or larger, or leave the size unset so the panel scales it.', uniq(small));
}

/* ============================================================
   Splunk version compatibility
   Minimum versions are approximate (from Splunk release notes); each can be corrected on the page.
   ============================================================ */
const COMPAT_VERSIONS = ['8.2', '9.0', '9.1', '9.2', '9.3', '9.4', '10.0'];
const COMPAT_FEATURES = [
  { key: 'studio', feature: 'Dashboard Studio', min: '8.2', items: () => ['dashboard:root'] },
  { key: 'grid', feature: 'Grid layout', min: '9.0', items: () => M.byKind('tab').filter(t => !t.global && t.layoutType === 'grid').map(t => t.id) },
  { key: 'tokdefaults', feature: 'Default token values (defaults.tokens)', min: '9.0', items: () => M.byKind('token').filter(t => ins(t.id, ['default']).length).map(t => t.id) },
  { key: 'hidenodata', feature: 'Hide panels that have no data', min: '9.0', items: () => [...M.byKind('viz'), ...M.byKind('input')].filter(n => /hidden when no data/.test(n.visibility || '')).map(n => n.id) },
  { key: 'smart', feature: 'Smart-source tokens ($search:result.field$)', min: '9.0', items: () => M.byKind('token').filter(t => t.subtype === 'smart').map(t => t.id) },
  { key: 'tabs', feature: 'Tabs', min: '9.1', items: () => M.byKind('tab').filter(t => t.isTab).map(t => t.id) },
  { key: 'unset', feature: 'Unset-token drilldowns', min: '9.1', items: () => M.byKind('viz').filter(v => v.drilldowns.some(d => /unsetToken/i.test(d.type))).map(v => v.id) },
  { key: 'conditions', feature: 'Show or hide panels on conditions (expressions.conditions)', min: '9.4', items: () => M.byKind('condition').map(c => c.id) },
];
const cmpVer = (a, b) => { const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number); for (let i = 0; i < Math.max(x.length, y.length); i++) { const d = (x[i] || 0) - (y[i] || 0); if (d) return d; } return 0; };
// Per-viewer settings: the chosen version and any corrected minimums (browser storage, optional).
const compatState = (() => { try { return { version: '', overrides: {}, ...JSON.parse(localStorage.getItem('sdi.compat') || '{}') }; } catch { return { version: '', overrides: {} }; } })();
const saveCompat = () => { try { localStorage.setItem('sdi.compat', JSON.stringify(compatState)); } catch { /* storage unavailable: settings last for this visit */ } };
function compatRows() {
  if (M.src.classic) return [];
  return COMPAT_FEATURES.map(f => ({ ...f, min: compatState.overrides[f.key] || f.min, edited: !!compatState.overrides[f.key], used: uniq(f.items()) })).filter(r => r.used.length);
}
function compatSummary() {
  const rows = compatRows();
  if (!rows.length) return { rows, needs: null, why: [], unsupported: [] };
  const needs = rows.reduce((m, r) => cmpVer(r.min, m) > 0 ? r.min : m, '0');
  const why = rows.filter(r => r.min === needs).map(r => r.feature);
  const v = compatState.version;
  const unsupported = v && v !== 'cloud' ? rows.filter(r => cmpVer(r.min, v) > 0) : [];
  return { rows, needs, why, unsupported };
}
function viewCompat() {
  if (M.src.classic) return '<p>This is a Classic Simple XML dashboard. Classic dashboards run on every supported Splunk version, so there is nothing to check here.</p>';
  const S = compatSummary();
  const v = compatState.version;
  const status = r => !v ? '<span class="muted">—</span>' : v === 'cloud' || cmpVer(r.min, v) <= 0 ? badge('supported', 'ok') : badge('needs ' + r.min, 'sev-error');
  return `<div class="graph-controls">
    <label>Your Splunk version <select id="compat-version"><option value="">Choose…</option>${COMPAT_VERSIONS.map(x => `<option value="${x}" ${v === x ? 'selected' : ''}>Splunk Enterprise ${x}</option>`).join('')}<option value="cloud" ${v === 'cloud' ? 'selected' : ''}>Splunk Cloud Platform (current)</option></select></label>
    ${Object.keys(compatState.overrides).length ? '<button class="btn small" id="compat-reset">Reset corrected versions</button>' : ''}
  </div>
  <div class="card" style="margin-bottom:12px">
    ${S.needs ? `This dashboard needs <b>Splunk Enterprise ${esc(S.needs)} or later</b>, because it uses ${esc(S.why.join(', '))}.` : 'This dashboard uses no features that need a particular version.'}
    ${v ? (S.unsupported.length ? `<div style="margin-top:6px;color:var(--sev-error)"><b>${plural(S.unsupported.length, 'feature')} won't work on ${v === 'cloud' ? 'your version' : 'Splunk Enterprise ' + esc(v)}:</b> ${esc(S.unsupported.map(r => r.feature).join(', '))}.</div>` : `<div style="margin-top:6px;color:var(--k-viz)"><b>Everything it uses is supported on ${v === 'cloud' ? 'Splunk Cloud Platform' : 'Splunk Enterprise ' + esc(v)}.</b></div>`) : '<div class="muted small" style="margin-top:6px">Choose your version above to check it.</div>'}
  </div>
  <p class="muted small" style="margin:0 0 8px">Minimum versions are approximate, based on Splunk release notes; check "What's new in Dashboard Studio" for your version. If one is wrong for your environment, correct it in the table: corrections and your version choice are remembered in this browser.</p>
  ${table([
    { h: 'Feature', f: r => esc(r.feature) },
    { h: 'Needs', f: r => `<select data-compat-min="${r.key}" aria-label="Minimum version for ${esc(r.feature)}">${COMPAT_VERSIONS.map(x => `<option value="${x}" ${r.min === x ? 'selected' : ''}>${x}</option>`).join('')}</select>${r.edited ? ' <span class="badge" title="You changed this from the default">corrected</span>' : ''}` },
    { h: 'Used by', f: r => chips(r.used) },
    { h: 'On your version', f: status },
  ], S.rows)}`;
}

/* ============================================================
   Build the model
   ============================================================ */
function buildModel(src) {
  const def = src.def;
  const nodes = new Map(), edges = [], edgeKeys = new Set(), issues = [], usages = [];
  const node = (kind, key, props = {}) => {
    const id = kind + ':' + key;
    let n = nodes.get(id);
    if (!n) { n = { id, kind, key: String(key), label: String(key) }; nodes.set(id, n); }
    Object.assign(n, props);
    return n;
  };
  const tokenNode = name => node('token', name, { label: '$' + name + '$' });
  const mn0 = key => nodes.get('macro:' + key)?.calls || [];
  const edge = (from, to, rel, detail = '') => {
    const k = [from, to, rel, detail].join('\u0001');
    if (edgeKeys.has(k)) return;
    edgeKeys.add(k);
    edges.push({ from, to, rel, detail: String(detail) });
  };
  // `fix`, when given, is { label, apply(definition) }: a safe change offered on the Issues page.
  const issue = (severity, message, ref, fix) => issues.push({ severity, message, ref, fix });
  const byKind = k => [...nodes.values()].filter(n => n.kind === k);
  const L = isObj(def.layout) ? def.layout : {};
  const SECTION = { viz: 'visualizations', input: 'inputs', ds: 'dataSources' };

  // ---- Dashboard root
  const dash = node('dashboard', 'root', {
    label: def.title || src.xmlLabel || 'Untitled dashboard',
    description: def.description || src.xmlDescription || '',
    raw: { title: def.title, description: def.description, layoutOptions: L.layoutDefinitions ? L.options : undefined }
  });
  for (const r of src.repairs || []) issue('info', 'Repaired while loading: ' + r, dash.id);
  for (const r of src.notes || []) issue('info', r, dash.id);

  // ---- Data sources
  const dsByName = new Map();
  for (const [id, d] of Object.entries(isObj(def.dataSources) ? def.dataSources : {})) {
    const o = isObj(d?.options) ? d.options : {};
    const qp = isObj(o.queryParameters) ? o.queryParameters : null;
    node('ds', id, {
      label: d?.name || id, name: d?.name || '', type: d?.type || 'unknown',
      query: typeof o.query === 'string' ? o.query : '', extend: o.extend || '', ref: o.ref || '', app: o.app || '',
      qp, refresh: qp?.refresh ?? o.refresh ?? '', refreshType: qp?.refreshType ?? o.refreshType ?? '',
      enableSmartSources: !!o.enableSmartSources, raw: d
    });
    if (!dsByName.has(id)) dsByName.set(id, id);
    if (d?.name) dsByName.set(d.name, id);
  }
  const linkDs = (dsId, targetId, rel, key) => {
    if (typeof dsId !== 'string') return;
    if (nodes.has('ds:' + dsId)) edge('ds:' + dsId, targetId, rel, key);
    else {
      const [kind, ...rest] = targetId.split(':'), tkey = rest.join(':');
      issue('error', `References data source "${dsId}" (${key}), which does not exist.`, targetId,
        { label: `Remove the broken "${key}" data source reference`, apply: d => { const it = d[SECTION[kind]]?.[tkey]; if (it?.dataSources) { delete it.dataSources[key]; if (!Object.keys(it.dataSources).length) delete it.dataSources; } } });
    }
  };
  // Classic Simple XML search handlers (<done><set token=…>) set tokens from search results.
  for (const n of byKind('ds')) for (const st of Array.isArray(n.raw?._classicSets) ? n.raw._classicSets : []) {
    const t = tokenNode(st.token);
    edge(n.id, t.id, 'smart-source', `<${st.when}> ${st.value}`.slice(0, 80));
  }

  // chains
  for (const n of byKind('ds')) {
    if (n.type !== 'ds.chain') continue;
    if (!n.extend) issue('error', 'This chain search has no base search ("extend" is empty).', n.id);
    else if (nodes.has('ds:' + n.extend)) edge('ds:' + n.extend, n.id, 'extends');
    else issue('error', `This chain search extends "${n.extend}", which does not exist.`, n.id);
  }
  for (const n of byKind('ds')) {
    let cur = n; const path = [n]; const seen = new Set([n.id]);
    while (cur.type === 'ds.chain' && cur.extend) {
      const p = nodes.get('ds:' + cur.extend);
      if (!p) break;
      if (seen.has(p.id)) { n.cycle = true; issue('error', 'Circular chain: this search eventually extends itself.', n.id); break; }
      seen.add(p.id); path.unshift(p); cur = p;
    }
    n.depth = path.length - 1;
    n.lineage = path.map(x => x.id);
    n.rootId = path[0].id;
    n.effectiveQuery = path.map(x => x.type === 'ds.savedSearch' ? `| savedsearch "${x.ref}"` : x.query).filter(Boolean).join('\n');
  }

  // ---- Visibility conditions (expressions)
  const conds = isObj(def.expressions?.conditions) ? def.expressions.conditions : {};
  for (const [id, c] of Object.entries(conds)) node('condition', id, { label: c?.name || id, value: fmt(c?.value), raw: c });
  const applyVisibility = (n, d) => {
    const v = isObj(d?.containerOptions?.visibility) ? d.containerOptions.visibility : {};
    const parts = [];
    for (const [k, verb] of [['showConditions', 'show when'], ['hideConditions', 'hide when']]) {
      for (const c of [].concat(v[k] || [])) {
        if (typeof c !== 'string') continue;
        parts.push(`${verb} ${c}`);
        if (nodes.has('condition:' + c)) edge('condition:' + c, n.id, 'visibility', verb);
        else issue('error', `Visibility refers to condition "${c}", which is not defined in expressions.conditions.`, n.id,
          { label: `Remove "${c}" from ${k}`, apply: d => { const vv = d[SECTION[n.kind]]?.[n.key]?.containerOptions?.visibility; if (vv && Array.isArray(vv[k])) vv[k] = vv[k].filter(x => x !== c); } });
      }
    }
    if (v.hideWhenNoData) parts.push('hidden when no data');
    if (v.hideInViewMode) parts.push('hidden in view mode');
    n.visibility = parts.join('; ');
  };

  // ---- Inputs
  for (const [id, d] of Object.entries(isObj(def.inputs) ? def.inputs : {})) {
    const o = isObj(d?.options) ? d.options : {};
    const n = node('input', id, {
      label: d?.title || id, title: d?.title || '', type: d?.type || 'unknown', token: o.token || '',
      defaultValue: o.defaultValue, items: Array.isArray(o.items) ? o.items : null, raw: d
    });
    if (o.token) {
      const t = tokenNode(o.token);
      (t.defaults ||= []).push({ from: n.id, value: o.defaultValue });
      edge(n.id, t.id, 'sets', o.defaultValue !== undefined ? 'default ' + fmt(o.defaultValue) : '');
    } else issue('warning', 'This input does not set a token, so it has no effect.', n.id);
    for (const st of Array.isArray(d?._classicSets) ? d._classicSets : []) edge(n.id, tokenNode(st.token).id, 'sets', `on change: ${st.value}`.slice(0, 80));
    for (const [k, dsId] of Object.entries(isObj(d?.dataSources) ? d.dataSources : {})) linkDs(dsId, n.id, 'populates', k);
    applyVisibility(n, d);
  }

  // ---- Visualizations
  for (const [id, d] of Object.entries(isObj(def.visualizations) ? def.visualizations : {})) {
    const n = node('viz', id, { label: d?.title || id, title: d?.title || '', type: d?.type || 'unknown', drilldowns: [], builtins: [], raw: d });
    for (const [k, dsId] of Object.entries(isObj(d?.dataSources) ? d.dataSources : {})) linkDs(dsId, n.id, 'feeds', k);
    (Array.isArray(d?.eventHandlers) ? d.eventHandlers : []).forEach(h => {
      const t = h?.type || '', ho = isObj(h?.options) ? h.options : {};
      const toks = Array.isArray(ho.tokens) ? ho.tokens : [];
      if (/setToken/i.test(t)) {
        for (const tk of toks) if (tk?.token) {
          const tn = tokenNode(tk.token);
          edge(n.id, tn.id, 'drilldown-sets', tk.key ? 'from ' + tk.key : (tk.value !== undefined ? 'value ' + fmt(tk.value) : ''));
        }
        n.drilldowns.push({ type: t, text: 'Sets ' + toks.map(x => '$' + x.token + '$' + (x.key ? ' ← ' + x.key : '')).join(', ') });
      } else if (/unsetToken/i.test(t)) {
        n.drilldowns.push({ type: t, text: 'Unsets ' + toks.map(x => '$' + x.token + '$').join(', ') });
      } else if (/linkToDashboard/i.test(t)) {
        n.drilldowns.push({ type: t, text: `Opens dashboard ${ho.app ? ho.app + '/' : ''}${ho.dashboard || '?'}` + (toks.length ? ' passing ' + toks.map(x => x.token + '=' + fmt(x.value)).join(', ') : ''),
          target: ho.dashboard ? { app: ho.app || '', dashboard: String(ho.dashboard), tokens: toks.filter(x => x?.token).map(x => ({ token: x.token, value: fmt(x.value) })) } : null });
      } else if (/linkToUrl|customUrl/i.test(t)) {
        n.drilldowns.push({ type: t, text: 'Opens URL ' + fmt(ho.url), target: dashFromUrl(ho.url) });
      } else if (/linkToSearch/i.test(t)) {
        n.drilldowns.push({ type: t, text: 'Opens search' + (ho.query ? ': ' + ho.query : '') });
      } else if (/linkToReport/i.test(t)) {
        n.drilldowns.push({ type: t, text: 'Opens report ' + fmt(ho.reportName || ho.ref || ho.report || '') });
      } else if (t) n.drilldowns.push({ type: t, text: t });
    });
    applyVisibility(n, d);
  }

  // ---- Defaults
  const dflt = isObj(def.defaults) ? def.defaults : null;
  const pending = []; // token usages to attach: {nodeId, path, raw, name|smart, filters}
  if (dflt && Object.keys(dflt).length) {
    const dn = node('defaults', 'dashboard', { label: 'Dashboard defaults', raw: dflt });
    const tokDefaults = isObj(dflt.tokens?.default) ? dflt.tokens.default : {};
    for (const [t, v] of Object.entries(tokDefaults)) {
      const val = isObj(v) && 'value' in v ? v.value : v;
      const tn = tokenNode(t);
      (tn.defaults ||= []).push({ from: dn.id, value: val });
      edge(dn.id, tn.id, 'default', 'value ' + fmt(val));
    }
    const apply = (section, kind, alwaysEdge) => {
      const secs = isObj(dflt[section]) ? dflt[section] : {};
      for (const n of byKind(kind)) {
        const keys = ['global', n.type].filter(k => isObj(secs[k]));
        if (!keys.length) continue;
        let any = false;
        for (const k of keys) {
          for (const u of scanTokens(secs[k])) {
            if (getPath(n.raw, u.path) !== undefined) continue; // overridden on the item itself
            any = true;
            pending.push({ ...u, nodeId: n.id, path: `defaults.${section}.${k} → ${u.path}` });
          }
          if (kind === 'ds') n.inheritedQp = { ...(n.inheritedQp || {}), ...(secs[k]?.options?.queryParameters || {}) };
        }
        if (alwaysEdge || any) edge(dn.id, n.id, 'inherits', keys.map(k => `${section}.${k}`).join(', '));
      }
    };
    apply('dataSources', 'ds', true);
    apply('visualizations', 'viz', false);
  }

  // ---- Effective time range of each search
  for (const n of byKind('ds')) {
    const root = nodes.get(n.rootId) || n;
    const own = root.qp || {}, inh = root.inheritedQp || {};
    const pick = k => own[k] !== undefined ? { v: fmt(own[k]), src: root === n ? 'own' : 'base search' }
      : inh[k] !== undefined ? { v: fmt(inh[k]), src: 'defaults' }
      : { v: root.type === 'ds.savedSearch' ? '(report setting)' : '(Splunk default)', src: '' };
    n.earliest = pick('earliest'); n.latest = pick('latest');
  }

  // ---- Indexes and sourcetypes each search reads
  for (const n of byKind('ds')) {
    n.sources = n.type === 'ds.savedSearch'
      ? { index: [], sourcetype: [], other: ['report ' + (n.ref || '?')], lookups: [], macros: [], datamodels: [], commands: [{ name: 'savedsearch', implicit: true, sub: false, text: '' }] }
      : extractSources(n.query);
    if (hasConfig()) {
      const ex = expandForAnalysis(n);
      n.expansion = ex.info;
      if (ex.text.trim() && ex.text.trim() !== String(n.query || '').trim()) {
        n.expandedQuery = ex.text.trim();
        mergeExpanded(n.sources, extractSources(ex.text), n.type === 'ds.savedSearch' ? 'via saved search' : 'via expansion');
      }
      for (const nm of ex.info.nested) n.sources.macros.push({ key: nm.key, name: nm.key.replace(/\(\d+\)$/, ''), args: [], call: nm.call, via: 'inside `' + nm.in + '`' });
      if (CONFIG.macros.size) for (const m of ex.info.missing) {
        const argc = +(m.key.match(/\((\d+)\)$/)?.[1] || 0);
        if (m.other.length) issue('error', `SPL: macro \`${m.key}\` is called with ${plural(argc, 'argument')}, but macros.conf only defines ${m.other.map(k => '`' + k + '`').join(', ')}.`, n.id);
        else issue('info', `Macro \`${m.key}\` isn't in the pasted macros.conf, so it wasn't expanded.`, n.id);
      }
      for (const k of ex.info.loops) issue('error', `SPL: macro \`${k}\` expands into itself.`, n.id);
      for (const k of ex.info.evalMacros) issue('info', `Macro \`${k}\` is an eval-based macro. Its SPL is computed when the search runs, so it can't be expanded here.`, n.id);
      for (const r of ex.info.savedMissing) issue('info', `Saved search "${r}" isn't in the pasted savedsearches.conf.`, n.id);
      for (const r of ex.info.datasetMissing) issue('info', `Dataset ${r} isn't in the pasted data model JSON.`, n.id);
    }
    if (n.type !== 'ds.savedSearch') for (const l of lintSpl(n.query, n.type === 'ds.chain'))
      issue(l.severity, l.message, n.id, l.fix ? { label: l.fixLabel, apply: d => { const o = d.dataSources?.[n.key]?.options; if (o && typeof o.query === 'string') o.query = l.fix(o.query); } } : undefined);
    for (const mc of n.sources.macros) {
      const mn = node('macro', mc.key, { label: '`' + mc.key + '`', name: mc.name, arity: mc.args.length || +(mc.key.match(/\((\d+)\)$/)?.[1] || 0), calls: mn0(mc.key) });
      if (!mn.calls.includes(mc.call)) mn.calls.push(mc.call);
      mn.config = CONFIG.macros.get(mc.key) || null;
      edge(mn.id, n.id, 'macro-used', mc.via || mc.call);
    }
    for (const dm of n.sources.datamodels) {
      if (dm.model.includes('$')) continue;
      const dn = node('datamodel', dm.model, { label: dm.model });
      (dn.datasets ||= new Set());
      if (dm.dataset) dn.datasets.add(dm.dataset);
      dn.config = CONFIG.datamodels.get(dm.model) || null;
      edge(dn.id, n.id, 'datamodel-read', [dm.dataset, dm.command, dm.via].filter(Boolean).join(' · '));
    }
    const counts = new Map();
    for (const c of n.sources.commands) counts.set(c.name, (counts.get(c.name) || 0) + 1);
    for (const [name, count] of counts) {
      const cn = node('command', name, { label: name, category: CMD_CATEGORY[name] || 'Other' });
      cn.uses = (cn.uses || 0) + count;
      const sub = n.sources.commands.some(c => c.name === name && c.sub);
      const via = n.sources.commands.find(c => c.name === name)?.via;
      edge(cn.id, n.id, 'command-used', [count > 1 ? '×' + count : '', sub ? 'in subsearch' : '', via || ''].filter(Boolean).join(', '));
      if (SIDE_EFFECT.has(name)) issue('warning', `This search runs | ${name}, which writes data or sends something every time the search runs (each dashboard load, input change and refresh).`, n.id);
    }
    for (const lk of n.sources.lookups) {
      if (lk.name.includes('$')) continue; // lookup name comes from a token
      const ln = node('lookup', lk.name, { label: lk.name });
      (ln.access ||= new Set()).add(lk.mode);
      if (lk.mode === 'read') edge(ln.id, n.id, 'lookup-read', lk.command + (lk.via ? ' · ' + lk.via : ''));
      else {
        edge(n.id, ln.id, 'lookup-write', lk.command + (lk.options ? ' ' + lk.options : '') + (lk.via ? ' · ' + lk.via : ''));
        issue('info', `This search writes to lookup "${lk.name}" (${lk.command}${/append\s*=\s*t/i.test(lk.options) ? ', append' : ', overwrite'}) every time it runs: on each dashboard load, input change and refresh.`, n.id);
      }
    }
    for (const field of ['index', 'sourcetype']) for (const v of n.sources[field]) {
      if (v.value.includes('$')) continue; // value comes from a token; shown on the search, not as an item
      const sn = node(field, v.value, { label: v.value });
      edge(sn.id, n.id, 'searches', [v.excluded ? 'excluded' : '', v.via || ''].filter(Boolean).join(', '));
    }
  }
  // A chain search reads whatever its base searches read.
  for (const n of byKind('ds')) {
    for (const field of ['index', 'sourcetype']) {
      const seen = new Set();
      n['eff_' + field] = n.lineage.flatMap(id => (nodes.get(id).sources?.[field] || []).map(v => ({ ...v, inherited: id !== n.id, from: id })))
        .filter(v => { const k = v.value + '|' + v.excluded; if (seen.has(k)) return false; seen.add(k); return true; });
    }
    n.eff_other = uniq(n.lineage.flatMap(id => nodes.get(id).sources?.other || []));
    n.eff_macros = n.lineage.flatMap(id => (nodes.get(id).sources?.macros || []).map(x => ({ ...x, inherited: id !== n.id })));
    n.eff_datamodels = n.lineage.flatMap(id => (nodes.get(id).sources?.datamodels || []).map(x => ({ ...x, inherited: id !== n.id })));
    // A chain inherits what its base searches read from lookups, but not their writes.
    n.eff_lookups = n.lineage.flatMap(id => (nodes.get(id).sources?.lookups || []).filter(l => id === n.id || l.mode === 'read').map(l => ({ ...l, inherited: id !== n.id })));
    if (n.type === 'ds.search' && !n.sources.index.length && !n.sources.other.length && !n.sources.macros.length && !n.sources.datamodels.length && n.query && !/^\s*\|/.test(n.query))
      issue('info', 'This search names no index, so it runs against the default indexes of whoever views the dashboard.', n.id);
  }

  // ---- Layout: tabs / canvases
  const tabsDef = [];
  const hasTabBar = Array.isArray(L.tabs?.items) && L.tabs.items.length > 0;
  if (isObj(L.layoutDefinitions)) {
    const order = (hasTabBar ? L.tabs.items : []).map(t => ({ id: t?.layoutId, label: t?.label }));
    for (const k of Object.keys(L.layoutDefinitions)) if (!order.some(o => o.id === k)) order.push({ id: k, label: k });
    for (const t of order) {
      const ld = L.layoutDefinitions[t.id];
      if (!isObj(ld)) { issue('error', `Tab "${t.label || t.id}" points to layout "${t.id}", which does not exist.`, dash.id); continue; }
      tabsDef.push({ key: t.id, label: t.label || t.id, def: ld, raw: ld });
    }
  } else if (Array.isArray(L.structure) || L.type) {
    tabsDef.push({ key: 'main', label: 'Main canvas', def: L, raw: { type: L.type, options: L.options, structure: L.structure } });
  }
  const placeItem = (b, tn) => {
    const id = b?.item;
    if (typeof id !== 'string') return;
    const target = nodes.get('viz:' + id) || nodes.get('input:' + id);
    if (target) {
      const p = b.position;
      edge(target.id, tn.id, 'contains', p && p.x !== undefined ? `x${p.x} y${p.y} ${p.w}×${p.h}` : '');
      (tn.items ||= []).push({ id: target.id, type: b.type, position: isObj(p) ? p : null });
    } else if (b.type !== 'line') issue('warning', `Layout "${tn.label}" places "${id}", which is not a defined visualization or input.`, tn.id, {
      label: `Remove "${id}" from the layout`, apply: d => {
        const LL = d.layout || {};
        if (tn.key === '__global__') LL.globalInputs = (LL.globalInputs || []).filter(x => x !== id);
        else { const tgt = LL.layoutDefinitions?.[tn.key] || LL; if (Array.isArray(tgt.structure)) tgt.structure = tgt.structure.filter(x => x?.item !== id); }
      }
    });
  };
  if (Array.isArray(L.globalInputs) && L.globalInputs.length) {
    const g = node('tab', '__global__', { label: 'Global inputs', layoutType: 'input bar (all tabs)', order: -1, global: true, raw: { globalInputs: L.globalInputs } });
    edge(g.id, dash.id, 'contains');
    for (const id of L.globalInputs) placeItem({ item: id, type: 'input' }, g);
  }
  tabsDef.forEach((t, i) => {
    const tn = node('tab', t.key, { label: t.label, layoutType: t.def.type || L.type || '', order: i, isTab: hasTabBar, options: isObj(t.def.options) ? t.def.options : {}, raw: t.raw });
    edge(tn.id, dash.id, 'contains');
    for (const b of Array.isArray(t.def.structure) ? t.def.structure : []) placeItem(b, tn);
  });

  // ---- Scan every item for token references
  for (const n of [...nodes.values()]) {
    if (n.kind === 'token' || !n.raw) continue;
    let obj = n.raw;
    if (n.kind === 'viz' && isObj(obj)) { const { dataSources, ...rest } = obj; obj = rest; }
    if (n.kind === 'tab' && isObj(obj)) { const { structure, ...rest } = obj; obj = rest; }
    for (const u of scanTokens(obj)) pending.push({ ...u, nodeId: n.id });
  }
  const defining = new Set(edges.filter(e => ['sets', 'drilldown-sets', 'default', 'smart-source'].includes(e.rel) && e.to.startsWith('token:')).map(e => e.to.slice(6)));
  const resolve = name => {
    if (defining.has(name)) return { key: name, prop: '' };
    const stripped = name.startsWith('form.') ? name.slice(5) : name;
    if (defining.has(stripped)) return { key: stripped, prop: '' };
    const i = stripped.lastIndexOf('.');
    if (i > 0 && defining.has(stripped.slice(0, i))) return { key: stripped.slice(0, i), prop: stripped.slice(i + 1) };
    return { key: stripped, prop: '' };
  };
  for (const u of pending) {
    const owner = nodes.get(u.nodeId);
    if (u.smart) {
      const dsId = dsByName.get(u.smart.ds);
      const key = `${u.smart.ds}:${u.smart.prop}`;
      const tn = tokenNode(key);
      tn.subtype = 'smart';
      if (dsId) {
        edge('ds:' + dsId, tn.id, 'smart-source', u.smart.prop);
        const dsn = nodes.get('ds:' + dsId);
        if (!dsn.enableSmartSources && !tn._warned) {
          tn._warned = true;
          issue('warning', `Smart-source token ${u.raw} reads from "${u.smart.ds}", but that data source does not set "enableSmartSources": true.`, tn.id,
            { label: `Turn on enableSmartSources for "${u.smart.ds}"`, apply: d => { const o = (d.dataSources?.[dsId] && (d.dataSources[dsId].options ||= {})); if (o) o.enableSmartSources = true; } });
        }
      } else issue('error', `Smart-source token ${u.raw} names data source "${u.smart.ds}", which does not exist.`, tn.id);
      edge(tn.id, u.nodeId, 'uses-token', u.path);
      usages.push({ token: tn.id, node: u.nodeId, path: u.path, raw: u.raw });
      continue;
    }
    if (/_classicSets/.test(u.path) && /^(value|label|earliest|latest|result\.|job\.|row\.|click\.)/.test(u.name)) continue;
    if (owner.kind === 'viz' && /(^|\.)eventHandlers/.test(u.path) && DRILL_BUILTIN.test(u.name)) {
      owner.builtins.push(u.raw);
      continue;
    }
    const r = resolve(u.name);
    const tn = tokenNode(r.key);
    if (r.key.startsWith('env:')) tn.subtype = 'env';
    edge(tn.id, u.nodeId, 'uses-token', u.path + (r.prop ? ` (.${r.prop})` : ''));
    usages.push({ token: tn.id, node: u.nodeId, path: u.path, raw: u.raw, prop: r.prop, filters: u.filters });
  }

  // ---- Lookups written and read by the same dashboard
  for (const ln of byKind('lookup')) {
    ln.accessLabel = ln.access.size === 2 ? 'read & write' : [...ln.access][0];
    const writers = edges.filter(e => e.rel === 'lookup-write' && e.to === ln.id).map(e => nodes.get(e.from).label);
    const readers = edges.filter(e => e.rel === 'lookup-read' && e.from === ln.id).map(e => nodes.get(e.to).label);
    if (writers.length && readers.length)
      issue('info', `Lookup "${ln.label}" is written by ${writers.join(', ')} and read by ${readers.join(', ')}. Dashboard searches run in parallel, so a reader may see the lookup before or after the write.`, ln.id);
  }

  // ---- Adjacency
  const outE = new Map(), inE = new Map();
  for (const n of nodes.keys()) { outE.set(n, []); inE.set(n, []); }
  for (const e of edges) { outE.get(e.from)?.push(e); inE.get(e.to)?.push(e); }

  // ---- Token status
  for (const t of byKind('token')) {
    const setters = inE.get(t.id).filter(e => ['sets', 'drilldown-sets', 'default', 'smart-source'].includes(e.rel));
    const users = outE.get(t.id).filter(e => e.rel === 'uses-token');
    if (t.subtype === 'env') t.status = 'Splunk environment';
    else if (t.subtype === 'smart') t.status = 'Smart source';
    else if (setters.length) t.status = 'Defined';
    else { t.status = 'Undefined'; issue('warning', `Token ${t.label} is used but never set by an input, a drilldown or a default value.`, t.id); }
    if (t.status === 'Defined' && !users.length) issue('info', `Token ${t.label} is set but never used.`, t.id);
    const inputSetters = setters.filter(e => e.rel === 'sets');
    if (inputSetters.length > 1) issue('info', `Token ${t.label} is set by ${inputSetters.length} inputs (${inputSetters.map(e => e.from.slice(6)).join(', ')}).`, t.id);
  }

  // ---- Structural checks
  const placed = id => outE.get(id).some(e => e.rel === 'contains');
  const hasLayout = tabsDef.length > 0 || nodes.has('tab:__global__');
  for (const n of byKind('ds')) {
    if (!outE.get(n.id).some(e => ['feeds', 'extends', 'populates', 'smart-source'].includes(e.rel)))
      issue('warning', 'This data source is not used by any visualization, input or chain search.', n.id,
        { label: 'Remove this unused data source', apply: d => { delete d.dataSources?.[n.key]; } });
  }
  if (hasLayout) {
    const fc = tabsDef[0];
    for (const n of byKind('viz')) if (!placed(n.id)) issue('warning', 'This visualization is defined but not placed on any tab or canvas, so it is never shown.', n.id, fc ? {
      label: `Place it at the bottom of "${fc.label}"`, apply: d => {
        const LL = (d.layout ||= {}), tgt = LL.layoutDefinitions?.[fc.key] || LL;
        tgt.structure ||= [];
        const maxY = Math.max(0, ...tgt.structure.map(b => (Number(b?.position?.y) || 0) + (Number(b?.position?.h) || 0)));
        tgt.structure.push({ item: n.key, type: 'block', position: { x: 0, y: maxY, w: Math.min(1200, Number(tgt.options?.width) || 1200), h: 300 } });
      }
    } : undefined);
    for (const n of byKind('input')) if (!placed(n.id)) issue('warning', 'This input is defined but not placed on any tab or in the global input bar, so it is never shown.', n.id,
      { label: 'Add it to the global input bar', apply: d => { const LL = (d.layout ||= {}); LL.globalInputs ||= []; if (!LL.globalInputs.includes(n.key)) LL.globalInputs.push(n.key); } });
  }
  for (const n of byKind('tab')) if (!inE.get(n.id).some(e => e.rel === 'contains')) issue('info', `Tab "${n.label}" is empty.`, n.id);

  // ---- Definition checks (Studio definitions only; Classic ones are generated by the converter)
  if (!src.classic) checkDefinition(def, issue, new Set(nodes.keys()));

  // ---- Behaviour checks: valid dashboards that don't do what you'd expect
  const mainCmds = n => (n.sources?.commands || []).filter(c => !c.sub && !c.via);
  const firstCmd = n => mainCmds(n)[0]?.name;
  const timeToks = n => uniq((`${n.earliest?.v || ''} ${n.latest?.v || ''}`.match(/\$[^$\s|.]+/g) || []).map(x => x.slice(1)));
  const ignoresTime = n => n.type === 'ds.search' && NO_EVENT_TIME.has(firstCmd(n));
  for (const n of byKind('ds')) if (n.depth === 0 && timeToks(n).length && ignoresTime(n))
    issue('warning', `The time range ($${timeToks(n).join('$, $')}$) has no effect on this search: it starts with | ${firstCmd(n)}, which doesn't filter by event time.`, n.id);
  for (const inp of byKind('input')) {
    if (shortType(inp.type) !== 'timerange' || !inp.token) continue;
    const users = byKind('ds').filter(n => n.depth === 0 && timeToks(n).includes(inp.token));
    if (users.length && users.every(ignoresTime))
      issue('warning', `This time picker has no effect: every search that uses $${inp.token}$ (${users.map(u => u.label).join(', ')}) starts with a command that doesn't filter by event time, such as | inputlookup.`, inp.id);
  }
  for (const v of byKind('viz')) {
    if (!/singlevalue/i.test(v.type)) continue;
    const o = isObj(v.raw?.options) ? v.raw.options : {};
    const wants = Object.entries(o).some(([k, val]) => (/trend/i.test(k) && !(/display/i.test(k) && val === 'off')) || (k === 'sparklineDisplay' && val !== 'off'));
    const feed = (inE.get(v.id) || []).find(e => e.rel === 'feeds');
    if (!wants || !feed) continue;
    const cmds = nodes.get(feed.from).lineage.flatMap(id => mainCmds(nodes.get(id)));
    const lastT = [...cmds].reverse().find(c => TRANSFORMING.has(c.name));
    if (lastT && lastT.name !== 'timechart' && !/\b_time\b/.test(lastT.text || ''))
      issue('warning', `This single value is set up to show a trend or sparkline, but its search ends with | ${lastT.name} without _time, so there is no time series to compare. Use | timechart (or split by _time) to get a trend.`, v.id);
  }
  const groupBy = (list, keyOf) => { const g = new Map(); for (const x of list) { const k = keyOf(x); if (k) (g.get(k) || g.set(k, []).get(k)).push(x); } return [...g.values()].filter(a => a.length > 1); };
  // Key order and empty fields don't make panels different.
  const stable = v => Array.isArray(v) ? '[' + v.map(stable).join(',') + ']'
    : isObj(v) ? '{' + Object.keys(v).filter(k => v[k] !== '' && v[k] !== undefined).sort().map(k => JSON.stringify(k) + ':' + stable(v[k])).join(',') + '}' : JSON.stringify(v);
  for (const g of groupBy(byKind('viz'), v => v.raw ? stable([v.type, v.title, v.raw.dataSources || {}, v.raw.options || {}, v.raw.context || {}]) : ''))
    for (const v of g) issue('info', `This panel is identical to ${g.filter(x => x !== v).map(x => x.key).join(', ')} (same type, title, data source and options).`, v.id);
  for (const g of groupBy(byKind('ds'), n => n.effectiveQuery ? [n.effectiveQuery.replace(/\s+/g, ' ').trim(), n.earliest?.v, n.latest?.v].join('\u0001') : ''))
    for (const n of g) issue('info', `Runs the same SPL and time range as ${g.filter(x => x !== n).map(x => x.label).join(', ')}. The panels could share one data source.`, n.id);
  const NON_EVENT = new Set([...NO_EVENT_TIME, 'tstats', 'mstats', 'mcatalog', 'datamodel', 'pivot', 'savedsearch', 'loadjob', 'metadata', 'dbinspect', 'eventcount', 'from']);
  for (const n of byKind('ds')) {
    if (n.depth !== 0 || n.type !== 'ds.search' || !(outE.get(n.id) || []).some(e => e.rel === 'extends')) continue;
    const cmds = mainCmds(n);
    if (NON_EVENT.has(cmds[0]?.name) || cmds.some(c => TRANSFORMING.has(c.name) || c.name === 'fields' || c.name === 'table')) continue;
    issue('warning', 'This base search passes raw events, with every field, to its chain searches. Splunk keeps a limited number of events for chain searches (500,000 by default), so chains can work on incomplete results and run slowly. End it with | fields and the fields the chains need, or with a transforming command such as | stats.', n.id);
  }

  const order = { error: 0, warning: 1, info: 2 };
  issues.sort((a, b) => order[a.severity] - order[b.severity]);

  const maxDepth = Math.max(0, ...byKind('ds').map(n => n.depth || 0));
  return {
    title: dash.label, description: dash.description, format: src.format,
    layoutSummary: hasTabBar ? `${tabsDef.length} tabs` : (tabsDef.length ? `single ${tabsDef[0].def.type || ''} canvas`.replace('  ', ' ') : 'no layout'),
    nodes, edges, issues, usages, outE, inE, maxDepth, byKind, src
  };
}

/* ============================================================
   Graph traversal
   ============================================================ */
function closure(start, dir, allowed) {
  const seen = new Set();
  const stack = [start];
  while (stack.length) {
    const id = stack.pop();
    for (const e of (dir === 'up' ? M.inE : M.outE).get(id) || []) {
      const nxt = dir === 'up' ? e.from : e.to;
      if (allowed && !allowed.has(nxt)) continue;
      if (!seen.has(nxt) && nxt !== start) { seen.add(nxt); stack.push(nxt); }
    }
  }
  return seen;
}
// Tokens whose value changes this item: walk upstream through searches, chains, defaults and conditions,
// but stop at each token reached (what sets that token is a separate concern).
function tokensAffecting(id) {
  const found = new Set(), seen = new Set([id]), stack = [id];
  while (stack.length) {
    for (const e of M.inE.get(stack.pop()) || []) {
      if (e.rel === 'contains' || e.rel === 'inherits' || e.rel === 'lookup-write' || e.rel === 'command-used' || seen.has(e.from)) continue;
      seen.add(e.from);
      if (e.from.startsWith('token:')) found.add(e.from); else stack.push(e.from);
    }
  }
  return [...found];
}

/* ============================================================
   Rendering helpers
   ============================================================ */
let M = null;
let view = 'overview';
// mode: 'focus' (one item and its lineage) or 'all'; layout: 'columns' or 'elk'
const graphState = {
  mode: 'focus', center: null, depth: 3, layout: 'columns', focus: '', tokens: true, sources: true, commands: false, selected: null,
  hubMin: 4, collapse: { tabs: false, chains: false, sources: false, commands: false }, toggled: new Map(),
  zoom: 1, overlay: false, pathFrom: null, pathTo: null,
};

function chip(id, detail) {
  const n = M.nodes.get(id);
  if (!n) return `<span class="chip missing">${esc(id)}</span>`;
  const label = n.kind === 'token' ? n.label : n.label;
  const tip = `${KINDS[n.kind].label}: ${n.kind === 'token' ? n.label : n.key}${n.label !== n.key && n.kind !== 'token' ? ' (' + n.label + ')' : ''}`;
  return `<button class="chip k-${n.kind}" data-id="${esc(id)}" title="${esc(tip)}">${esc(label)}${detail ? ` <span class="det">${esc(detail)}</span>` : ''}</button>`;
}
const chips = (ids, empty = '<span class="muted">—</span>') => ids.length ? `<div class="stack">${ids.map(x => Array.isArray(x) ? chip(x[0], x[1]) : chip(x)).join('')}</div>` : empty;
const badge = (t, cls = '') => `<span class="badge ${cls}">${esc(t)}</span>`;
const sevBadge = s => badge(s, 'sev-' + s);
const outs = (id, rels) => (M.outE.get(id) || []).filter(e => !rels || rels.includes(e.rel));
const ins = (id, rels) => (M.inE.get(id) || []).filter(e => !rels || rels.includes(e.rel));
const tabsOf = id => uniq(outs(id, ['contains']).map(e => e.to));
const directTokens = id => uniq(ins(id, ['uses-token']).map(e => e.from));
const issuesFor = id => M.issues.filter(i => i.ref === id);
const issueMark = id => {
  const list = issuesFor(id);
  if (!list.length) return '';
  const worst = list[0].severity;
  return ` <span class="badge sev-${worst}" title="${esc(list.map(i => i.message).join('\n'))}">${list.length} ${list.length === 1 ? 'issue' : 'issues'}</span>`;
};

function table(cols, rows) {
  if (!rows.length) return `<p class="muted">None in this dashboard.</p>`;
  return `<div class="tablewrap"><table><thead><tr>${cols.map(c => `<th scope="col">${esc(c.h)}</th>`).join('')}</tr></thead><tbody>` +
    rows.map(r => `<tr class="filterable">${cols.map(c => `<td class="${c.cls || ''}">${c.f(r)}</td>`).join('')}</tr>`).join('') +
    `</tbody></table></div>`;
}
function dsLineage(dsId) {
  const n = M.nodes.get(dsId);
  if (!n) return chip(dsId);
  return `<span class="lineage">${n.lineage.map(x => chip(x)).join('<span class="sep">›</span>')}</span>`;
}
function timeRange(n) {
  const e = n.earliest, l = n.latest;
  if (!e) return '';
  const src = uniq([e.src, l.src].filter(Boolean));
  return `<code>${esc(e.v)}</code> → <code>${esc(l.v)}</code>${src.length ? `<div class="muted small">from ${esc(src.join(' / '))}</div>` : ''}`;
}

/* ============================================================
   Views
   ============================================================ */
const VIEWS = [
  { id: 'app', label: 'All dashboards', when: () => DASH.length > 1, count: () => DASH.length },
  { id: 'overview', label: 'Overview' },
  { id: 'mockup', label: 'Dashboard mockup' },
  { sep: 'Inventory' },
  { id: 'inventory', label: 'All items', count: () => invItems().length },
  { id: 'tabs', label: 'Tabs & layout', kind: 'tab' },
  { id: 'inputs', label: 'Inputs', kind: 'input' },
  { id: 'datasources', label: 'Data sources & searches', kind: 'ds' },
  { id: 'sources', label: 'Indexes & sourcetypes', kinds: ['index', 'sourcetype'] },
  { id: 'lookups', label: 'Lookups', kind: 'lookup' },
  { id: 'datamodels', label: 'Data models', kind: 'datamodel' },
  { id: 'macros', label: 'Macros', kind: 'macro' },
  { id: 'commands', label: 'SPL commands', kind: 'command' },
  { id: 'visualizations', label: 'Visualizations', kind: 'viz' },
  { id: 'tokens', label: 'Tokens', kind: 'token' },
  { id: 'conditions', label: 'Visibility conditions', kind: 'condition', hideEmpty: true },
  { sep: 'Relationships' },
  { id: 'graph', label: 'Relationship map' },
  { id: 'tokenmatrix', label: 'Token matrix', count: () => M.byKind('token').length || '' },
  { id: 'dataflow', label: 'Data flow (Sankey)' },
  { id: 'relationships', label: 'Relationship list' },
  { sep: 'Checks and tools' },
  { id: 'issues', label: 'Issues' },
  { id: 'recommendations', label: 'Recommendations', count: () => recommendations().length },
  { id: 'compat', label: 'Splunk version', count: () => compatSummary().unsupported.length || '' },
  { id: 'compare', label: 'Compare versions' },
  { id: 'config', label: 'Splunk config', count: () => CONFIG.macros.size + CONFIG.saved.size + CONFIG.datamodels.size || '' },
];

function renderNav() {
  $('#nav').innerHTML = VIEWS.map(v => {
    if (v.sep) return `<hr><div class="navlabel">${esc(v.sep)}</div>`;
    if (v.when && !v.when()) return '';
    let count = v.count ? v.count() : '';
    if (v.kinds) count = v.kinds.reduce((a, k) => a + M.byKind(k).length, 0);
    else if (v.kind) {
      const c = M.byKind(v.kind).length;
      if (v.hideEmpty && !c) return '';
      count = c;
    } else if (v.id === 'relationships') count = M.edges.length;
    else if (v.id === 'issues') count = M.issues.length;
    const alert = v.id === 'issues' && M.issues.some(i => i.severity !== 'info');
    return `<button data-view="${v.id}" ${view === v.id ? 'aria-current="page"' : ''}><span>${esc(v.label)}</span><span class="count ${alert ? 'alert' : ''}">${count}</span></button>`;
  }).join('');
}

function render() {
  renderNav();
  if (!VIEWS.some(x => x.id === view && (!x.when || x.when()))) view = 'overview';
  const v = VIEWS.find(x => x.id === view);
  $('#view-title').textContent = v.label;
  const root = $('#view');
  root.innerHTML = ({
    overview: viewOverview, mockup: viewMockup, tabs: viewTabs, inputs: viewInputs, datasources: viewDataSources,
    visualizations: viewVisualizations, tokens: viewTokens, conditions: viewConditions, sources: viewSources, lookups: viewLookups, datamodels: viewDatamodels, macros: viewMacros, commands: viewCommands,
    graph: () => '', relationships: viewRelationships, issues: viewIssues,
    app: viewApp, compare: viewCompare, config: viewConfig, inventory: viewInventory, recommendations: viewRecommendations, tokenmatrix: viewTokenMatrix, dataflow: viewDataFlow, compat: viewCompat
  })[view]();
  if (view === 'graph') renderGraph(root);
  applyFilter();
}

function viewOverview() {
  const ds = M.byKind('ds');
  const nType = t => ds.filter(n => n.type === t).length;
  const tokens = M.byKind('token');
  const undef = tokens.filter(t => t.status === 'Undefined').length;
  const sev = s => M.issues.filter(i => i.severity === s).length;
  const tabs = M.byKind('tab').filter(t => !t.global);
  const otherDs = ds.length - nType('ds.search') - nType('ds.chain') - nType('ds.savedSearch');
  const stat = (v, k, n, l, s) => `<button class="stat k-${k}" style="--kc: var(--k-${k})" data-view="${v}"><div class="n">${n}</div><div class="l">${esc(l)}</div><div class="s">${s}</div></button>`;
  return `
  <div class="card">
    <dl class="meta-grid">
      <dt>Title</dt><dd><b>${esc(M.title)}</b></dd>
      ${M.description ? `<dt>Description</dt><dd>${esc(M.description)}</dd>` : ''}
      <dt>Layout</dt><dd>${esc(M.layoutSummary)}</dd>
      <dt>Source</dt><dd>${esc(M.format)}</dd>
      <dt>Relationships</dt><dd>${M.edges.length} connections between ${M.nodes.size - 1} items</dd>
      ${(() => { const c = compatSummary(); return c.needs ? `<dt>Needs</dt><dd>Splunk Enterprise ${esc(c.needs)} or later (approximately; for ${esc(c.why.join(', '))})${c.unsupported.length ? ` · <b style="color:var(--sev-error)">${plural(c.unsupported.length, 'feature')} not supported on your version</b>` : ''} <button class="btn small" data-view="compat">Check</button></dd>` : ''; })()}
      ${hasConfig() ? `<dt>Splunk config</dt><dd>${plural(CONFIG.macros.size, 'macro')}, ${plural(CONFIG.saved.size, 'saved search', 'saved searches')} and ${plural(CONFIG.datamodels.size, 'data model')} loaded and expanded</dd>` : ''}
    </dl>
    ${(M.src.repairs || []).length || (M.src.notes || []).length ? `<div class="notes"><b>While loading:</b><ul>${[...(M.src.repairs || []).map(r => 'Repaired: ' + r), ...(M.src.notes || [])].map(r => `<li>${esc(r)}</li>`).join('')}</ul>${(M.src.repairs || []).length ? '<button class="btn small" data-view="issues">Download the clean definition from the Issues page</button>' : ''}</div>` : ''}
  </div>
  <div class="stats">
    ${stat('tabs', 'tab', tabs.length, 'Tabs', tabs.map(t => esc(t.label)).join(' · ') || '—')}
    ${stat('inputs', 'input', M.byKind('input').length, 'Inputs', esc(uniq(M.byKind('input').map(n => shortType(n.type))).join(', ') || '—'))}
    ${stat('datasources', 'ds', ds.length, 'Data sources', `${plural(nType('ds.search'), 'search', 'searches')} · ${plural(nType('ds.chain'), 'chain')} · ${plural(nType('ds.savedSearch'), 'saved search', 'saved searches')}${otherDs ? ` · ${otherDs} other` : ''}`)}
    ${stat('sources', 'index', M.byKind('index').length, 'Indexes', esc(M.byKind('index').map(n => n.label).join(', ') || 'none named in SPL'))}
    ${stat('sources', 'sourcetype', M.byKind('sourcetype').length, 'Sourcetypes', esc(M.byKind('sourcetype').map(n => n.label).join(', ') || 'none named in SPL'))}
    ${stat('lookups', 'lookup', M.byKind('lookup').length, 'Lookups', M.byKind('lookup').length ? `${M.byKind('lookup').filter(l => l.access.has('read')).length} read · ${M.byKind('lookup').filter(l => l.access.has('write')).length} written` : 'none in SPL')}
    ${stat('datamodels', 'datamodel', M.byKind('datamodel').length, 'Data models', esc(M.byKind('datamodel').map(n => n.label).join(', ') || 'none in SPL'))}
    ${stat('macros', 'macro', M.byKind('macro').length, 'Macros', esc(M.byKind('macro').map(n => n.key).join(', ') || 'none in SPL'))}
    ${stat('commands', 'command', M.byKind('command').length, 'SPL commands', esc(M.byKind('command').sort((a, b) => b.uses - a.uses).slice(0, 6).map(n => n.label).join(', ') || '—'))}
    ${stat('visualizations', 'viz', M.byKind('viz').length, 'Visualizations', esc(uniq(M.byKind('viz').map(n => shortType(n.type))).join(', ') || '—'))}
    ${stat('tokens', 'token', tokens.length, 'Tokens', `${tokens.filter(t => t.status === 'Defined').length} defined${undef ? ` · <b style="color:var(--sev-warning)">${undef} undefined</b>` : ''}`)}
    ${M.byKind('condition').length ? stat('conditions', 'condition', M.byKind('condition').length, 'Conditions', 'show / hide rules') : ''}
    <button class="stat" style="--kc: var(--sev-${sev('error') ? 'error' : sev('warning') ? 'warning' : 'info'})" data-view="issues"><div class="n">${M.issues.length}</div><div class="l">Issues</div><div class="s">${plural(sev('error'), 'error')} · ${plural(sev('warning'), 'warning')} · ${plural(sev('info'), 'note')}</div></button>
    ${(() => { const rc = recommendations(), hi = rc.filter(r => r.impact === 'High').length; return `<button class="stat" style="--kc: var(--accent)" data-view="recommendations"><div class="n">${rc.length}</div><div class="l">Recommendations</div><div class="s">${hi ? `<b>${hi} high impact</b> · ` : ''}optimisations and best practice</div></button>`; })()}
  </div>
  ${M.issues.length ? `<div class="section-title">Top issues</div>${issueTable(M.issues.slice(0, 8))}` : ''}
  ${dashLinks(CUR_I).length ? `<div class="section-title">Opens other dashboards</div>${linksTable(dashLinks(CUR_I), false)}` : ''}
  <div class="section-title">Search lineage</div>
  <div class="card">${dsTree()}</div>`;
}

function viewTabs() {
  const tabs = M.byKind('tab').sort((a, b) => a.order - b.order);
  if (!tabs.length) return '<p class="muted">This dashboard has no layout definition.</p>';
  return tabs.map(t => {
    const items = ins(t.id, ['contains']);
    const inputs = items.filter(e => e.from.startsWith('input:'));
    const viz = items.filter(e => e.from.startsWith('viz:'));
    const vizRows = viz.map(e => M.nodes.get(e.from));
    return `<div class="card tabcard filterable">
      <h3>${chip(t.id)} ${badge(t.global ? 'shown on every tab' : (t.isTab ? 'tab' : 'canvas'))} ${t.layoutType ? badge(t.layoutType) : ''}${issueMark(t.id)}</h3>
      <div class="sub">${plural(inputs.length, 'input')} · ${plural(viz.length, 'visualization')} · layout id <code>${esc(t.key)}</code></div>
      ${inputs.length ? `<div class="relgroup"><div class="rl">Inputs</div>${chips(inputs.map(e => [e.from, M.nodes.get(e.from).token ? '$' + M.nodes.get(e.from).token + '$' : '']))}</div>` : ''}
      ${vizRows.length ? table([
        { h: 'Visualization', f: n => chip(n.id) + issueMark(n.id) },
        { h: 'Type', f: n => esc(shortType(n.type)) },
        { h: 'Data source lineage', f: n => outsIn(n.id) },
        { h: 'Driven by tokens', f: n => chips(tokensAffecting(n.id)) },
      ], vizRows) : ''}
    </div>`;
  }).join('');
}
function outsIn(vizId) {
  const list = ins(vizId, ['feeds']);
  if (!list.length) return '<span class="muted">static (no data source)</span>';
  return list.map(e => `<div>${dsLineage(e.from)}${list.length > 1 ? ` <span class="muted small">${esc(e.detail)}</span>` : ''}</div>`).join('');
}

function viewInputs() {
  return table([
    { h: 'Input', f: n => chip(n.id) + issueMark(n.id) },
    { h: 'ID', f: n => `<code>${esc(n.key)}</code>` },
    { h: 'Type', f: n => esc(shortType(n.type)) },
    { h: 'Sets token', f: n => n.token ? chip('token:' + n.token) : '<span class="muted">—</span>' },
    { h: 'Default', f: n => n.defaultValue !== undefined ? `<code>${esc(fmt(n.defaultValue))}</code>` : '<span class="muted">—</span>' },
    { h: 'Options from', f: n => {
        const d = ins(n.id, ['populates']).map(e => e.from);
        const parts = [];
        if (d.length) parts.push(d.map(x => dsLineage(x)).join(' '));
        if (n.items) parts.push(`<span class="muted small">${plural(n.items.length, 'static option')}</span>`);
        return parts.join('<br>') || '<span class="muted">—</span>';
      } },
    { h: 'Placed on', f: n => chips(tabsOf(n.id)) },
    { h: 'Uses tokens', f: n => chips(directTokens(n.id)) },
    { h: 'Visibility', f: n => esc(n.visibility || '') },
  ], M.byKind('input'));
}

function dsTree() {
  const ds = M.byKind('ds');
  if (!ds.length) return '<p class="muted">No data sources.</p>';
  const li = (id, seen) => {
    if (seen.has(id)) return '';
    seen = new Set(seen).add(id);
    const n = M.nodes.get(id);
    const kids = outs(id, ['extends']).map(e => e.to);
    const cons = outs(id, ['feeds', 'populates']).map(e => e.to);
    return `<li class="filterable"><div class="tree-row">${chip(id)} ${badge(dsTypeLabel(n.type))}${issueMark(id)}
      ${cons.length ? `<span class="arrow">→</span> ${cons.map(c => chip(c)).join(' ')}` : (kids.length ? '' : '<span class="muted small">no consumers</span>')}</div>
      ${kids.length ? `<ul>${kids.map(k => li(k, seen)).join('')}</ul>` : ''}</li>`;
  };
  const roots = ds.filter(n => n.depth === 0 || n.cycle || (n.type === 'ds.chain' && !M.nodes.has('ds:' + n.extend)));
  return `<ul class="tree">${uniq(roots.map(r => r.id)).map(r => li(r, new Set())).join('')}</ul>`;
}

function viewDataSources() {
  const ds = M.byKind('ds');
  return `<p class="muted small">Searches run on their own. Chain searches extend a base search, and a chain can extend another chain. Click any item to see its full and effective SPL.</p>
  <div class="section-title">Search lineage</div>
  <div class="card">${dsTree()}</div>
  <div class="section-title">All data sources</div>
  ${table([
    { h: 'Data source', f: n => chip(n.id) + issueMark(n.id) },
    { h: 'ID', f: n => `<code>${esc(n.key)}</code>` },
    { h: 'Type', f: n => esc(dsTypeLabel(n.type)) },
    { h: 'Base search', f: n => n.type === 'ds.chain' ? (n.extend ? chip('ds:' + n.extend) : '<span class="muted">missing</span>') : '<span class="muted">—</span>' },
    { h: 'Query', cls: 'q', f: n => n.type === 'ds.savedSearch' ? `<code>| savedsearch "${esc(n.ref)}"</code>${n.app ? `<span class="muted small">app: ${esc(n.app)}</span>` : ''}` : (n.query ? `<code>${esc(n.query)}</code>` : '<span class="muted">—</span>') },
    { h: 'Indexes', f: n => srcCell(n, 'index') },
    { h: 'Sourcetypes', f: n => srcCell(n, 'sourcetype') },
    { h: 'Lookups', f: n => lookupCell(n) },
    { h: 'Data models', f: n => dmCell(n) },
    { h: 'Macros', f: n => macroCell(n) },
    { h: 'Commands', f: n => pipeline(n) },
    { h: 'Other sources', f: n => n.eff_other.length ? n.eff_other.map(o => `<div class="small"><code>${esc(o)}</code></div>`).join('') : '<span class="muted">—</span>' },
    { h: 'Time range', f: n => timeRange(n) },
    { h: 'Refresh', f: n => n.refresh ? `<code>${esc(fmt(n.refresh))}</code>${n.refreshType ? ` <span class="muted small">${esc(n.refreshType)}</span>` : ''}` : '<span class="muted">—</span>' },
    { h: 'Used by', f: n => chips(outs(n.id, ['feeds', 'populates', 'extends']).map(e => e.to)) },
    { h: 'Uses tokens', f: n => chips(directTokens(n.id)) },
    { h: 'Provides tokens', f: n => chips(outs(n.id, ['smart-source']).map(e => e.to)) },
  ], ds)}`;
}

function viewVisualizations() {
  return table([
    { h: 'Visualization', f: n => chip(n.id) + issueMark(n.id) },
    { h: 'ID', f: n => `<code>${esc(n.key)}</code>` },
    { h: 'Type', f: n => esc(shortType(n.type)) },
    { h: 'Placed on', f: n => chips(tabsOf(n.id)) },
    { h: 'Data source lineage', f: n => outsIn(n.id) },
    { h: 'Search type', f: n => esc(uniq(ins(n.id, ['feeds']).map(e => dsTypeLabel(M.nodes.get(e.from)?.type))).join(', ')) },
    { h: 'Reads from', f: n => chips(vizSources(n.id)) },
    { h: 'Uses tokens (direct)', f: n => chips(directTokens(n.id)) },
    { h: 'Sets tokens', f: n => chips(outs(n.id, ['drilldown-sets']).map(e => e.to)) },
    { h: 'Drilldown', f: n => n.drilldowns.map(d => `<div class="small">${esc(d.text)}</div>`).join('') || '<span class="muted">—</span>' },
    { h: 'Visibility', f: n => esc(n.visibility || '') },
  ], M.byKind('viz'));
}

function viewTokens() {
  const st = t => t.status === 'Undefined' ? badge('Undefined', 'sev-warning') : t.status === 'Defined' ? badge('Defined', 'ok') : badge(t.status);
  return `<p class="muted small">A token is set by an input, a drilldown, a default value or a smart source, and is used wherever <code>$name$</code> appears. Time range tokens such as <code>$global_time.earliest$</code> are grouped under their base token.</p>` +
  table([
    { h: 'Token', f: t => chip(t.id) + issueMark(t.id) },
    { h: 'Status', f: st },
    { h: 'Set by', f: t => chips(ins(t.id, ['sets', 'drilldown-sets', 'default', 'smart-source']).map(e => [e.from, REL[e.rel].group === 'token' && e.rel === 'drilldown-sets' ? 'drilldown' : e.rel === 'default' ? 'default' : e.rel === 'smart-source' ? 'smart source' : ''])) },
    { h: 'Default value', f: t => (t.defaults || []).map(d => `<code>${esc(fmt(d.value))}</code>`).join(' ') || '<span class="muted">—</span>' },
    { h: 'Used by', f: t => chips(uniq(outs(t.id, ['uses-token']).map(e => e.to))) },
    { h: 'References', f: t => String(M.usages.filter(u => u.token === t.id).length) },
  ], M.byKind('token'));
}

function srcCell(n, field) {
  const list = n['eff_' + field] || [];
  if (!list.length) return n.type === 'ds.savedSearch' ? '<span class="muted small">defined in the report</span>' : '<span class="muted">—</span>';
  return `<div class="stack">${list.map(v => {
    const det = [v.excluded ? 'excluded' : '', v.inherited ? 'from base' : ''].filter(Boolean).join(', ');
    return v.value.includes('$') ? `<code title="Set by a token">${esc(v.value)}</code>${det ? ` <span class="muted small">${esc(det)}</span>` : ''}` : chip(field + ':' + v.value, det);
  }).join('')}</div>`;
}
// Index / sourcetype items a visualization ultimately reads (included terms only).
function vizSources(vizId) {
  const ids = [];
  for (const e of ins(vizId, ['feeds'])) {
    const d = M.nodes.get(e.from);
    for (const f of ['index', 'sourcetype']) for (const v of d['eff_' + f] || []) if (!v.excluded && !v.value.includes('$')) ids.push(f + ':' + v.value);
    for (const l of d.eff_lookups || []) if (l.mode === 'read' && !l.name.includes('$')) ids.push('lookup:' + l.name);
    for (const x of d.eff_datamodels || []) if (!x.model.includes('$')) ids.push('datamodel:' + x.model);
    for (const x of d.eff_macros || []) ids.push('macro:' + x.key);
  }
  return uniq(ids);
}
// Follow only data links (index/sourcetype → search → chain → visualization), not token links.
function dataDown(id) {
  const seen = new Set(), stack = [id];
  while (stack.length) for (const e of outs(stack.pop(), ['searches', 'lookup-read', 'datamodel-read', 'macro-used', 'extends', 'feeds'])) if (e.detail !== 'excluded' && !seen.has(e.to)) { seen.add(e.to); stack.push(e.to); }
  return [...seen];
}
function viewSources() {
  const items = [...M.byKind('index'), ...M.byKind('sourcetype')];
  const chainsOf = id => dataDown(id).filter(x => x.startsWith('ds:') && !outs(id, ['searches']).some(e => e.to === x));
  const vizOf = id => dataDown(id).filter(x => x.startsWith('viz:'));
  const noIndex = M.byKind('ds').filter(n => !n.eff_index.length);
  return `<p class="muted small">Read from each search's SPL: <code>index=</code>, <code>index::</code>, <code>index!=</code>, <code>NOT index=</code> and <code>index IN (…)</code>, and the same for <code>sourcetype</code>. Chain searches inherit from their base search. Macros, saved searches, data models and lookups can hide further sources, so those are listed separately.</p>
  ${table([
    { h: 'Name', f: n => chip(n.id) },
    { h: 'Kind', f: n => esc(KINDS[n.kind].label) },
    { h: 'Read directly by', f: n => chips(outs(n.id, ['searches']).map(e => [e.to, e.detail])) },
    { h: 'Inherited by chain searches', f: n => chips(chainsOf(n.id)) },
    { h: 'Feeds visualizations', f: n => chips(vizOf(n.id)) },
    { h: 'Tabs', f: n => chips(uniq(vizOf(n.id).flatMap(tabsOf))) },
  ], items)}
  <div class="section-title">Data sources with no index in their SPL (${noIndex.length})</div>
  ${table([
    { h: 'Data source', f: n => chip(n.id) },
    { h: 'Type', f: n => esc(dsTypeLabel(n.type)) },
    { h: 'Sourcetypes', f: n => srcCell(n, 'sourcetype') },
    { h: 'Other sources', f: n => n.eff_other.map(o => `<div class="small"><code>${esc(o)}</code></div>`).join('') || '<span class="muted">—</span>' },
  ], noIndex)}`;
}

const accessBadge = a => badge(a, a === 'read' ? 'read' : 'write');
function lookupCell(n) {
  const list = n.eff_lookups || [];
  if (!list.length) return '<span class="muted">—</span>';
  return `<div class="stack">${list.map(l => {
    const det = [l.mode, l.command, l.inherited ? 'from base' : ''].filter(Boolean).join(' · ');
    return l.name.includes('$') ? `<code title="Set by a token">${esc(l.name)}</code> <span class="muted small">${esc(det)}</span>` : chip('lookup:' + l.name, det);
  }).join('')}</div>`;
}
function dmCell(n) {
  const list = n.eff_datamodels || [];
  if (!list.length) return '<span class="muted">—</span>';
  return `<div class="stack">${list.map(x => {
    const det = [x.dataset, x.command, x.inherited ? 'from base' : ''].filter(Boolean).join(' · ');
    return x.model.includes('$') ? `<code>${esc(x.model)}</code> <span class="muted small">${esc(det)}</span>` : chip('datamodel:' + x.model, det);
  }).join('')}</div>`;
}
function macroCell(n) {
  const list = n.eff_macros || [];
  if (!list.length) return '<span class="muted">—</span>';
  const seen = new Set();
  return `<div class="stack">${list.filter(x => !seen.has(x.key + x.inherited) && seen.add(x.key + x.inherited)).map(x => chip('macro:' + x.key, x.inherited ? 'from base' : '')).join('')}</div>`;
}
// The command pipeline of one search (its own SPL), with subsearch commands marked.
function pipeline(n, chipsToo = false) {
  const cmds = n.sources?.commands || [];
  if (!cmds.length) return '<span class="muted">—</span>';
  const one = c => {
    const label = c.name + (c.implicit && c.name === 'search' ? ' (implicit)' : '');
    const html = chipsToo && M.nodes.has('command:' + c.name) ? chip('command:' + c.name, c.implicit && c.name === 'search' ? 'implicit' : '') : `<code>${esc(label)}</code>`;
    return c.sub ? `<span title="In a subsearch">[${html}]</span>` : html;
  };
  return `<span class="pipeline">${cmds.map(one).join('<span class="sep">|</span>')}</span>`;
}
function viewDatamodels() {
  const vizOf = id => dataDown(id).filter(x => x.startsWith('viz:'));
  return `<p class="muted small">Found in SPL as <code>| tstats … from datamodel=Model.Dataset</code>, <code>| from datamodel:Model.Dataset</code>, <code>| datamodel Model Dataset search</code> and <code>| pivot Model Dataset …</code>. A chain search inherits the data models its base search reads.</p>` +
  table([
    { h: 'Data model', f: n => chip(n.id) + issueMark(n.id) },
    { h: 'Datasets', f: n => [...n.datasets].map(d => `<code>${esc(d)}</code>`).join(' ') || '<span class="muted">—</span>' },
    { h: 'Read by', f: n => chips(outs(n.id, ['datamodel-read']).map(e => [e.to, e.detail])) },
    { h: 'Inherited by chain searches', f: n => chips(dataDown(n.id).filter(x => x.startsWith('ds:') && !outs(n.id, ['datamodel-read']).some(e => e.to === x))) },
    { h: 'Feeds visualizations', f: n => chips(vizOf(n.id)) },
    { h: 'Tabs', f: n => chips(uniq(vizOf(n.id).flatMap(tabsOf))) },
  ], M.byKind('datamodel'));
}
function viewMacros() {
  const vizOf = id => dataDown(id).filter(x => x.startsWith('viz:'));
  return `<p class="muted small">Every <code>\`macro\`</code> call in the SPL. Splunk identifies a macro by its name and argument count, so <code>\`name(2)\`</code> is a different macro from <code>\`name\`</code>. Macro definitions live in macros.conf and are not part of the dashboard, so the indexes, lookups and commands inside a macro are not listed here. To see them, expand the macro in Search (Ctrl+Shift+E).</p>` +
  table([
    { h: 'Macro', f: n => chip(n.id) + issueMark(n.id) },
    { h: 'Arguments', f: n => String(n.arity) },
    { h: 'Definition', cls: 'q', f: n => n.config ? `<code>${esc(n.config.definition)}</code>` : '<span class="muted small">Paste macros.conf on the Splunk config page to see it.</span>' },
    { h: 'Calls as written', cls: 'q', f: n => n.calls.map(c => `<code>\`${esc(c)}\`</code>`).join('') },
    { h: 'Used by', f: n => chips(outs(n.id, ['macro-used']).map(e => e.to)) },
    { h: 'Inherited by chain searches', f: n => chips(dataDown(n.id).filter(x => x.startsWith('ds:') && !outs(n.id, ['macro-used']).some(e => e.to === x))) },
    { h: 'Feeds visualizations', f: n => chips(vizOf(n.id)) },
  ], M.byKind('macro'));
}
function viewCommands() {
  const cmds = M.byKind('command').sort((a, b) => b.uses - a.uses || a.label.localeCompare(b.label));
  const catCls = c => c === 'Writes data / side effect' ? 'write' : c === 'Generating' ? 'read' : '';
  return `<p class="muted small">Every command in every search's pipeline, including subsearches. A search that doesn't start with <code>|</code> begins with an implicit <code>search</code>. Commands inside macros aren't visible, because macro definitions live in macros.conf.</p>` +
  table([
    { h: 'Command', f: n => chip(n.id) },
    { h: 'Category', f: n => badge(n.category, catCls(n.category)) },
    { h: 'Uses', f: n => String(n.uses) },
    { h: 'Searches', f: n => String(outs(n.id, ['command-used']).length) },
    { h: 'Used by', f: n => chips(outs(n.id, ['command-used']).map(e => [e.to, e.detail])) },
  ], cmds) +
  `<div class="section-title">Pipeline of each search</div>` +
  table([
    { h: 'Data source', f: n => chip(n.id) },
    { h: 'Type', f: n => esc(dsTypeLabel(n.type)) },
    { h: 'Pipeline', f: n => pipeline(n, true) },
  ], M.byKind('ds'));
}

function viewLookups() {
  const vizOf = id => dataDown(id).filter(x => x.startsWith('viz:'));
  return `<p class="muted small">Read from each search's SPL. <b>Read</b>: <code>| lookup</code>, <code>| inputlookup</code>, <code>| inputcsv</code>, <code>| from lookup:</code>. <b>Write</b>: <code>| outputlookup</code>, <code>| outputcsv</code>. A chain search inherits the lookups its base search reads. Automatic lookups configured in props.conf don't appear in SPL, so they aren't listed.</p>` +
  table([
    { h: 'Lookup', f: n => chip(n.id) + issueMark(n.id) },
    { h: 'Access', f: n => [...n.access].sort().map(accessBadge).join(' ') },
    { h: 'Read by', f: n => chips(outs(n.id, ['lookup-read']).map(e => [e.to, e.detail])) },
    { h: 'Written by', f: n => chips(ins(n.id, ['lookup-write']).map(e => [e.from, e.detail])) },
    { h: 'Inherited by chain searches', f: n => chips(dataDown(n.id).filter(x => x.startsWith('ds:') && !outs(n.id, ['lookup-read']).some(e => e.to === x))) },
    { h: 'Feeds visualizations', f: n => chips(vizOf(n.id)) },
    { h: 'Tabs', f: n => chips(uniq(vizOf(n.id).flatMap(tabsOf))) },
  ], M.byKind('lookup'));
}

/* ---------- Dashboard mockup (interactive) ---------- */
const mockState = { tab: null, substitute: true, showHidden: true, showNames: false, values: null };
// The definition IDs behind a mockup item: the item itself, plus the data sources feeding a panel
// or the token an input sets.
function itemNames(n) {
  if (n.kind === 'input') return n.key + (n.token ? ' → $' + n.token + '$' : '');
  const ds = ins(n.id, ['feeds']).map(e => e.from.slice(3));
  return n.key + (ds.length ? ' ← ' + ds.join(', ') : '');
}
// Token values start from the defaults: an input's default first, then dashboard defaults.
function resetMockValues() {
  mockState.values = new Map();
  for (const t of M.byKind('token')) {
    const d = (t.defaults || []).find(x => x.value !== undefined && x.value !== '');
    if (d) mockState.values.set(t.key, Array.isArray(d.value) ? d.value.map(String) : String(d.value));
  }
}
const mockValues = () => { if (!mockState.values) resetMockValues(); return mockState.values; };
const hasValue = key => { const v = mockValues().get(key); return v !== undefined && !(Array.isArray(v) && !v.length); };
// The text a token expands to, honouring multiselect prefixes and delimiters and timerange .earliest/.latest.
function tokenText(name) {
  const key0 = String(name).split('|')[0].replace(/^form\./, '');
  let key = key0, prop = '';
  if (!M.nodes.has('token:' + key)) { const i = key.lastIndexOf('.'); if (i > 0 && M.nodes.has('token:' + key.slice(0, i))) { prop = key.slice(i + 1); key = key.slice(0, i); } }
  const v = mockValues().get(key);
  if (v === undefined) return undefined;
  if (Array.isArray(v)) {
    const inp = ins('token:' + key, ['sets']).map(e => M.nodes.get(e.from)).find(n => n?.kind === 'input');
    const o = inp?.raw?.options || {};
    const body = v.map(x => (o.valuePrefix || '') + x + (o.valueSuffix || '')).join(o.delimiter ?? ' ');
    return (o.prefix || '') + body + (o.suffix || '');
  }
  if (prop === 'earliest' || prop === 'latest') { const [e, l] = String(v).split(','); return prop === 'earliest' ? e : (l || 'now'); }
  return String(v);
}
function withValues(str) {
  str = String(str ?? '');
  if (!mockState.substitute) return str;
  return str.replace(/\$\$|\$([^$\s]+?)\$/g, (all, name) => { if (!name) return '$'; const v = tokenText(name); return v === undefined ? all : v; });
}
/* Condition expressions: comparisons (= == != < > <= >=), AND/OR/NOT (&& || !), parentheses,
   strings, numbers, true/false/null, and $tokens$. Anything else is reported as "can't evaluate". */
function evalExpr(src) {
  const toks = [];
  let i = 0;
  while (i < src.length) {
    const ch = src[i], rest = src.slice(i);
    if (/\s/.test(ch)) { i++; continue; }
    if (ch === '"' || ch === "'") {
      let j = i + 1, s = '';
      while (j < src.length && src[j] !== ch) { if (src[j] === '\\') j++; s += src[j++] ?? ''; }
      toks.push({ t: 'val', v: withValuesForce(s) }); i = j + 1; continue;
    }
    let m;
    if ((m = rest.match(/^\$([^$\s]+)\$/))) { const v = tokenText(m[1]); toks.push({ t: 'val', v: v === undefined ? null : v }); i += m[0].length; continue; }
    if ((m = rest.match(/^(==|!=|<=|>=|&&|\|\||=|<|>|!|\(|\))/))) { toks.push({ t: 'op', v: m[1] }); i += m[1].length; continue; }
    if ((m = rest.match(/^-?\d+(\.\d+)?/))) { toks.push({ t: 'val', v: +m[0] }); i += m[0].length; continue; }
    if ((m = rest.match(/^[A-Za-z_][\w.]*/))) {
      const u = m[0].toUpperCase();
      if (u === 'AND') toks.push({ t: 'op', v: '&&' }); else if (u === 'OR') toks.push({ t: 'op', v: '||' }); else if (u === 'NOT') toks.push({ t: 'op', v: '!' });
      else if (u === 'TRUE' || u === 'FALSE') toks.push({ t: 'val', v: u === 'TRUE' }); else if (u === 'NULL') toks.push({ t: 'val', v: null });
      else throw new Error('unsupported word ' + m[0]);
      i += m[0].length; continue;
    }
    throw new Error('unexpected ' + ch);
  }
  let p = 0;
  const isOp = v => toks[p]?.t === 'op' && toks[p].v === v;
  const num = x => x !== null && x !== '' && !isNaN(Number(x));
  const compare = (a, op, b) => {
    if (op === '=') op = '==';
    if (a === null || b === null) return op === '==' ? a === b : op === '!=' ? a !== b : false;
    if (num(a) && num(b)) { a = Number(a); b = Number(b); } else { a = String(a); b = String(b); }
    return { '==': a === b, '!=': a !== b, '<': a < b, '>': a > b, '<=': a <= b, '>=': a >= b }[op];
  };
  const or = () => { let a = and(); while (isOp('||')) { p++; const b = and(); a = truthy(a) || truthy(b); } return a; };
  const and = () => { let a = not(); while (isOp('&&')) { p++; const b = not(); a = truthy(a) && truthy(b); } return a; };
  const not = () => { if (isOp('!')) { p++; return !truthy(not()); } return cmp(); };
  const cmp = () => {
    const a = prim(), o = toks[p];
    if (o?.t === 'op' && ['==', '=', '!=', '<', '>', '<=', '>='].includes(o.v)) { p++; return compare(a, o.v, prim()); }
    return a;
  };
  const prim = () => {
    const k = toks[p++];
    if (!k) throw new Error('unexpected end');
    if (k.t === 'op' && k.v === '(') { const v = or(); if (!isOp(')')) throw new Error('missing )'); p++; return v; }
    if (k.t === 'val') return k.v;
    throw new Error('unexpected ' + k.v);
  };
  const v = or();
  if (p < toks.length) throw new Error('unexpected ' + toks[p].v);
  return v;
}
const truthy = v => v !== null && v !== undefined && v !== false && v !== '' && v !== 0 && v !== 'false';
const withValuesForce = s => String(s).replace(/\$([^$\s]+?)\$/g, (all, n) => tokenText(n) ?? '');
// true / false, or null when the expression can't be evaluated here.
function evalCondition(c) {
  const cl = c?.raw?._classic;
  if (cl) return cl.depends.every(hasValue) && !cl.rejects.some(hasValue);
  try { return truthy(evalExpr(String(c?.value ?? ''))); } catch { return null; }
}
// Hidden by a condition? Waiting for tokens that have no value?
function panelState(n) {
  let hidden = false, unknown = false;
  for (const e of ins(n.id, ['visibility'])) {
    const r = evalCondition(M.nodes.get(e.from));
    if (r === null) unknown = true;
    else if ((e.detail === 'show when' && !r) || (e.detail === 'hide when' && r)) hidden = true;
  }
  const searchToks = n.kind === 'viz' ? uniq(ins(n.id, ['feeds']).flatMap(e => M.nodes.get(e.from)?.lineage || []).flatMap(id => directTokens(id))) : [];
  const waiting = searchToks.filter(t => { const tn = M.nodes.get(t); return tn && tn.subtype !== 'env' && tn.subtype !== 'smart' && !hasValue(tn.key); });
  return { hidden, unknown, waiting };
}
function mockInput(n, inCanvas) {
  const t = shortType(n.type);
  const tok = n.token;
  const v = tok ? mockValues().get(tok) : undefined;
  const items = (n.items || []).map(i => ({ label: fmt(i?.label ?? i?.value), value: fmt(i?.value ?? i?.label) }));
  const dyn = ins(n.id, ['populates']).length > 0;
  const attrs = `data-mock-token="${esc(tok || '')}" data-mock-type="${esc(t)}" ${tok ? '' : 'disabled'} aria-label="${esc(n.title || n.key)}"`;
  let ctl;
  if (t === 'dropdown' || t === 'radio') {
    const opts = [...items];
    if (v !== undefined && !opts.some(o => o.value === String(v))) opts.push({ label: String(v), value: String(v) });
    ctl = `<select class="mock-ctl" ${attrs}><option value="">${dyn ? '(options come from a search)' : 'Select…'}</option>${opts.map(o => `<option value="${esc(o.value)}" ${String(v) === o.value ? 'selected' : ''}>${esc(o.label)}</option>`).join('')}</select>`;
  } else if (t === 'multiselect' || t === 'checkbox') {
    const cur = Array.isArray(v) ? v : v === undefined ? [] : [String(v)];
    const opts = [...items];
    for (const c of cur) if (!opts.some(o => o.value === c)) opts.push({ label: c, value: c });
    ctl = `<div class="mock-opts" ${attrs} data-multi="1">${opts.map(o => `<label><input type="checkbox" value="${esc(o.value)}" ${cur.includes(o.value) ? 'checked' : ''}> ${esc(o.label)}</label>`).join('') || '<span class="muted small">options come from a search</span>'}</div>`;
  } else {
    const ph = t === 'timerange' ? 'earliest,latest' : t === 'number' ? 'number' : 'value';
    ctl = `<input class="mock-ctl" ${attrs} value="${esc(v === undefined ? '' : fmt(v))}" placeholder="${ph}"${t === 'timerange' ? ' title="earliest,latest, for example -24h@h,now"' : ''}>`;
  }
  const inner = `<div class="lbl"><button class="linklike" data-open="${esc(n.id)}" title="Open details">${esc(n.title || n.key)}</button>${mockState.showNames ? `<code class="idtag-inline" title="${esc(itemNames(n))}">${esc(itemNames(n))}</code>` : tok ? ` <span class="muted">$${esc(tok)}$</span>` : ''}</div>${ctl}`;
  return inCanvas ? inner : `<div class="mock-input">${inner}</div>`;
}
// Placeholder drawing for a visualization type. Shapes are illustrative only, not data.
function vizSketch(n) {
  const t = shortType(n.type).toLowerCase();
  const svg = (body, keep) => `<svg viewBox="0 0 100 60" preserveAspectRatio="${keep ? 'xMidYMid meet' : 'none'}" aria-hidden="true">${body}</svg>`;
  const S = 'stroke="currentColor" fill="none" stroke-width="1.6" vector-effect="non-scaling-stroke"';
  if (/singlevalue|gauge|marker/.test(t)) return `<div class="big">1,234</div>`;
  if (t === 'markdown') {
    const md = String(n.raw?.options?.markdown ?? '');
    const lines = withValues(md).split('\n').slice(0, 8).map(l => {
      const h = l.match(/^(#{1,6})\s*(.*)$/);
      const txt = esc((h ? h[2] : l).replace(/\*\*|__|`/g, ''));
      return h ? `<div style="font-weight:650;font-size:${Math.max(12, 18 - h[1].length * 2)}px">${txt}</div>` : `<div>${txt || '&nbsp;'}</div>`;
    }).join('');
    return `<div class="md">${lines}</div>`;
  }
  if (t === 'line') return svg(`<polyline ${S} points="2,48 14,40 26,44 38,26 50,32 62,18 74,24 86,12 98,16"/><polyline ${S} opacity=".45" points="2,54 14,50 26,52 38,42 50,46 62,38 74,42 86,34 98,36"/>`);
  if (t === 'area') return svg(`<polygon fill="currentColor" opacity=".25" points="2,58 2,44 18,36 34,40 50,24 66,30 82,14 98,20 98,58"/><polyline ${S} points="2,44 18,36 34,40 50,24 66,30 82,14 98,20"/>`);
  if (t === 'column') return svg([12, 26, 18, 40, 30, 46, 22, 34].map((h, i) => `<rect x="${4 + i * 12}" y="${58 - h}" width="8" height="${h}" fill="currentColor" opacity=".7"/>`).join(''));
  if (t === 'bar') return svg([70, 52, 40, 30, 18].map((w, i) => `<rect x="2" y="${4 + i * 11}" width="${w}" height="7" fill="currentColor" opacity=".7"/>`).join(''));
  if (t === 'pie') return svg(`<circle cx="50" cy="30" r="13" fill="none" stroke="currentColor" stroke-width="26" stroke-dasharray="40 82" opacity=".8"/><circle cx="50" cy="30" r="13" fill="none" stroke="currentColor" stroke-width="26" stroke-dasharray="25 82" stroke-dashoffset="-40" opacity=".45"/><circle cx="50" cy="30" r="13" fill="none" stroke="currentColor" stroke-width="26" stroke-dasharray="17 82" stroke-dashoffset="-65" opacity=".25"/>`, true);
  if (t === 'table' || t === 'events') return svg(`<rect x="0" y="0" width="100" height="9" fill="currentColor" opacity=".25"/>` + [0, 1, 2, 3, 4].map(i => `<line x1="0" x2="100" y1="${19 + i * 10}" y2="${19 + i * 10}" stroke="currentColor" opacity=".3" vector-effect="non-scaling-stroke"/>`).join('') + [0, 1, 2, 3, 4, 5].map(i => `<rect x="3" y="${12 + i * 10 - 2}" width="${20 + (i * 7) % 18}" height="3" fill="currentColor" opacity=".45"/><rect x="45" y="${12 + i * 10 - 2}" width="${12 + (i * 5) % 14}" height="3" fill="currentColor" opacity=".3"/>`).join(''));
  if (/scatter|bubble|punchcard/.test(t)) return svg([[10, 40, 2], [22, 30, 3], [35, 44, 2], [48, 20, 4], [60, 34, 2], [72, 14, 3], [85, 26, 2], [92, 10, 3]].map(([x, y, r]) => `<circle cx="${x}" cy="${y}" r="${t === 'bubble' ? r * 2 : 2}" fill="currentColor" opacity=".6"/>`).join(''));
  if (/map|choropleth/.test(t)) return svg(`<path d="M8,30 C14,12 30,8 40,16 C52,6 70,10 74,22 C90,20 96,36 86,46 C70,56 48,52 34,50 C18,54 4,44 8,30 z" fill="currentColor" opacity=".25" stroke="currentColor" vector-effect="non-scaling-stroke"/><circle cx="36" cy="28" r="2.5" fill="currentColor"/><circle cx="64" cy="34" r="2.5" fill="currentColor"/>`, true);
  if (t === 'image') return svg(`<rect x="20" y="8" width="60" height="44" ${S}/><polyline ${S} points="24,48 40,30 52,40 62,32 76,48"/><circle cx="64" cy="20" r="4" ${S}/>`, true);
  if (t === 'rectangle') return '';
  if (t === 'ellipse') return svg(`<ellipse cx="50" cy="30" rx="48" ry="28" ${S} opacity=".5"/>`);
  if (/sankey|linkgraph|parallel/.test(t)) return svg(`<path d="M4,10 C40,10 60,44 96,44 M4,30 C40,30 60,14 96,14 M4,50 C40,50 60,30 96,30" ${S} opacity=".6"/>`);
  return `<div class="muted small">${esc(shortType(n.type))}</div>`;
}
function mockPanel(item, style) {
  const n = M.nodes.get(item.id);
  if (!n) return '';
  const st = panelState(n);
  if (st.hidden && !mockState.showHidden) return '';
  const hiddenCls = st.hidden ? ' hidden-panel' : '';
  if (n.kind === 'input') return `<div class="mock-panel input-item${hiddenCls}" style="${style}">${mockInput(n, true)}</div>`;
  const t = shortType(n.type).toLowerCase();
  const shape = t === 'rectangle' || t === 'ellipse';
  const ds = ins(n.id, ['feeds']).map(e => M.nodes.get(e.from)?.label).filter(Boolean);
  const flags = [];
  if (st.hidden) flags.push('<span class="warn">hidden by condition</span>');
  else if (ins(n.id, ['visibility']).length) flags.push(`<span title="Shown or hidden by a condition">${st.unknown ? 'condition: can\'t evaluate' : 'conditional'}</span>`);
  if (/hidden when no data/.test(n.visibility || '')) flags.push('<span>hides if empty</span>');
  const sets = outs(n.id, ['drilldown-sets']).map(e => M.nodes.get(e.to)?.label);
  if (sets.length || n.drilldowns.length) flags.push(`<span title="${esc(n.drilldowns.map(d => d.text).join('; '))}">drilldown${sets.length ? ' → ' + esc(sets.join(', ')) : ''}</span>`);
  if (issuesFor(n.id).some(i => i.severity === 'error')) flags.push('<span class="err">error</span>');
  const title = n.title ? `<div class="t" title="${esc(n.title)}">${esc(withValues(n.title))}</div>` : '';
  const tip = `${n.key} · ${n.type}${ds.length ? ' · data: ' + ds.join(', ') : ''}`;
  const waiting = st.waiting.length ? `<div class="waiting">Waiting for input: ${esc(st.waiting.map(x => M.nodes.get(x).label).join(', '))}</div>` : '';
  return `<div class="mock-panel mock-item${shape ? ' shape' : ''}${hiddenCls}" data-id="${esc(n.id)}" style="${style}" title="${esc(tip)}">
    ${flags.length ? `<div class="flags">${flags.join('')}</div>` : ''}${title}<div class="b${waiting ? ' faded' : ''}">${vizSketch(n)}</div>${waiting}
    ${!shape && t !== 'markdown' ? `<div class="f">${esc(shortType(n.type))}${ds.length ? ' · ' + esc(ds.join(', ')) : ''}</div>` : ''}${mockState.showNames ? `<div class="idtag" title="${esc(itemNames(n))}">${esc(itemNames(n))}</div>` : ''}</div>`;
}
// Canvas size and the items that have positions.
function canvasGeometry(tab) {
  const items = tab.items || [];
  const placed = items.filter(i => i.position && i.position.x !== undefined && i.position.w);
  const W = Number(tab.options?.width) || Math.max(1200, ...placed.map(i => i.position.x + i.position.w));
  const H = Number(tab.options?.height) && tab.layoutType === 'absolute' ? Number(tab.options.height) : Math.max(1, ...placed.map(i => i.position.y + i.position.h));
  return { items, placed, unplaced: items.filter(i => !placed.includes(i)), W, H };
}
function mockCanvas(tab) {
  const g = canvasGeometry(tab);
  if (!g.items.length) return '<p class="muted">This tab is empty.</p>';
  let html = '';
  if (g.placed.length) {
    const pct = (v, of) => (v / of * 100).toFixed(3) + '%';
    html += `<div class="mock-canvas" style="aspect-ratio: ${g.W} / ${g.H}">` + g.placed.map(i => {
      const p = i.position;
      // A small inset so neighbouring grid panels read as separate panels.
      return mockPanel(i, `left:calc(${pct(p.x, g.W)} + 3px);top:calc(${pct(p.y, g.H)} + 3px);width:calc(${pct(p.w, g.W)} - 6px);height:calc(${pct(p.h, g.H)} - 6px)`);
    }).join('') + `</div>`;
  }
  if (g.unplaced.length) html += `<div class="mock-flow" style="margin-top:10px">${g.unplaced.map(i => mockPanel(i, '')).join('')}</div>`;
  return html;
}
function mockTabs() { return M.byKind('tab').filter(t => !t.global).sort((a, b) => a.order - b.order); }
function viewMockup() {
  const tabs = mockTabs();
  const global = M.nodes.get('tab:__global__');
  if (!tabs.length && !global) return '<p class="muted">This dashboard has no layout to draw.</p>';
  if (!tabs.some(t => t.id === mockState.tab)) mockState.tab = tabs[0]?.id || null;
  const cur = M.nodes.get(mockState.tab);
  const gInputs = (global?.items || []).map(i => M.nodes.get(i.id)).filter(Boolean);
  const editable = M.byKind('token').filter(t => t.subtype !== 'env');
  return `<div class="mock-controls">
      <label><input type="checkbox" id="mock-sub" ${mockState.substitute ? 'checked' : ''}> Show token values in titles</label>
      <label><input type="checkbox" id="mock-hidden" ${mockState.showHidden ? 'checked' : ''}> Show hidden panels (dimmed)</label>
      <label><input type="checkbox" id="mock-names" ${mockState.showNames ? 'checked' : ''}> Show item names</label>
      <button class="btn small" id="mock-reset">Reset token values</button>
      <button class="btn small" id="mock-svg">Export SVG</button>
      <button class="btn small" id="mock-png">Export PNG</button>
    </div>
    <p class="muted small" style="margin:0 0 10px">Change inputs or token values to see titles, conditional panels and "waiting for input" states update. Positions come from the layout. Charts are placeholders, not real data. Click a panel, or an input's name, for details.</p>
    <div class="mock-scroll"><div class="mock-dash">
      <div class="mock-head"><h3>${esc(withValues(M.title))}</h3>${M.description ? `<span class="muted small">${esc(M.description)}</span>` : ''}</div>
      ${tabs.length > 1 || cur?.isTab ? `<div class="mock-tabs" role="tablist">${tabs.map(t => `<button role="tab" data-mocktab="${esc(t.id)}" aria-selected="${t.id === mockState.tab}">${esc(t.label)}${mockState.showNames ? `<code class="idtag-inline">${esc(t.key)}</code>` : ''}</button>`).join('')}</div>` : ''}
      ${gInputs.length ? `<div class="mock-inputs">${gInputs.map(n => mockInput(n, false)).join('')}</div>` : ''}
      ${cur ? mockCanvas(cur) : ''}
      ${cur ? `<div class="muted small" style="margin-top:8px">${esc(cur.layoutType || 'canvas')} layout${cur.options?.width ? ` · ${cur.options.width}×${cur.options.height || '?'}` : ''} · ${plural((cur.items || []).length, 'item')}</div>` : ''}
    </div></div>
    <div class="section-title">Token values</div>
    <p class="muted small" style="margin:0 0 6px">Set a token to simulate a drilldown click or a search result. Leave it empty for "no value". Separate several values with commas for a multiselect.</p>
    ${table([
      { h: 'Token', f: t => chip(t.id) },
      { h: 'Set by', f: t => chips(ins(t.id, ['sets', 'drilldown-sets', 'default', 'smart-source']).map(e => e.from)) },
      { h: 'Value', f: t => { const v = mockValues().get(t.key); return `<input class="mock-ctl" style="min-width:220px" data-mock-token="${esc(t.key)}" data-mock-type="${Array.isArray(v) ? 'list' : 'text'}" value="${esc(Array.isArray(v) ? v.join(',') : v ?? '')}" placeholder="(no value)" aria-label="Value of ${esc(t.label)}">`; } },
      { h: 'Used by', f: t => chips(uniq(outs(t.id, ['uses-token']).map(e => e.to))) },
    ], editable)}`;
}
function onMockChange(el) {
  const box = el.closest('[data-mock-token]');
  const tok = box?.dataset.mockToken;
  if (!tok) return false;
  let v;
  if (box.dataset.multi) v = [...box.querySelectorAll('input:checked')].map(x => x.value);
  else if (box.dataset.mockType === 'list' || box.dataset.mockType === 'multiselect' || box.dataset.mockType === 'checkbox') v = box.value.split(',').map(x => x.trim()).filter(Boolean);
  else v = box.value;
  if (v === '' || (Array.isArray(v) && !v.length)) mockValues().delete(tok); else mockValues().set(tok, v);
  render();
  return true;
}

/* ---------- Mockup as SVG / PNG ---------- */
function mockupSvg(tabId = mockState.tab, light = false) {
  const cs = getComputedStyle(document.documentElement);
  // light: use the light palette whatever the page theme (for documents and print)
  const col = (v, d) => (light ? '' : cs.getPropertyValue(v).trim()) || d;
  const C = { bg: col('--panel', '#fff'), canvas: col('--panel-2', '#f1f3f6'), border: col('--border', '#dde1e7'), text: col('--text', '#1b1f24'), muted: col('--muted', '#5f6b7a'), accent: col('--accent', '#2f6fde'), warn: col('--sev-warning', '#b7791f') };
  const FONT = 'system-ui, -apple-system, Segoe UI, Roboto, sans-serif';
  const T = (x, y, s, size = 12, color = C.text, weight = 400, anchor = 'start') => `<text x="${x.toFixed(1)}" y="${y.toFixed(1)}" font-family="${FONT}" font-size="${size}" fill="${color}" font-weight="${weight}" text-anchor="${anchor}">${esc(s)}</text>`;
  const fit = (s, px, size) => { s = String(s ?? ''); const max = Math.max(1, Math.floor(px / (size * 0.56))); return s.length > max ? s.slice(0, Math.max(1, max - 1)) + '…' : s; };
  const R = (x, y, w, h, fill, stroke, extra = '') => `<rect x="${x.toFixed(1)}" y="${y.toFixed(1)}" width="${Math.max(0, w).toFixed(1)}" height="${Math.max(0, h).toFixed(1)}" rx="4" fill="${fill}" stroke="${stroke}" ${extra}/>`;
  const W = 1232, PAD = 16;
  let y = PAD, out = '';
  out += T(PAD, y + 18, fit(withValues(M.title), W - 2 * PAD, 18), 18, C.text, 650); y += 34;
  const tabs = mockTabs(), tab = M.nodes.get(tabId);
  if (tabs.length > 1 || tab?.isTab) {
    let x = PAD;
    for (const t of tabs) {
      const w = t.label.length * 7.2 + 28 + (mockState.showNames ? t.key.length * 6.4 + 8 : 0);
      out += T(x + 14, y + 18, t.label, 13, t.id === tabId ? C.text : C.muted, t.id === tabId ? 600 : 400);
      if (mockState.showNames) out += T(x + 14 + t.label.length * 7.2 + 6, y + 18, t.key, 10.5, C.accent, 600);
      if (t.id === tabId) out += `<rect x="${x}" y="${y + 27}" width="${w}" height="2" fill="${C.accent}"/>`;
      x += w;
    }
    out += `<rect x="${PAD}" y="${y + 29}" width="${W - 2 * PAD}" height="1" fill="${C.border}"/>`;
    y += 40;
  }
  const inputBox = (n, x, yy, w) => {
    const v = n.token ? tokenText(n.token) : undefined;
    return T(x, yy + 11, fit((n.title || n.key) + (mockState.showNames ? '  ' + itemNames(n) : ''), w, 11), 11, mockState.showNames ? C.accent : C.muted) + R(x, yy + 16, w, 26, C.bg, C.border) + T(x + 8, yy + 33, fit(v ?? '—', w - 16, 12), 12, v === undefined ? C.muted : C.text);
  };
  const gInputs = (M.nodes.get('tab:__global__')?.items || []).map(i => M.nodes.get(i.id)).filter(Boolean);
  if (gInputs.length) {
    let x = PAD;
    const iw = mockState.showNames ? 300 : 170; // room for "Title  input_id → $token$"
    for (const n of gInputs) { if (x + iw + 10 > W - PAD) { x = PAD; y += 52; } out += inputBox(n, x, y, iw); x += iw + 10; }
    y += 52;
  }
  if (tab) {
    const g = canvasGeometry(tab);
    const scale = (W - 2 * PAD) / g.W, ch = g.H * scale;
    out += R(PAD, y, W - 2 * PAD, ch, C.canvas, 'none');
    for (const it of g.placed) {
      const n = M.nodes.get(it.id);
      if (!n) continue;
      const st = panelState(n);
      if (st.hidden && !mockState.showHidden) continue;
      const p = it.position, x0 = PAD + p.x * scale + 3, y0 = y + p.y * scale + 3, w = p.w * scale - 6, h = p.h * scale - 6;
      let g2 = '';
      if (n.kind === 'input') g2 += inputBox(n, x0 + 4, y0 + Math.max(0, (h - 44) / 2), Math.min(w - 8, 260));
      else {
        const t = shortType(n.type).toLowerCase(), shape = t === 'rectangle' || t === 'ellipse';
        if (!shape) g2 += R(x0, y0, w, h, C.bg, C.border);
        let top = y0 + 8;
        if (n.title) { g2 += T(x0 + 8, y0 + 17, fit(withValues(n.title), w - 16, 12), 12, C.text, 600); top = y0 + 24; }
        const foot = shape || t === 'markdown' ? 0 : 16;
        const bx = x0 + 8, bw = w - 16, bh = Math.max(0, y0 + h - foot - 6 - top);
        const sk = vizSketch(n);
        if (sk.startsWith('<svg')) g2 += sk.replace('<svg ', `<svg x="${bx.toFixed(1)}" y="${top.toFixed(1)}" width="${bw.toFixed(1)}" height="${bh.toFixed(1)}" color="${C.accent}" style="color:${C.accent}" opacity="${st.waiting.length ? 0.3 : 1}" `);
        else if (sk.includes('class="big"')) g2 += T(x0 + w / 2, top + bh / 2 + 10, '1,234', Math.min(34, Math.max(16, bh / 3)), C.accent, 650, 'middle');
        else if (t === 'markdown') String(withValues(n.raw?.options?.markdown ?? '')).split('\n').slice(0, Math.max(1, Math.floor(bh / 16))).forEach((l, i) => {
          const hd = l.match(/^(#{1,6})\s*(.*)$/);
          g2 += T(bx, top + 12 + i * 16, fit((hd ? hd[2] : l).replace(/\*\*|__|`/g, ''), bw, 12), hd ? 13 : 12, C.text, hd ? 650 : 400);
        });
        else g2 += T(bx, top + 14, shortType(n.type), 11, C.muted);
        if (st.waiting.length) g2 += T(x0 + w / 2, top + bh / 2, fit('Waiting for input: ' + st.waiting.map(x => M.nodes.get(x).label).join(', '), w - 16, 11), 11, C.warn, 600, 'middle');
        if (foot) g2 += T(x0 + 8, y0 + h - 7, fit(shortType(n.type) + (ins(n.id, ['feeds']).length ? ' · ' + ins(n.id, ['feeds']).map(e => M.nodes.get(e.from)?.label).join(', ') : ''), w - 16, 10), 10, C.muted);
      }
      if (mockState.showNames && n.kind !== 'input') {
        const tag = fit(itemNames(n), w - 16, 10.5), tw = tag.length * 6.4 + 10;
        g2 += `<rect x="${(x0 + w - tw - 4).toFixed(1)}" y="${(y0 + h - 20).toFixed(1)}" width="${tw.toFixed(1)}" height="16" rx="3" fill="${C.bg}" stroke="${C.accent}" stroke-opacity="0.5"/>`
          + `<text x="${(x0 + w - 9).toFixed(1)}" y="${(y0 + h - 8).toFixed(1)}" font-family="ui-monospace, SFMono-Regular, Menlo, Consolas, monospace" font-size="10.5" font-weight="600" fill="${C.accent}" text-anchor="end">${esc(tag)}</text>`;
      }
      out += st.hidden ? `<g opacity="0.3">${g2}</g>` : g2;
    }
    y += ch + PAD;
  }
  const H = Math.ceil(y + PAD);
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}"><rect width="${W}" height="${H}" fill="${C.bg}"/>${out}</svg>`;
}
function mockFileName(ext) {
  const tab = M.nodes.get(mockState.tab);
  return `${slug(M.title)}-mockup${tab && mockTabs().length > 1 ? '-' + slug(tab.label) : ''}.${ext}`;
}
async function exportMockupPng() {
  const svg = mockupSvg();
  const url = URL.createObjectURL(new Blob([svg], { type: 'image/svg+xml' }));
  try {
    const img = new Image();
    await new Promise((res, rej) => { img.onload = res; img.onerror = () => rej(new Error('The mockup image could not be drawn.')); img.src = url; });
    const c = document.createElement('canvas');
    c.width = img.width * 2; c.height = img.height * 2;
    const g = c.getContext('2d');
    g.scale(2, 2); g.drawImage(img, 0, 0);
    const blob = await new Promise(r => c.toBlob(r, 'image/png'));
    await download(mockFileName('png'), blob, 'image/png');
  } catch (e) { alert(e.message); }
  finally { URL.revokeObjectURL(url); }
}

/* ---------- Issues and fixes ---------- */
let FIX_SEL = new Set();
function viewIssues() {
  const repairs = M.src.repairs || [];
  const fixable = M.issues.map((x, i) => [x, i]).filter(([x]) => x.fix);
  const bar = `<div class="card fixbar">
    ${fixable.length ? `<b>${plural(fixable.length, 'issue')} can be fixed automatically.</b> Tick the fixes you want, then download the corrected definition or load it here.`
      : '<b>No issue here has a safe automatic fix.</b>'}
    ${repairs.length ? ` Loading also repaired the source (${repairs.length}), so a downloaded definition is clean, valid JSON.` : ''}
    <div class="loader-actions" style="margin-top:8px">
      ${fixable.length ? `<button class="btn small" id="fix-all">Select all fixes</button><button class="btn small" id="fix-none">Clear selection</button>` : ''}
      <button class="btn primary small" id="fix-download">Download definition${FIX_SEL.size ? ` with ${plural(FIX_SEL.size, 'fix', 'fixes')}` : ''}</button>
      ${FIX_SEL.size ? `<button class="btn small" id="fix-load">Load the fixed version</button>` : ''}
    </div></div>`;
  if (!M.issues.length) return bar + '<p>No issues found. Every reference resolves, every item is placed, every token is defined, and the SPL checks passed.</p>';
  return bar + table([
    { h: 'Severity', f: i => sevBadge(i.severity) },
    { h: 'Item', f: i => chip(i.ref) },
    { h: 'Issue', f: i => esc(i.message) },
    { h: 'Fix', f: i => { const k = M.issues.indexOf(i); return i.fix ? `<label class="small"><input type="checkbox" data-fix="${k}" ${FIX_SEL.has(k) ? 'checked' : ''}> ${esc(i.fix.label)}</label>` : ''; } },
  ], M.issues);
}
// The definition with the selected fixes applied (and internal converter fields removed).
function fixedDefinition() {
  const d = structuredClone(M.src.def);
  for (const k of FIX_SEL) { try { M.issues[k]?.fix?.apply(d); } catch (e) { console.warn('Fix failed', e); } }
  return stripInternal(d);
}
function definitionFile(d) {
  const json = JSON.stringify(d, null, 2);
  const s = M.src;
  if (s.xmlText && !s.classic && /<definition>[\s\S]*?<\/definition>/.test(s.xmlText)) {
    const cdata = '<definition><![CDATA[\n' + json.replace(/]]>/g, ']]]]><![CDATA[>') + '\n]]></definition>';
    return { name: slug(M.title) + '.xml', text: s.xmlText.replace(/<definition>[\s\S]*?<\/definition>/, () => cdata), type: 'application/xml' };
  }
  return { name: slug(M.title) + (s.classic ? '-studio' : '') + '.json', text: json + '\n', type: 'application/json' };
}
function downloadDefinition() { const f = definitionFile(fixedDefinition()); download(f.name, f.text, f.type); }
function loadFixed() {
  const fixed = fixedDefinition();
  const src = { ...M.src, def: fixed, repairs: [], notes: [`Loaded with ${plural(FIX_SEL.size, 'fix', 'fixes')} applied. Download the definition from the Issues page to keep it.`] };
  DASH[CUR_I] = { src, model: buildModel(src) };
  selectDash(CUR_I, 'issues');
}

/* ---------- All dashboards (app-wide) ---------- */
function sharedItems() {
  const map = new Map();
  const add = (kind, name, i, detail) => {
    const k = kind + '\u0001' + name;
    if (!map.has(k)) map.set(k, { kind, name, uses: new Map() });
    const u = map.get(k).uses;
    if (!u.has(i)) u.set(i, new Set());
    if (detail) u.get(i).add(detail);
  };
  DASH.forEach((x, i) => {
    const m = x.model;
    for (const n of m.byKind('index')) add('Index', n.label, i);
    for (const n of m.byKind('sourcetype')) add('Sourcetype', n.label, i);
    for (const n of m.byKind('lookup')) add('Lookup', n.label, i, n.accessLabel);
    for (const n of m.byKind('macro')) add('Macro', n.key, i);
    for (const n of m.byKind('datamodel')) add('Data model', n.label, i, [...n.datasets].join(', '));
    for (const n of m.byKind('ds')) {
      if (n.type === 'ds.savedSearch' && n.ref) add('Saved search', n.ref, i, 'data source');
      for (const r of String(n.query || '').matchAll(/(?:^|\||\[)\s*savedsearch\s+("([^"]+)"|[^\s|\]]+)/gi)) add('Saved search', r[2] || r[1], i, '| savedsearch');
    }
  });
  return [...map.values()].sort((a, b) => b.uses.size - a.uses.size || a.kind.localeCompare(b.kind) || a.name.localeCompare(b.name));
}
function viewApp() {
  const sev = (m, s) => m.issues.filter(i => i.severity === s).length;
  const dashBtn = (i, detail) => `<button class="chip k-tab" data-dash="${i}" title="Open this dashboard">${esc(DASH[i].model.title)}${detail ? ` <span class="det">${esc(detail)}</span>` : ''}</button>`;
  const shared = sharedItems();
  return `${LOAD_ERRORS.length ? `<div class="error" style="margin-bottom:12px"><b>Some sources could not be loaded:</b><br>${LOAD_ERRORS.map(esc).join('<br>')}</div>` : ''}
  <p class="muted small">${plural(DASH.length, 'dashboard')} loaded. Open one to see its full inventory, or use the table below to see what the dashboards share.</p>
  ${table([
    { h: 'Dashboard', f: x => dashBtn(x.i) },
    { h: 'Source', f: x => `<span class="small">${esc(x.d.src.name || '')}</span><div class="muted small">${esc(x.d.model.format)}</div>` },
    { h: 'Tabs', f: x => String(x.d.model.byKind('tab').filter(t => !t.global).length) },
    { h: 'Panels', f: x => String(x.d.model.byKind('viz').length) },
    { h: 'Searches', f: x => String(x.d.model.byKind('ds').length) },
    { h: 'Inputs', f: x => String(x.d.model.byKind('input').length) },
    { h: 'Tokens', f: x => String(x.d.model.byKind('token').length) },
    { h: 'Errors', f: x => { const n = sev(x.d.model, 'error'); return n ? badge(n, 'sev-error') : '0'; } },
    { h: 'Warnings', f: x => { const n = sev(x.d.model, 'warning'); return n ? badge(n, 'sev-warning') : '0'; } },
  ], DASH.map((d, i) => ({ d, i })))}
  ${viewDashLinksSection()}
  <div class="section-title">Data sources across dashboards</div>
  <p class="muted small" style="margin:0 0 6px">Which dashboards read each index, lookup and data model. Band width is the number of base searches reading it. Click a dashboard to open it.</p>
  ${(() => { const sv = sankeyRender(appSankeyData()); return sv ? `<div class="graph-wrap sankey-wrap" style="margin-bottom:10px">${sv}</div>` : '<p class="muted">No search names an index, lookup or data model.</p>'; })()}
  <div class="section-title">Shared across dashboards</div>
  <p class="muted small" style="margin:0 0 6px">Indexes, sourcetypes, lookups, macros, data models and saved searches, with every dashboard that uses each. The most widely shared are listed first.</p>
  <div class="loader-actions" style="margin-bottom:8px"><button class="btn small" id="app-csv">Download app inventory (.csv)</button><button class="btn small" id="app-xlsx">Download app workbook (.xlsx)</button></div>
  ${table([
    { h: 'Kind', f: r => badge(r.kind) },
    { h: 'Name', f: r => `<code>${esc(r.name)}</code>` },
    { h: 'Dashboards', f: r => String(r.uses.size) },
    { h: 'Used by', f: r => `<div class="stack">${[...r.uses].map(([i, d]) => dashBtn(i, [...d].join(', '))).join('')}</div>` },
  ], shared)}`;
}
function exportAppCsv() {
  const rows = [['Dashboard', 'Source', 'Kind', 'Name', 'Detail']];
  for (const r of sharedItems()) for (const [i, d] of r.uses) rows.push([DASH[i].model.title, DASH[i].src.name || '', r.kind, r.name, [...d].join('; ')]);
  download('app-inventory.csv', '﻿' + csv(rows), 'text/csv;charset=utf-8');
}

/* ---------- Compare two versions ---------- */
let COMPARE = null; // { model, label }
function flattenObj(o, p = '', out = {}) {
  if (isObj(o)) { const ks = Object.keys(o); if (!ks.length && p) out[p] = '{}'; for (const k of ks) flattenObj(o[k], p ? p + '.' + k : k, out); }
  else if (Array.isArray(o)) {
    if (o.every(v => !isObj(v) && !Array.isArray(v))) out[p] = JSON.stringify(o);
    else o.forEach((v, i) => flattenObj(v, `${p}[${i}]`, out));
  } else out[p] = JSON.stringify(o);
  return out;
}
function itemSignature(n, m) {
  const ids = (list) => uniq(list).sort();
  const lbl = id => { const x = m.nodes.get(id); return x ? `${x.kind}:${x.kind === 'token' ? x.label : x.key}` : id; };
  const inn = (rels) => ids((m.inE.get(n.id) || []).filter(e => rels.includes(e.rel)).map(e => lbl(e.from)));
  const outn = (rels) => ids((m.outE.get(n.id) || []).filter(e => rels.includes(e.rel)).map(e => lbl(e.to)));
  switch (n.kind) {
    case 'tab': return { label: n.label, layoutType: n.layoutType, options: n.options || {}, placement: Object.fromEntries((n.items || []).map(i => [lbl(i.id), i.position ? `x${i.position.x} y${i.position.y} ${i.position.w}×${i.position.h}` : 'placed'])) };
    case 'token': return { status: n.status, setBy: inn(['sets', 'drilldown-sets', 'default', 'smart-source']), defaults: (n.defaults || []).map(d => fmt(d.value)), usedBy: outn(['uses-token']) };
    case 'index': case 'sourcetype': return { searchedBy: outn(['searches']) };
    case 'lookup': return { access: n.accessLabel, readBy: outn(['lookup-read']), writtenBy: inn(['lookup-write']) };
    case 'macro': return { usedBy: outn(['macro-used']) };
    case 'datamodel': return { datasets: [...n.datasets].sort(), readBy: outn(['datamodel-read']) };
    case 'dashboard': return { title: n.label, description: n.description || '' };
    default: return stripInternal(structuredClone(n.raw ?? {}));
  }
}
const DIFF_KINDS = ['dashboard', 'tab', 'input', 'ds', 'viz', 'condition', 'token', 'index', 'sourcetype', 'lookup', 'datamodel', 'macro'];
function diffModels(A, B) {
  const rows = [];
  for (const kind of DIFF_KINDS) {
    const a = new Map(A.byKind(kind).map(n => [n.key, n])), b = new Map(B.byKind(kind).map(n => [n.key, n]));
    for (const key of uniq([...a.keys(), ...b.keys()])) {
      const na = a.get(key), nb = b.get(key);
      if (!nb) { rows.push({ kind, key, label: na.label, status: 'removed', id: na.id, changes: [] }); continue; }
      if (!na) { rows.push({ kind, key, label: nb.label, status: 'added', changes: [] }); continue; }
      const fa = flattenObj(itemSignature(na, A)), fb = flattenObj(itemSignature(nb, B));
      const changes = uniq([...Object.keys(fa), ...Object.keys(fb)]).filter(k => fa[k] !== fb[k]).map(k => ({ path: k, a: fa[k], b: fb[k] }));
      if (changes.length) rows.push({ kind, key, label: nb.label, status: 'changed', id: na.id, changes, queryA: na.query, queryB: nb.query });
    }
  }
  return rows;
}
// Line diff (longest common subsequence) for SPL.
function lineDiff(a, b) {
  const x = String(a ?? '').split('\n'), y = String(b ?? '').split('\n');
  const n = x.length, m = y.length, L = Array.from({ length: n + 1 }, () => new Array(m + 1).fill(0));
  for (let i = n - 1; i >= 0; i--) for (let j = m - 1; j >= 0; j--) L[i][j] = x[i] === y[j] ? L[i + 1][j + 1] + 1 : Math.max(L[i + 1][j], L[i][j + 1]);
  const out = [];
  let i = 0, j = 0;
  while (i < n && j < m) { if (x[i] === y[j]) { out.push([' ', x[i]]); i++; j++; } else if (L[i + 1][j] >= L[i][j + 1]) out.push(['-', x[i++]]); else out.push(['+', y[j++]]); }
  while (i < n) out.push(['-', x[i++]]);
  while (j < m) out.push(['+', y[j++]]);
  return out;
}
const shortVal = v => { v = v === undefined ? '(none)' : String(v); return v.length > 140 ? v.slice(0, 139) + '…' : v; };
function viewCompare() {
  if (!COMPARE) {
    return `<div class="card">
      <p style="margin-top:0">Compare <b>${esc(M.title)}</b> (A, the dashboard open now) with another version (B). Paste or choose the other definition${DASH.length > 1 ? ', or pick one of the loaded dashboards' : ''}.</p>
      ${DASH.length > 1 ? `<p><label>Loaded dashboard: <select id="cmp-pick"><option value="">Choose…</option>${DASH.map((d, i) => i === CUR_I ? '' : `<option value="${i}">${esc(d.model.title)}</option>`).join('')}</select></label></p>` : ''}
      <textarea id="cmp-source" class="cmp-source" spellcheck="false" placeholder="Paste version B: Studio JSON, dashboard XML or a REST response."></textarea>
      <div class="loader-actions"><button class="btn primary" id="cmp-run">Compare</button><label class="btn">Choose file… <input type="file" id="cmp-file" accept=".json,.xml,.txt" hidden></label></div>
      <div class="error" id="cmp-error" hidden></div></div>`;
  }
  const rows = diffModels(M, COMPARE.model);
  const count = s => rows.filter(r => r.status === s).length;
  const stBadge = s => badge(s, s === 'added' ? 'ok' : s === 'removed' ? 'sev-error' : 'sev-warning');
  const item = r => r.id && M.nodes.has(r.id) ? chip(r.id) : `<span class="chip k-${r.kind}" style="cursor:default">${esc(r.kind === 'token' ? r.label : r.label || r.key)}</span>`;
  const changes = r => {
    if (r.status !== 'changed') return '';
    const q = r.changes.find(c => c.path === 'options.query');
    let html = r.changes.filter(c => c.path !== 'options.query').slice(0, 12).map(c => `<div class="small"><code>${esc(c.path)}</code>: <span class="del">${esc(shortVal(c.a))}</span> → <span class="ins">${esc(shortVal(c.b))}</span></div>`).join('');
    if (r.changes.length > 13) html += `<div class="muted small">…and ${r.changes.length - 12} more</div>`;
    if (q) html += `<pre class="diff">${lineDiff(r.queryA, r.queryB).map(([t, l]) => `<span class="${t === '+' ? 'ins' : t === '-' ? 'del' : ''}">${t} ${esc(l)}</span>`).join('\n')}</pre>`;
    return html;
  };
  return `<div class="card">
      <b>A:</b> ${esc(M.title)} <span class="muted small">(open now)</span> &nbsp; <b>B:</b> ${esc(COMPARE.label)}
      <div class="loader-actions" style="margin-top:8px"><button class="btn small" id="cmp-clear">Compare with something else</button><button class="btn small" id="cmp-md">Download changes (.md)</button><button class="btn small" id="cmp-map">Show changes on the relationship map</button></div>
    </div>
    <div class="stats">
      <div class="stat" style="--kc: var(--k-viz)"><div class="n">${count('added')}</div><div class="l">Added in B</div></div>
      <div class="stat" style="--kc: var(--sev-error)"><div class="n">${count('removed')}</div><div class="l">Removed in B</div></div>
      <div class="stat" style="--kc: var(--sev-warning)"><div class="n">${count('changed')}</div><div class="l">Changed</div></div>
    </div>
    ${rows.length ? table([
      { h: 'Change', f: r => stBadge(r.status) },
      { h: 'Kind', f: r => esc(KINDS[r.kind].label) },
      { h: 'Item', f: item },
      { h: 'What changed', f: changes },
    ], rows) : '<p>No differences: the two versions define the same items with the same settings.</p>'}`;
}
function startCompare(text, label) {
  const err = $('#cmp-error');
  try {
    const list = parseSources(text, label).filter(x => !x.error);
    if (!list.length) throw new Error('No dashboard was found in version B.');
    COMPARE = { model: buildModel(list[0]), label: list[0].def?.title || label || 'version B' };
    render();
  } catch (e) { if (err) { err.textContent = e.message; err.hidden = false; } }
}
function exportDiffMd() {
  const rows = diffModels(M, COMPARE.model);
  let md = `# Changes: ${M.title}\n\n- A: ${M.title}\n- B: ${COMPARE.label}\n\n`;
  for (const s of ['added', 'removed', 'changed']) {
    const list = rows.filter(r => r.status === s);
    md += `## ${s[0].toUpperCase() + s.slice(1)} (${list.length})\n\n`;
    for (const r of list) {
      md += `- **${KINDS[r.kind].label}** ${r.label || r.key} (\`${r.key}\`)\n`;
      for (const c of r.changes) md += c.path === 'options.query' ? `  - query:\n\n\`\`\`diff\n${lineDiff(r.queryA, r.queryB).map(([t, l]) => t + ' ' + l).join('\n')}\n\`\`\`\n\n` : `  - \`${c.path}\`: ${shortVal(c.a)} → ${shortVal(c.b)}\n`;
    }
    md += '\n';
  }
  download(slug(M.title) + '-changes.md', md, 'text/markdown;charset=utf-8');
}

/* ---------- Splunk configuration view ---------- */
function viewConfig() {
  const usedHere = key => M.nodes.has('macro:' + key);
  return `<p class="muted small" style="margin-top:0">Macro bodies, saved searches and data models live outside the dashboard. Paste them here (or choose the files) and the page expands them before it looks for indexes, sourcetypes, lookups, data models and commands. Items found this way are marked "via expansion" or "via saved search". It also checks macro argument counts. Nothing leaves this page.</p>
  <div class="cfg-grid">
    <div><label class="lbl2" for="cfg-conf">macros.conf and savedsearches.conf (one or both, pasted together)</label><textarea id="cfg-conf" class="cfg-text" spellcheck="false" placeholder="[my_macro(1)]&#10;args = field&#10;definition = stats count by $field$">${esc(CONFIG.conf)}</textarea></div>
    <div><label class="lbl2" for="cfg-dm">Data model JSON (one or more models, or a REST response)</label><textarea id="cfg-dm" class="cfg-text" spellcheck="false" placeholder='{"modelName": "Web", "objects": [ … ]}'>${esc(CONFIG.dm)}</textarea></div>
  </div>
  <div class="loader-actions" style="margin:8px 0 4px">
    <button class="btn primary" id="cfg-apply">Apply${DASH.length > 1 ? ' to all loaded dashboards' : ''}</button>
    <label class="btn">Choose .conf / .json files… <input type="file" id="cfg-file" multiple accept=".conf,.json,.txt" hidden></label>
    <button class="btn" id="cfg-sample">Load sample config</button>
    <button class="btn" id="cfg-clear">Clear</button>
  </div>
  ${CONFIG.errors.length ? `<div class="error">${CONFIG.errors.map(esc).join('<br>')}</div>` : ''}
  <div class="section-title">Macros (${CONFIG.macros.size})</div>
  ${table([
    { h: 'Macro', f: m => usedHere(m.key) ? chip('macro:' + m.key) : `<code>\`${esc(m.key)}\`</code>` },
    { h: 'Arguments', f: m => esc(m.args.join(', ')) || '—' },
    { h: 'Definition', cls: 'q', f: m => `<code>${esc(m.definition)}</code>${m.iseval ? ' <span class="badge">eval</span>' : ''}` },
    { h: 'Used in this dashboard', f: m => usedHere(m.key) ? 'yes' : '<span class="muted">no</span>' },
  ], [...CONFIG.macros.values()])}
  <div class="section-title">Saved searches (${CONFIG.saved.size})</div>
  ${table([
    { h: 'Name', f: s => `<code>${esc(s.name)}</code>` },
    { h: 'Search', cls: 'q', f: s => `<code>${esc(s.search)}</code>` },
    { h: 'Time range', f: s => s.earliest || s.latest ? `<code>${esc(s.earliest || '…')}</code> → <code>${esc(s.latest || 'now')}</code>` : '—' },
    { h: 'Schedule', f: s => s.cron ? `<code>${esc(s.cron)}</code>` : '—' },
  ], [...CONFIG.saved.values()])}
  <div class="section-title">Data models (${CONFIG.datamodels.size})</div>
  ${table([
    { h: 'Data model', f: d => M.nodes.has('datamodel:' + d.name) ? chip('datamodel:' + d.name) : `<code>${esc(d.name)}</code>` },
    { h: 'Datasets and constraints', cls: 'q', f: d => d.objects.map(o => `<div class="small"><b>${esc(o.name)}</b>${o.parent ? ` <span class="muted">(child of ${esc(o.parent)})</span>` : ''}${o.constraints.length ? `: <code>${esc(o.constraints.join(' '))}</code>` : ''}</div>`).join('') },
  ], [...CONFIG.datamodels.values()])}`;
}
function setConfig(conf, dm) {
  applyConfig(conf, dm);
  if (!DASH.length) return;
  DASH = DASH.map(x => ({ src: x.src, model: buildModel(x.src) }));
  M = DASH[CUR_I].model;
  FIX_SEL = new Set();
  render();
}
async function readConfigFiles(files) {
  let conf = $('#cfg-conf')?.value ?? CONFIG.conf, dm = $('#cfg-dm')?.value ?? CONFIG.dm;
  for (const f of files) {
    const t = await f.text();
    if (/\.json$/i.test(f.name) || /^\s*[{[]/.test(t)) dm = (dm ? dm + '\n' : '') + t; else conf = (conf ? conf + '\n' : '') + t;
  }
  return { conf, dm };
}

/* ---------- Printable summary ---------- */
function exportSummary() {
  const tabs = mockTabs();
  const prevTab = mockState.tab;
  const mocks = tabs.length ? tabs.map(t => ({ t, svg: mockupSvg(t.id, true) })) : [];
  mockState.tab = prevTab;
  const sev = s => M.issues.filter(i => i.severity === s).length;
  const lbl = id => M.nodes.get(id)?.label ?? id;
  const tbl = (head, rows) => rows.length ? `<table><thead><tr>${head.map(h => `<th>${esc(h)}</th>`).join('')}</tr></thead><tbody>${rows.map(r => `<tr>${r.map(c => `<td>${c}</td>`).join('')}</tr>`).join('')}</tbody></table>` : '<p class="m">None.</p>';
  const vals = (n, f) => (n['eff_' + f] || []).map(v => (v.excluded ? 'NOT ' : '') + v.value).join(', ');
  const html = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${esc(M.title)} · summary</title>
<style>
body{font:12.5px/1.45 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;color:#1b1f24;background:#fff;margin:24px auto;max-width:1000px;padding:0 16px}
h1{font-size:20px;margin:0 0 4px}h2{font-size:15px;margin:22px 0 6px;border-bottom:1px solid #dde1e7;padding-bottom:3px}
.m{color:#5f6b7a}table{border-collapse:collapse;width:100%;margin:4px 0 8px}th,td{border:1px solid #dde1e7;padding:4px 6px;text-align:left;vertical-align:top}
th{background:#f1f3f6}code{font:11.5px ui-monospace,Menlo,Consolas,monospace;white-space:pre-wrap;word-break:break-word}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:6px}.box{border:1px solid #dde1e7;border-radius:6px;padding:6px 8px}.box b{font-size:18px;display:block}
.mock svg{width:100%;height:auto;border:1px solid #dde1e7;border-radius:6px}.e{color:#c53030}.w{color:#b7791f}
.noprint{margin:10px 0}@media print{.noprint{display:none}body{margin:0}h2{break-after:avoid}.mock,table{break-inside:avoid}}
</style></head><body>
<div class="noprint"><button onclick="window.print()">Print</button></div>
<h1>${esc(M.title)}</h1>
<div class="m">${esc(M.description || '')}</div>
<div class="m">${esc(M.format)} · ${esc(M.layoutSummary)} · generated ${esc(new Date().toISOString().slice(0, 16).replace('T', ' '))}</div>
<h2>Summary</h2>
<div class="grid">${[['Tabs', tabs.length], ['Inputs', M.byKind('input').length], ['Data sources', M.byKind('ds').length], ['Visualizations', M.byKind('viz').length], ['Tokens', M.byKind('token').length], ['Indexes', M.byKind('index').length], ['Lookups', M.byKind('lookup').length], ['Macros', M.byKind('macro').length], ['Errors', sev('error')], ['Warnings', sev('warning')]].map(([l, n]) => `<div class="box"><b>${n}</b>${l}</div>`).join('')}</div>
${mocks.length ? `<h2>Layout</h2>${mocks.map(x => `<div class="mock"><div class="m">${esc(x.t.label)}</div>${x.svg}</div>`).join('')}` : ''}
<h2>Inputs and tokens</h2>
${tbl(['Token', 'Status', 'Set by', 'Default', 'Used by'], M.byKind('token').map(t => [`<code>${esc(t.label)}</code>`, esc(t.status), esc(ins(t.id, ['sets', 'drilldown-sets', 'default', 'smart-source']).map(e => lbl(e.from)).join(', ')), `<code>${esc((t.defaults || []).map(d => fmt(d.value)).join(', '))}</code>`, esc(uniq(outs(t.id, ['uses-token']).map(e => lbl(e.to))).join(', '))]))}
<h2>Data sources</h2>
${tbl(['Data source', 'Type', 'Reads', 'Time range', 'Feeds'], M.byKind('ds').map(n => [`<b>${esc(n.label)}</b><div class="m">${esc(n.key)}</div>`, esc(dsTypeLabel(n.type)) + (n.extend ? `<div class="m">extends ${esc(lbl('ds:' + n.extend))}</div>` : ''),
  esc([vals(n, 'index') && 'index: ' + vals(n, 'index'), vals(n, 'sourcetype') && 'sourcetype: ' + vals(n, 'sourcetype'), (n.eff_lookups || []).length && 'lookup: ' + n.eff_lookups.map(l => `${l.name} (${l.mode})`).join(', '), (n.eff_datamodels || []).length && 'data model: ' + n.eff_datamodels.map(d => d.model).join(', '), (n.eff_macros || []).length && 'macro: ' + uniq(n.eff_macros.map(x => x.key)).join(', ')].filter(Boolean).join(' · ')),
  n.earliest ? `<code>${esc(n.earliest.v)} → ${esc(n.latest.v)}</code>` : '', esc(outs(n.id, ['feeds', 'populates', 'extends']).map(e => lbl(e.to)).join(', '))]))}
<h2>Visualizations</h2>
${tbl(['Visualization', 'Type', 'Tab', 'Data source', 'Drilldown'], M.byKind('viz').map(n => [esc(withValues(n.label)), esc(shortType(n.type)), esc(tabsOf(n.id).map(lbl).join(', ')), esc(ins(n.id, ['feeds']).map(e => M.nodes.get(e.from).lineage.map(lbl).join(' › ')).join('; ')), esc(n.drilldowns.map(d => d.text).join('; '))]))}
<h2>Issues</h2>
${tbl(['Severity', 'Item', 'Issue'], M.issues.map(i => [`<span class="${i.severity[0]}">${esc(i.severity)}</span>`, esc(lbl(i.ref)), esc(i.message)]))}
</body></html>`;
  download(slug(M.title) + '-summary.html', html, 'text/html;charset=utf-8');
}

/* ---------- Inventory: every item in one table ---------- */
const INV_ORDER = ['tab', 'input', 'ds', 'viz', 'token', 'condition', 'index', 'sourcetype', 'lookup', 'datamodel', 'macro', 'command', 'defaults'];
const invState = { kind: '' };
function invItems() { return INV_ORDER.flatMap(k => M.byKind(k)); }
// Stable item numbers in inventory order, so #14 means the same item whatever the filter.
function invNo(id) {
  if (!M._invNo) M._invNo = new Map(invItems().map((n, i) => [n.id, i + 1]));
  return M._invNo.get(id) || '';
}
function invType(n) {
  switch (n.kind) {
    case 'ds': return dsTypeLabel(n.type);
    case 'viz': case 'input': return shortType(n.type);
    case 'token': return n.status;
    case 'tab': return n.global ? 'input bar' : (n.layoutType || 'canvas');
    case 'lookup': return n.accessLabel;
    case 'command': return n.category;
    case 'macro': return plural(n.arity, 'argument');
    case 'datamodel': return [...n.datasets].join(', ') || 'data model';
    case 'condition': return n.value.length > 60 ? n.value.slice(0, 59) + '…' : n.value;
    default: return KINDS[n.kind].label;
  }
}
function viewInventory() {
  const all = invItems();
  if (invState.kind && !all.some(n => n.kind === invState.kind)) invState.kind = '';
  const list = invState.kind ? all.filter(n => n.kind === invState.kind) : all;
  const kinds = INV_ORDER.filter(k => M.byKind(k).length);
  const btn = (k, label, count) => `<button class="chip ${k ? 'k-' + k : ''}" data-invkind="${k}" aria-pressed="${invState.kind === k}"${invState.kind === k ? ' style="font-weight:650;outline:2px solid var(--kc, var(--accent));outline-offset:1px"' : ''}>${esc(label)} <span class="det">${count}</span></button>`;
  const some = (edges, side) => {
    const ids = uniq(edges.map(e => e[side]));
    return ids.length ? `<div class="stack">${ids.slice(0, 4).map(x => chip(x)).join('')}${ids.length > 4 ? `<span class="muted small">+${ids.length - 4} more</span>` : ''}</div>` : '<span class="muted">—</span>';
  };
  return `<p class="muted small" style="margin-top:0">Every item in the dashboard in one place. Filter by kind, or type in the filter box. Click any item for its details and full lineage.</p>
  <div class="stack inv-kinds" style="margin-bottom:10px">${btn('', 'All', all.length)}${kinds.map(k => btn(k, KINDS[k].plural, M.byKind(k).length)).join('')}</div>
  <div class="loader-actions" style="margin-bottom:8px"><button class="btn small" id="inv-csv">Download inventory (.csv)</button></div>
  ${table([
    { h: '#', cls: 'num', f: n => String(invNo(n.id)) },
    { h: 'Item', f: n => chip(n.id) + issueMark(n.id) },
    { h: 'Kind', f: n => esc(KINDS[n.kind].label) },
    { h: 'ID', f: n => `<code>${esc(n.kind === 'token' ? n.label : n.key)}</code>` },
    { h: 'Type', f: n => esc(invType(n)) },
    { h: 'Placed on', f: n => chips(tabsOf(n.id).filter(x => x.startsWith('tab:'))) },
    { h: 'Depends on', f: n => some(ins(n.id).filter(e => e.rel !== 'contains'), 'from') },
    { h: 'Used by', f: n => some(outs(n.id).filter(e => e.rel !== 'contains'), 'to') },
  ], list)}`;
}

/* ---------- Recommendations: optimisations and best practice ----------
   Each: { impact: High|Medium|Low, category, title, why, how, example?, items: [node ids] } */
const IMPACT_ORDER = { High: 0, Medium: 1, Low: 2 };
const INDEXED_FIELDS = new Set(['host', 'source', 'sourcetype', 'index', '_time', 'splunk_server']);
function recommendations() {
  if (M._recs) return M._recs;
  const R = [];
  const add = (impact, category, title, why, how, items, example) => { if (items.length) R.push({ impact, category, title, why, how, example, items: uniq(items) }); };
  const ds = M.byKind('ds');
  const own = n => (n.sources?.commands || []).filter(c => !c.sub && !c.via);
  const roots = ds.filter(n => n.depth === 0 && n.type === 'ds.search');
  const descendants = n => [...closure(n.id, 'down')].filter(x => x.startsWith('ds:')).map(x => M.nodes.get(x));
  const firstSeg = n => { const c = own(n)[0]; return c && c.name === 'search' ? c.text.replace(/^search\s+/i, '').replace(/\s+/g, ' ').trim() : ''; };
  const restOf = n => { const q = String(n.query || ''); const i = q.indexOf('|'); return i < 0 ? '' : q.slice(i).trim(); };
  const tokVal = v => /\$/.test(String(v ?? ''));
  const timeInputs = M.byKind('input').filter(n => shortType(n.type) === 'timerange');

  // ---- Performance
  // Several base searches that start the same way: one base search with chains runs the scan once.
  const groups = new Map();
  for (const n of roots) {
    const seg = firstSeg(n);
    if (!seg || !/\b(index|sourcetype)\s*(=|::)/i.test(seg)) continue;
    const k = [seg.toLowerCase(), n.earliest?.v, n.latest?.v].join('\u0001');
    (groups.get(k) || groups.set(k, []).get(k)).push(n);
  }
  for (const g of groups.values()) if (g.length > 1) add('High', 'Performance', `Share one base search between ${plural(g.length, 'search', 'searches')} that start the same way`,
    `${g.map(n => n.label).join(', ')} all begin with the same search (${firstSeg(g[0])}) over the same time range, so Splunk scans the same events ${g.length} times.`,
    'Create one base search with the shared part, ending in | fields with the fields the panels need, and turn each search into a chain search (type ds.chain, "extend": the base search ID) that keeps only its own pipeline.',
    g.map(n => n.id),
    `Base search:\n${firstSeg(g[0])}\n| fields <fields the panels need>\n\n` + g.map(n => `Chain for ${n.label}:\n${restOf(n) || '| ...'}`).join('\n\n'));

  // stats/timechart count over indexed fields only: tstats reads the index files, not the raw events.
  const tstatsItems = [], tstatsEx = [];
  for (const n of ds) {
    if (n.type === 'ds.savedSearch') continue;
    const cmds = n.lineage.flatMap(id => own(M.nodes.get(id))).filter(c => c.name !== 'fields');
    if (cmds.length !== 2 || cmds[0].name !== 'search') continue;
    const terms = cmds[0].text.replace(/^search\s+/i, '').trim();
    const parts = terms.match(/"[^"]*"|\(|\)|[^\s()]+/g) || [];
    if (!parts.length || !parts.every(t => /^(\(|\)|OR|AND|NOT)$/.test(t) || /^(index|sourcetype|host|source)\s*(=|!=|::)/i.test(t))) continue;
    const m = cmds[1].text.match(/^(stats|timechart)\s+((?:span=\S+\s+)?)count(\s+as\s+\w+)?(?:\s+by\s+(.+))?$/i);
    if (!m) continue;
    const by = (m[4] || '').split(/[\s,]+/).filter(Boolean);
    if (!by.every(f => INDEXED_FIELDS.has(f))) continue;
    tstatsItems.push(n.id);
    const span = (m[2].match(/span=(\S+)/) || [])[1] || '1h';
    tstatsEx.push(`${n.label}:\n` + (m[1].toLowerCase() === 'stats'
      ? `| tstats count${m[3] || ''} where ${terms}${by.length ? ' by ' + by.join(' ') : ''}`
      : `| tstats prestats=t count where ${terms} by _time${by.length ? ' ' + by.join(' ') : ''} span=${span}\n| timechart span=${span} count${by.length ? ' by ' + by.join(' ') : ''}`));
  }
  add('High', 'Performance', 'Use tstats for counts over indexed fields',
    'These searches only count events by index, sourcetype, host, source or _time. tstats answers that from the index files without reading raw events, often many times faster.',
    'Rewrite the search with | tstats (see the example). If the panel needs other fields later, keep the raw search.', tstatsItems, tstatsEx.join('\n\n'));

  // index=* and leading wildcards
  add('High', 'Performance', 'Name the indexes instead of index=*',
    'index=* searches every index the viewer can read, which is slow and returns different results for different people.',
    'Replace index=* with the specific indexes, or a macro that lists them.',
    ds.filter(n => (n.sources?.index || []).some(v => v.value === '*' && !v.excluded)).map(n => n.id), 'index=web OR index=web_archive');
  add('Medium', 'Performance', 'Avoid wildcards at the start of search terms',
    'A term such as *error or field=*value can\'t use the index, so Splunk reads every event in range to check it.',
    'Search for the full term, put the wildcard only at the end (error*), or match it after narrowing the events (| where like(field, "%value")).',
    roots.filter(n => /(^|[\s="(])\*[A-Za-z0-9_]/.test(firstSeg(n).replace(/\bindex\s*=\s*\*/gi, ''))).map(n => n.id));

  // | search right after the base search
  add('Medium', 'Performance', 'Move | search filters into the base search',
    'A | search straight after the first search filters events after they have been retrieved. Putting the terms in the first search lets Splunk skip those events at the index.',
    'Add the | search terms to the search before the first pipe and remove the | search command.',
    ds.filter(n => n.type === 'ds.search' && own(n)[0]?.name === 'search' && own(n)[1]?.name === 'search').map(n => n.id));

  // | lookup before aggregation
  const lookupEarly = roots.filter(n => {
    const c = own(n), li = c.findIndex(x => x.name === 'lookup');
    if (li < 0) return false;
    return c.slice(li + 1).some(x => TRANSFORMING.has(x.name)) || descendants(n).some(d => own(d).some(x => TRANSFORMING.has(x.name)));
  });
  add('Medium', 'Performance', 'Run | lookup after aggregating',
    'A lookup on raw events runs once per event. After | stats it runs once per result row, which is usually far fewer.',
    'Move the | lookup after the | stats (in the chain searches, if the base search feeds several), and keep the lookup\'s key field in the stats by clause.',
    lookupEarly.map(n => n.id), '... | stats count by uri\n| lookup uri_owners.csv uri OUTPUT team');

  // Expensive commands
  const EXPENSIVE = {
    join: ['Medium', 'Replace | join with | stats', '| join runs a subsearch limited to 50,000 rows and 60 seconds by default, and silently drops the rest.', 'Search both sets of events together and combine them with | stats values(...) by <key field>.', '(index=a sourcetype=x) OR (index=b sourcetype=y)\n| stats values(field1) AS field1 values(field2) AS field2 by key'],
    transaction: ['Medium', 'Replace | transaction with | stats where possible', '| transaction holds events in memory and is one of the slowest commands; it also has event-count limits.', 'Group with | stats by the shared field, using min(_time), max(_time) and range(_time) for start, end and duration.', '| stats min(_time) AS start max(_time) AS end range(_time) AS duration values(action) AS actions by session_id'],
    map: ['Medium', 'Avoid | map', '| map runs a separate search for every input row (10 by default), multiplying load.', 'Rewrite as one search, using a subsearch or | stats to correlate.', ''],
    append: ['Low', 'Check | append subsearch limits', 'Subsearches stop at 50,000 results and 60 seconds by default, so appended results can be incomplete.', 'Prefer one search with OR between the event sets, or | multisearch for streaming searches.', ''],
    appendcols: ['Low', 'Check | appendcols subsearch limits', 'Subsearches stop at 50,000 results and 60 seconds by default, and appendcols aligns rows by position only.', 'Prefer one search with | stats by a shared field.', ''],
    selfjoin: ['Low', 'Avoid | selfjoin', '| selfjoin is memory-heavy.', 'Use | stats by the join field.', ''],
  };
  for (const [cmd, [impact, title, why, how, ex]] of Object.entries(EXPENSIVE))
    add(impact, 'Performance', title, why, how, ds.filter(n => (n.sources?.commands || []).some(c => c.name === cmd && !c.via)).map(n => n.id), ex || undefined);

  // Real-time, refresh, all time
  add('High', 'Performance', 'Avoid real-time searches',
    'Real-time searches (earliest=rt…) hold a search slot for as long as anyone has the dashboard open.',
    'Use a normal relative time range with a refresh interval instead, for example earliest=-15m with refresh 1m.',
    ds.filter(n => /^rt/i.test(n.earliest?.v || '') || /^rt/i.test(n.latest?.v || '')).map(n => n.id).concat(timeInputs.filter(n => /^rt/i.test(fmt(n.defaultValue))).map(n => n.id)));
  const seconds = v => { const m = String(v ?? '').trim().match(/^(\d+(?:\.\d+)?)\s*(s|m|h|d)?$/i); if (!m) return null; return +m[1] * ({ s: 1, m: 60, h: 3600, d: 86400 }[(m[2] || 's').toLowerCase()]); };
  add('Medium', 'Performance', 'Lengthen short refresh intervals',
    'Refreshing more often than once a minute reruns the search for every open copy of the dashboard and can exhaust search slots.',
    'Use 1m or longer, refresh only the panels that need it, or make the data a scheduled report.',
    ds.filter(n => { const s = seconds(n.refresh); return s !== null && s > 0 && s < 60; }).map(n => n.id));
  add('Medium', 'Performance', 'Avoid "All time" as a default time range',
    'A default of All time (earliest 0) makes every search scan all data each time the dashboard opens.',
    'Default to a bounded range such as the last 24 hours (-24h@h,now) and let people widen it.',
    timeInputs.filter(n => /^0?\s*,/.test(fmt(n.defaultValue)) || fmt(n.defaultValue) === '0').map(n => n.id)
      .concat(ds.filter(n => n.depth === 0 && n.earliest && (n.earliest.v === '0' || n.earliest.v === '')).map(n => n.id)));
  const indep = ds.filter(n => n.depth === 0 && (n.type === 'ds.search' || n.type === 'ds.savedSearch'));
  if (indep.length >= 8) add('Medium', 'Performance', `Reduce the ${indep.length} searches that run when the dashboard opens`,
    'Each base search uses a search slot. Many at once can queue behind the user\'s and the system\'s concurrency limits, making panels load slowly.',
    'Merge searches that read the same data into a base search with chains, move fixed panels to scheduled reports, and put rarely used panels on another tab or behind a condition.', indep.map(n => n.id));
  // Searches with no tokens could be a scheduled report
  add('Low', 'Performance', 'Consider scheduled reports for searches that never change',
    'These searches use no tokens, so every viewer runs the same search. A scheduled report runs once and every viewer reads its results.',
    'Save the search as a scheduled report and use it as a "Saved search" data source (ds.savedSearch).',
    roots.filter(n => !directTokens(n.id).length && !tokVal(n.earliest?.v) && !NO_EVENT_TIME.has(own(n)[0]?.name) && (M.outE.get(n.id) || []).some(e => ['feeds', 'extends'].includes(e.rel))).map(n => n.id));
  // sort default limit
  add('Low', 'Correctness', 'Give | sort an explicit limit',
    '| sort keeps only the first 10,000 results unless you give it a count, which can silently truncate tables.',
    'Use | sort 0 - field to keep everything, or | sort 20 - field when you only need the top rows.',
    ds.filter(n => own(n).some((c, i, all) => c.name === 'sort' && !/^sort\s+(\d+|limit\s*=)/i.test(c.text) && !all.slice(i + 1).some(x => x.name === 'head' || x.name === 'tail'))).map(n => n.id), '| sort 0 - count');
  // Input options from raw events
  add('Medium', 'Performance', 'Populate input options with tstats or a lookup',
    'This input\'s choices come from a search over raw events, which runs every time the dashboard loads.',
    'Use | tstats (for indexed fields such as host or sourcetype), | inputlookup, or | metadata to list the values.',
    M.byKind('input').filter(i => ins(i.id, ['populates']).some(e => { const d = M.nodes.get(e.from); return d && own(M.nodes.get(d.rootId) || d)[0]?.name === 'search'; })).map(n => n.id),
    '| tstats count where index=web by host\n| fields host');

  // ---- Correctness and security
  const textInputs = new Set(M.byKind('input').filter(n => shortType(n.type) === 'text' && n.token).map(n => n.token));
  const unescaped = M.usages.filter(u => textInputs.has(M.nodes.get(u.token)?.key) && M.nodes.get(u.node)?.kind === 'ds' && /query/.test(u.path) && !/\|s/.test(u.filters || ''));
  add('Medium', 'Security', 'Escape text-input tokens in SPL with |s',
    'A free-text input is pasted into the search as typed. Quotes or pipes in it can break the search or change what it does.',
    'Use $token|s$, which wraps the value in quotes and escapes it, instead of "$token$".',
    uniq([...unescaped.map(u => u.node), ...unescaped.map(u => ins(u.token, ['sets']).map(e => e.from)).flat()]),
    unescaped.length ? `${unescaped[0].raw.replace(/\$$/, '')}|s$   (instead of "${unescaped[0].raw}")` : undefined);
  add('Medium', 'Correctness', 'Give multiselect inputs a prefix and delimiter',
    'Without a delimiter the selected values are joined with spaces, which Splunk reads as AND: selecting 200 and 404 searches for events containing both.',
    'Set valuePrefix (for example status=) and delimiter " OR ", and wrap the token in parentheses in the search.',
    M.byKind('input').filter(n => shortType(n.type) === 'multiselect' && n.raw?.options?.delimiter === undefined && outs('token:' + n.token, ['uses-token']).length).map(n => n.id),
    '"options": { "token": "status", "valuePrefix": "status=", "delimiter": " OR " }\n... ($status$) ...');
  add('Medium', 'Usability', 'Give inputs a default value',
    'Searches that use these tokens wait until someone picks a value, so the panels start empty.',
    'Set defaultValue on the input (for example * for "all").',
    M.byKind('input').filter(n => n.token && n.defaultValue === undefined && outs('token:' + n.token, ['uses-token']).some(e => e.to.startsWith('ds:'))).map(n => n.id));

  // ---- Maintainability
  const directIdx = new Map();
  for (const n of roots) for (const v of n.sources?.index || []) if (!v.excluded && !v.via && !v.value.includes('$') && v.value !== '*') (directIdx.get(v.value) || directIdx.set(v.value, []).get(v.value)).push(n.id);
  for (const [idx, ids] of directIdx) if (ids.length >= 3) add('Low', 'Maintainability', `Put index=${idx} in a macro`,
    `index=${idx} is written out in ${ids.length} searches. If the index changes, every search has to be edited.`,
    'Define a macro for the index list and use it in each search.', ids, `macros.conf:\n[${idx}_indexes]\ndefinition = (index=${idx})\n\nSearch:\n\`${idx}_indexes\` sourcetype=...`);
  add('Low', 'Maintainability', 'Flatten deep chain searches',
    'Chains three or more levels deep are hard to follow and debug, because each level only shows its own part of the SPL.',
    'Collapse intermediate chains where they only filter, so each chain extends the base search directly.',
    ds.filter(n => n.depth >= 3).map(n => n.id));
  add('Low', 'Maintainability', 'Give data sources descriptive names',
    'Data sources named like "Search_1" or with no name are hard to tell apart in the editor and in smart-source tokens.',
    'Set name to what the search returns, for example "Errors by URI".',
    // Classic searches are named after their id by the converter, so only Studio names are checked.
    M.src.classic ? [] : ds.filter(n => !n.name || n.name === n.key || /^(search|ds|chain|base)[ _]?\d+$/i.test(n.name)).map(n => n.id));
  const STATIC = /^(markdown|image|rectangle|ellipse|line|text)$/;
  add('Low', 'Usability', 'Add titles to panels',
    'Panels without a title don\'t say what they show, and are hard to find in the editor.',
    'Set title on each chart and table.',
    M.byKind('viz').filter(n => !n.title && !STATIC.test(shortType(n.type))).map(n => n.id));
  const byTitle = new Map();
  for (const v of M.byKind('viz')) if (v.title) (byTitle.get(v.title) || byTitle.set(v.title, []).get(v.title)).push(v.id);
  for (const [t, ids] of byTitle) if (ids.length > 1) add('Low', 'Usability', `Make the ${ids.length} panels titled "${t}" distinguishable`,
    'Several panels share one title, so viewers can\'t tell what each shows.', 'Give each panel a title that says what it measures.', ids);

  // ---- Usability
  if (timeInputs.length) add('Low', 'Usability', 'Panels that don\'t follow the time picker',
    'These searches set their own time range, so changing the time picker doesn\'t change them. That is sometimes intended, but often surprises viewers.',
    'If it is intended, say so in the panel title (for example "last 7 days"); otherwise use the time picker\'s tokens.',
    roots.filter(n => n.earliest?.src === 'own' && !tokVal(n.earliest.v) && !NO_EVENT_TIME.has(own(n)[0]?.name)).map(n => n.id)
      .concat(roots.filter(n => /\bearliest\s*=\s*[^$\s]/i.test(firstSeg(n))).map(n => n.id)));
  const tabs = M.byKind('tab').filter(t => !t.global);
  add('Low', 'Usability', 'Prefer the grid layout for dashboards viewed on different screens',
    'Absolute layouts keep fixed pixel positions, so they don\'t adapt to smaller screens or other window sizes.',
    'Use the grid layout unless the dashboard needs free positioning (diagrams, overlays, background images).',
    tabs.filter(t => t.layoutType === 'absolute' && (t.items || []).some(i => i.id.startsWith('viz:'))).map(t => t.id));
  add('Low', 'Usability', 'Split crowded tabs',
    'More than 12 panels on one tab makes it slow to load and hard to read, because every panel\'s search runs at once.',
    'Group related panels onto separate tabs; searches only on hidden tabs still run, so also check the search count.',
    tabs.filter(t => (t.items || []).filter(i => i.id.startsWith('viz:')).length > 12).map(t => t.id));

  accessibilityRecs(add);

  R.sort((a, b) => IMPACT_ORDER[a.impact] - IMPACT_ORDER[b.impact] || a.category.localeCompare(b.category));
  M._recs = R;
  return R;
}
const impactBadge = i => badge(i, i === 'High' ? 'sev-error' : i === 'Medium' ? 'sev-warning' : 'sev-info');
function viewRecommendations() {
  const recs = recommendations();
  if (!recs.length) return '<p>No recommendations: nothing here matched the optimisation and best-practice checks.</p>';
  const count = (k, v) => recs.filter(r => r[k] === v).length;
  const cats = uniq(recs.map(r => r.category));
  return `<p class="muted small" style="margin-top:0">Ways to make the dashboard faster, easier to maintain and safer. Unlike issues, nothing here is broken; each item is a suggested improvement, with why it matters and what to change. They're based on the definition and SPL alone, so check them against how the dashboard is used.</p>
  <div class="stats">
    ${['High', 'Medium', 'Low'].map(i => `<div class="stat" style="--kc: var(--sev-${i === 'High' ? 'error' : i === 'Medium' ? 'warning' : 'info'})"><div class="n">${count('impact', i)}</div><div class="l">${i} impact</div></div>`).join('')}
    <div class="stat"><div class="n">${cats.length}</div><div class="l">Categories</div><div class="s">${esc(cats.map(c => `${c} ${count('category', c)}`).join(' · '))}</div></div>
  </div>
  ${recs.map(r => `<div class="card rec filterable">
    <div class="rec-head">${impactBadge(r.impact)} ${badge(r.category)} <b>${esc(r.title)}</b></div>
    <p>${esc(r.why)}</p>
    <p><b>What to do:</b> ${esc(r.how)}</p>
    ${r.example ? `<pre>${esc(r.example)}</pre>` : ''}
    <div class="relgroup"><div class="rl">Applies to (${r.items.length})</div>${chips(r.items)}</div>
  </div>`).join('')}`;
}

function viewConditions() {
  return table([
    { h: 'Condition', f: n => chip(n.id) + issueMark(n.id) },
    { h: 'ID', f: n => `<code>${esc(n.key)}</code>` },
    { h: 'Expression', cls: 'q', f: n => `<code>${esc(n.value)}</code>` },
    { h: 'Uses tokens', f: n => chips(directTokens(n.id)) },
    { h: 'Controls', f: n => chips(outs(n.id, ['visibility']).map(e => [e.to, e.detail])) },
  ], M.byKind('condition'));
}

function viewRelationships() {
  const groups = { data: 'Data flow', token: 'Token flow', layout: 'Layout', vis: 'Visibility' };
  return `<p class="muted small">Every connection, written as “from → relationship → to”. Edges follow the direction data and token values flow.</p>` + table([
    { h: 'From', f: e => chip(e.from) },
    { h: 'Relationship', f: e => `${esc(REL[e.rel].fwd)}` },
    { h: 'To', f: e => chip(e.to) },
    { h: 'Detail', f: e => e.detail ? `<code>${esc(e.detail)}</code>` : '' },
    { h: 'Kind', f: e => badge(groups[REL[e.rel].group]) },
  ], M.edges);
}

function issueTable(list) {
  return table([
    { h: 'Severity', f: i => sevBadge(i.severity) },
    { h: 'Item', f: i => chip(i.ref) },
    { h: 'Issue', f: i => esc(i.message) },
  ], list);
}

/* ============================================================
   Relationship map (SVG)
   ============================================================ */
const ELK_LIB = libUrl('https://cdn.jsdelivr.net/npm/elkjs@0.11.1/lib/elk.bundled.js', 'lib/elk.bundled.js');
const GW = 196, GH = 36; // node box size on the map
const graphSub = n => n.kind === 'group' ? n.sub : n.kind === 'ds' ? dsTypeLabel(n.type) : n.kind === 'viz' ? shortType(n.type) : n.kind === 'input' ? shortType(n.type) + (n.token ? ' → $' + n.token + '$' : '')
  : n.kind === 'token' ? n.status : n.kind === 'index' ? 'index' : n.kind === 'sourcetype' ? 'sourcetype' : n.kind === 'lookup' ? 'lookup · ' + n.accessLabel : n.kind === 'datamodel' ? 'data model'
  : n.kind === 'macro' ? 'macro' : n.kind === 'command' ? 'command · ' + n.category.toLowerCase() : n.kind === 'tab' ? (n.layoutType || 'tab') : n.kind === 'condition' ? 'condition' : n.kind === 'defaults' ? 'defaults' : 'dashboard';
const gtrunc = (s, n) => (s = String(s)).length > n ? s.slice(0, n - 1) + '…' : s;
const SOURCE_KINDS = /^(index|sourcetype|lookup|datamodel|macro):/;

/* ---------- The graph the map draws: this dashboard, or this dashboard plus the changes from Compare ---------- */
let _gm = null;
function graphModel() {
  const B = graphState.overlay && COMPARE ? COMPARE.model : null;
  if (_gm && _gm.M === M && _gm.B === B) return _gm;
  const nodes = new Map(M.nodes), status = new Map();
  const edges = M.edges.map(e => ({ ...e }));
  if (B) {
    const key = e => e.from + '\u0001' + e.to + '\u0001' + e.rel;
    const inA = new Set(M.edges.map(key)), inB = new Set(B.edges.map(key));
    for (const e of edges) if (!inB.has(key(e))) e.change = 'removed';
    const seen = new Set();
    for (const e of B.edges) if (!inA.has(key(e)) && !seen.has(key(e))) { seen.add(key(e)); edges.push({ ...e, change: 'added' }); }
    for (const [id, n] of B.nodes) if (!nodes.has(id)) { nodes.set(id, n); status.set(id, 'added'); }
    for (const id of M.nodes.keys()) if (!B.nodes.has(id)) status.set(id, 'removed');
    for (const r of diffModels(M, B)) if (r.status === 'changed') status.set(r.kind + ':' + r.key, 'changed');
  }
  const inE = new Map(), outE = new Map();
  for (const id of nodes.keys()) { inE.set(id, []); outE.set(id, []); }
  for (const e of edges) { outE.get(e.from)?.push(e); inE.get(e.to)?.push(e); }
  _gm = { M, B, nodes, edges, inE, outE, status };
  return _gm;
}
// Tokens used by so many items that their lines would swamp the map: shown as badges instead.
function hubTokens(G) {
  const out = new Map();
  if (!graphState.hubMin) return out;
  for (const [id, n] of G.nodes) if (n.kind === 'token') {
    const users = new Set((G.outE.get(id) || []).filter(e => e.rel === 'uses-token').map(e => e.to));
    if (users.size >= graphState.hubMin) out.set(id, users.size);
  }
  return out;
}
const kindHidden = id => (!graphState.tokens && /^(token|input|defaults|condition):/.test(id)) || (!graphState.sources && SOURCE_KINDS.test(id)) || (!graphState.commands && id.startsWith('command:'));
function defaultCenter() {
  const viz = M.byKind('viz');
  return (viz.find(v => outs(v.id, ['contains']).length && ins(v.id, ['feeds']).length) || viz.find(v => ins(v.id, ['feeds']).length) || viz[0] || invItems()[0])?.id || null;
}
// Everything reachable from `start` in one direction, ignoring the dashboard root.
function reach(G, start, up, maxDepth = 99, stop = () => false) {
  const seen = new Set([start]);
  let frontier = [start];
  for (let d = 0; d < maxDepth && frontier.length; d++) {
    const next = [];
    for (const id of frontier) for (const e of (up ? G.inE : G.outE).get(id) || []) {
      const x = up ? e.from : e.to;
      if (x.startsWith('dashboard:') || seen.has(x)) continue;
      seen.add(x);
      if (!stop(x)) next.push(x);
    }
    frontier = next;
  }
  seen.delete(start);
  return seen;
}
// Which items to show, before collapsing.
function visibleSet(G, hubs) {
  if (graphState.mode === 'path') return pathInfo(G).ids;
  if (graphState.mode === 'focus') {
    if (!graphState.center || !G.nodes.has(graphState.center)) graphState.center = defaultCenter();
    const c = graphState.center;
    if (!c) return new Set();
    const depth = graphState.depth === 'all' ? 99 : +graphState.depth;
    const hub = x => hubs.has(x) && x !== c;
    const ids = new Set([c]);
    for (const up of [true, false]) for (const x of reach(G, c, up, depth, hub)) if (x === c || (!kindHidden(x) && !hub(x))) ids.add(x);
    return ids;
  }
  let ids = new Set([...G.nodes.keys()].filter(id => !id.startsWith('dashboard:')));
  if (graphState.focus) ids = new Set([graphState.focus, ...reach(G, graphState.focus, true)]);
  for (const id of [...ids]) if (kindHidden(id) || hubs.has(id)) ids.delete(id);
  return ids;
}
/* ---------- Path between two items ---------- */
function pathInfo(G) {
  const a = graphState.pathFrom, b = graphState.pathTo;
  if (!a || !b || !G.nodes.has(a) || !G.nodes.has(b) || a === b) return { ids: new Set([a, b].filter(x => x && G.nodes.has(x))), routes: 0, msg: a && b && a === b ? 'Pick two different items.' : 'Pick the two items to connect.' };
  const route = (s, t) => {
    const down = reach(G, s, false), up = reach(G, t, true);
    if (!down.has(t)) return null;
    const ids = new Set([s, t, ...[...down].filter(x => up.has(x))]);
    const onRoute = e => ids.has(e.from) && ids.has(e.to) && (e.from === s || down.has(e.from)) && (e.to === t || up.has(e.to));
    // Count routes and the shortest one (memoised walk; guarded against loops).
    const memo = new Map();
    const count = (id, stack) => {
      if (id === t) return 1;
      if (memo.has(id)) return memo.get(id);
      if (stack.has(id)) return 0;
      stack.add(id);
      let n = 0;
      for (const e of G.outE.get(id) || []) if (onRoute(e)) n += count(e.to, stack);
      stack.delete(id);
      memo.set(id, n);
      return n;
    };
    const dist = new Map([[s, 0]]), q = [s];
    while (q.length) { const id = q.shift(); for (const e of G.outE.get(id) || []) if (onRoute(e) && !dist.has(e.to)) { dist.set(e.to, dist.get(id) + 1); q.push(e.to); } }
    return { ids, onRoute, routes: Math.min(count(s, new Set()), 1e6), shortest: dist.get(t) };
  };
  const lbl = id => G.nodes.get(id)?.label ?? id;
  let r = route(a, b);
  if (r) return { ...r, msg: `${plural(r.routes, 'route')} from ${lbl(a)} to ${lbl(b)}; the shortest is ${plural(r.shortest, 'step')}.` };
  r = route(b, a);
  if (r) return { ...r, reversed: true, msg: `Nothing flows from ${lbl(a)} to ${lbl(b)}, but ${plural(r.routes, 'route')} ${r.routes === 1 ? 'runs' : 'run'} the other way, from ${lbl(b)} to ${lbl(a)} (shortest ${plural(r.shortest, 'step')}).` };
  return { ids: new Set([a, b]), routes: 0, msg: `${lbl(a)} and ${lbl(b)} aren't connected: changing one doesn't affect the other.` };
}
/* ---------- Collapsing: tabs, chain families, sources, commands ---------- */
function isCollapsed(key, flag) { return graphState.toggled.has(key) ? graphState.toggled.get(key) : !!graphState.collapse[flag]; }
function collapseMap(G, ids) {
  const rep = new Map(), synth = new Map(), members = new Map();
  const add = (id, r) => { rep.set(id, r); if (r !== id) (members.get(r) || members.set(r, []).get(r)).push(id); };
  const group = (gid, label, kinds) => { if (!synth.has(gid)) synth.set(gid, { id: gid, kind: 'group', key: gid, label, sub: '', kinds }); return gid; };
  for (const id of ids) {
    const n = G.nodes.get(id);
    let r = id;
    if (n.kind === 'viz' || n.kind === 'input') {
      const tab = (G.outE.get(id) || []).find(e => e.rel === 'contains' && ids.has(e.to))?.to;
      if (tab && isCollapsed(tab, 'tabs')) r = tab;
    } else if (n.kind === 'ds' && n.rootId && n.rootId !== id && G.nodes.has(n.rootId) && isCollapsed(n.rootId, 'chains')) r = n.rootId;
    else if (SOURCE_KINDS.test(id) && isCollapsed('group:sources', 'sources')) r = group('group:sources', 'Sources', 'indexes, sourcetypes, lookups, data models, macros');
    else if (n.kind === 'command' && isCollapsed('group:commands', 'commands')) r = group('group:commands', 'SPL commands', 'commands');
    add(id, r);
  }
  for (const [gid, s] of synth) { const m = members.get(gid) || []; s.label = `${s.label} (${m.length})`; s.sub = 'collapsed · click + to expand'; }
  return { rep, synth, members };
}
// Collapsible items and their current state: tab boxes, base searches with chains, and the groups.
function toggleState(G, id, members) {
  const n = G.nodes.get(id);
  if (id.startsWith('group:')) return { key: id, collapsed: true };
  if (n?.kind === 'tab' && (G.inE.get(id) || []).some(e => e.rel === 'contains')) return { key: id, collapsed: isCollapsed(id, 'tabs') };
  if (n?.kind === 'ds' && n.depth === 0 && (G.outE.get(id) || []).some(e => e.rel === 'extends')) return { key: id, collapsed: isCollapsed(id, 'chains') };
  if (SOURCE_KINDS.test(id)) return { key: 'group:sources', collapsed: false };
  if (n?.kind === 'command') return { key: 'group:commands', collapsed: false };
  return null;
}
// The nodes and edges to draw, after collapsing. Edges between the same pair are merged.
function graphScene() {
  const G = graphModel();
  const hubs = graphState.mode === 'path' ? new Map() : hubTokens(G);
  const raw = visibleSet(G, hubs);
  const pathCut = graphState.mode === 'path' ? pathInfo(G) : null;
  const cm = graphState.mode === 'path' ? { rep: new Map([...raw].map(id => [id, id])), synth: new Map(), members: new Map() } : collapseMap(G, raw);
  const getNode = id => cm.synth.get(id) || G.nodes.get(id);
  const ids = new Set([...raw].map(id => cm.rep.get(id) || id));
  const edges = [], seen = new Map();
  for (const e of G.edges) {
    if (!raw.has(e.from) || !raw.has(e.to)) continue;
    if (pathCut?.onRoute && !pathCut.onRoute(e)) continue;
    const f = cm.rep.get(e.from), t = cm.rep.get(e.to);
    if (!f || !t || f === t) continue;
    const k = f + '\u0001' + t + '\u0001' + e.rel;
    if (seen.has(k)) { const x = seen.get(k); x.n++; if (e.change) x.change ||= e.change; continue; }
    const x = { from: f, to: t, rel: e.rel, detail: e.detail, change: e.change, n: 1 };
    seen.set(k, x); edges.push(x);
  }
  // Hub tokens each item uses (directly, or through the items folded into it).
  const hubsOf = new Map();
  if (hubs.size) for (const id of ids) {
    const mem = [id, ...(cm.members.get(id) || [])];
    const used = uniq(mem.flatMap(m => (G.inE.get(m) || []).filter(e => e.rel === 'uses-token' && hubs.has(e.from)).map(e => e.from)));
    if (used.length) hubsOf.set(id, used);
  }
  return { G, ids, edges, getNode, cm, hubs, hubsOf, path: pathCut };
}

function renderGraph(root) {
  const G = graphModel();
  const mode = graphState.mode;
  if (mode === 'focus' && (!graphState.center || !G.nodes.has(graphState.center))) graphState.center = defaultCenter();
  const tabs = M.byKind('tab').sort((a, b) => a.order - b.order);
  const itemOptions = sel => INV_ORDER.filter(k => M.byKind(k).length).map(k => `<optgroup label="${esc(KINDS[k].plural)}">${M.byKind(k).map(n => `<option value="${esc(n.id)}" ${sel === n.id ? 'selected' : ''}>#${invNo(n.id)} ${esc(n.label)}</option>`).join('')}</optgroup>`).join('');
  const seg = (k, label) => `<button data-gmode="${k}" aria-pressed="${mode === k}">${label}</button>`;
  const hubs = hubTokens(G);
  const ov = COMPARE ? `<label title="Colour what changed between this dashboard (A) and ${esc(COMPARE.label)} (B)"><input type="checkbox" id="g-overlay" ${graphState.overlay ? 'checked' : ''}> Show changes vs ${esc(gtrunc(COMPARE.label, 30))}</label>` : '';
  const p = mode === 'path' ? pathInfo(G) : null;
  root.innerHTML = `<div class="graph-controls">
    <div class="seg" role="group" aria-label="What to show">${seg('focus', 'Focus on one item')}${seg('path', 'Path between two')}${seg('all', 'Whole dashboard')}</div>
    ${mode === 'focus' ? `<label>Item <select id="g-center">${itemOptions(graphState.center)}</select></label>
      <label>Steps each way <select id="g-depth">${['1', '2', '3', '4', 'all'].map(d => `<option value="${d}" ${String(graphState.depth) === d ? 'selected' : ''}>${d === 'all' ? 'All' : d}</option>`).join('')}</select></label>`
    : mode === 'path' ? `<label>From <select id="g-from"><option value="">Choose…</option>${itemOptions(graphState.pathFrom)}</select></label>
      <label>To <select id="g-to"><option value="">Choose…</option>${itemOptions(graphState.pathTo)}</select></label>`
    : `<label>Tab <select id="g-focus"><option value="">All tabs</option>${tabs.map(t => `<option value="${esc(t.id)}" ${graphState.focus === t.id ? 'selected' : ''}>${esc(t.label)} (and everything feeding it)</option>`).join('')}</select></label>`}
    <label>Layout <select id="g-layout"><option value="columns" ${graphState.layout === 'columns' ? 'selected' : ''}>Columns</option><option value="elk" ${graphState.layout === 'elk' ? 'selected' : ''}>Layered, grouped by tab (ELK)</option></select></label>
  </div>
  <div class="graph-controls">
    <input class="search" id="g-find" list="g-find-list" placeholder="Find an item…" aria-label="Find an item on the map" style="min-width:200px">
    <datalist id="g-find-list">${invItems().map(n => `<option value="#${invNo(n.id)} ${esc(n.label)}">${esc(KINDS[n.kind].label)}</option>`).join('')}</datalist>
    <span class="zoomctl" role="group" aria-label="Zoom"><button class="btn small" id="g-zout" title="Zoom out">−</button><span id="g-zlabel">${Math.round(graphState.zoom * 100)}%</span><button class="btn small" id="g-zin" title="Zoom in">+</button><button class="btn small" id="g-zfit">Fit</button><button class="btn small" id="g-z100">100%</button></span>
    <button class="btn small" id="g-svg">Export SVG</button><button class="btn small" id="g-png">Export PNG</button>
  </div>
  ${mode !== 'path' ? `<div class="graph-controls">
    <label><input type="checkbox" id="g-tokens" ${graphState.tokens ? 'checked' : ''}> Inputs, tokens and conditions</label>
    <label><input type="checkbox" id="g-sources" ${graphState.sources ? 'checked' : ''}> Sources and macros</label>
    <label><input type="checkbox" id="g-commands" ${graphState.commands ? 'checked' : ''}> SPL commands</label>
    <label title="Tokens used by at least this many items are shown as a badge on each item instead of as lines">Hub tokens <select id="g-hub">${[0, 3, 4, 5, 6, 8].map(v => `<option value="${v}" ${graphState.hubMin === v ? 'selected' : ''}>${v ? 'badge if used by ' + v + '+' : 'always draw lines'}</option>`).join('')}</select></label>
    <span class="small muted">Collapse:</span>${['tabs', 'chains', 'sources', 'commands'].map(f => `<label><input type="checkbox" data-gcollapse="${f}" ${graphState.collapse[f] ? 'checked' : ''}> ${f === 'chains' ? 'chain searches' : f === 'sources' ? 'sources' : f === 'commands' ? 'commands' : 'tabs'}</label>`).join('')}
    ${ov}
  </div>` : `<div class="graph-controls">${ov}</div>`}
  <div class="legend graph-legend"><span><i style="border-color:var(--e-data)"></i>data</span><span><i style="border-color:var(--e-token)"></i>token</span><span><i style="border-color:var(--e-vis)"></i>visibility</span><span><i style="border-color:var(--e-layout)"></i>layout</span><span><i style="border-color:var(--muted);border-top-style:dashed"></i>flows back</span>
    ${hubs.size && mode !== 'path' ? `<span>Hub tokens as badges: ${[...hubs].map(([id, n]) => `<b>${esc(G.nodes.get(id).label)}</b> (${n})`).join(', ')}</span>` : ''}
    ${graphState.overlay && COMPARE ? '<span class="chg-key"><i class="ck-added"></i>added in B</span><span class="chg-key"><i class="ck-removed"></i>removed in B</span><span class="chg-key"><i class="ck-changed"></i>changed</span>' : ''}</div>
  <p class="muted small" style="margin:4px 0 8px">${mode === 'focus'
    ? `Showing <b>${esc(G.nodes.get(graphState.center)?.label || '—')}</b> and what it depends on and what depends on it, ${graphState.depth === 'all' ? 'all the way' : plural(+graphState.depth, 'step') + ' each way'}. Click an item to move the focus to it.`
    : mode === 'path' ? esc(p.msg) : 'Every item. Click an item to highlight its lineage and open its details; click empty space to clear.'}
    Drag to pan, Ctrl+scroll (or pinch) to zoom, arrow keys to move between connected items. <b>+</b>/<b>−</b> on a box collapses or expands it.</p>
  <div class="graph-wrap" id="g-wrap" tabindex="-1"></div>`;
  const redraw = () => { graphState.selected = graphState.mode === 'focus' ? graphState.center : null; drawGraph(); };
  root.querySelectorAll('[data-gmode]').forEach(b => b.onclick = () => {
    graphState.mode = b.dataset.gmode; graphState.selected = null;
    if (graphState.mode === 'path' && !graphState.pathFrom) { graphState.pathFrom = M.byKind('input')[0]?.id || null; graphState.pathTo = graphState.center; }
    render();
  });
  const on = (id, ev, fn) => { const el = $('#' + id); if (el) el[ev] = fn; };
  on('g-center', 'onchange', e => { graphState.center = e.target.value; render(); });
  on('g-depth', 'onchange', e => { graphState.depth = e.target.value; render(); });
  on('g-from', 'onchange', e => { graphState.pathFrom = e.target.value; render(); });
  on('g-to', 'onchange', e => { graphState.pathTo = e.target.value; render(); });
  on('g-focus', 'onchange', e => { graphState.focus = e.target.value; redraw(); });
  on('g-layout', 'onchange', e => { graphState.layout = e.target.value; redraw(); });
  on('g-tokens', 'onchange', e => { graphState.tokens = e.target.checked; redraw(); });
  on('g-sources', 'onchange', e => { graphState.sources = e.target.checked; redraw(); });
  on('g-commands', 'onchange', e => { graphState.commands = e.target.checked; redraw(); });
  on('g-hub', 'onchange', e => { graphState.hubMin = +e.target.value; render(); });
  on('g-overlay', 'onchange', e => { graphState.overlay = e.target.checked; render(); });
  root.querySelectorAll('[data-gcollapse]').forEach(c => c.onchange = () => { graphState.collapse[c.dataset.gcollapse] = c.checked; graphState.toggled.clear(); redraw(); });
  on('g-zin', 'onclick', () => setZoom(graphState.zoom * 1.25));
  on('g-zout', 'onclick', () => setZoom(graphState.zoom / 1.25));
  on('g-z100', 'onclick', () => setZoom(1));
  on('g-zfit', 'onclick', fitGraph);
  on('g-svg', 'onclick', () => { const s = exportableSvg($('#g-wrap svg')); if (s) download(slug(M.title) + '-map.svg', s, 'image/svg+xml'); });
  on('g-png', 'onclick', async () => { const s = exportableSvg($('#g-wrap svg')); if (s) await downloadPng(s, slug(M.title) + '-map.png'); });
  on('g-find', 'onchange', e => findOnMap(e.target.value));
  if (mode === 'focus') graphState.selected = graphState.center;
  drawGraph();
}
function findOnMap(text) {
  const m = String(text).match(/^#(\d+)\b/);
  const n = m ? invItems()[+m[1] - 1] : invItems().find(x => x.label.toLowerCase() === String(text).trim().toLowerCase());
  if (!n) { toast('No item matches "' + text + '".', 3000); return; }
  const id = n.id;
  if (graphState.mode === 'focus') { graphState.center = id; render(); return; }
  if (graphState.mode === 'path') { if (!graphState.pathFrom || graphState.pathTo) { graphState.pathFrom = id; graphState.pathTo = null; } else graphState.pathTo = id; render(); return; }
  if (kindHidden(id)) { if (/^(token|input|defaults|condition):/.test(id)) graphState.tokens = true; if (SOURCE_KINDS.test(id)) graphState.sources = true; if (id.startsWith('command:')) graphState.commands = true; }
  if (hubTokens(graphModel()).has(id)) graphState.hubMin = 0;
  graphState.toggled.set(toggleState(graphModel(), id)?.key || '', false);
  graphState.selected = id;
  render();
}

/* Columns layout: one column per kind of item, ordered to reduce crossings. */
function layoutColumns(ids, vEdges, getNode) {
  const D = M.maxDepth;
  const colOf = n => n.kind === 'group' ? 3 : ({ input: 0, defaults: 0, token: 1, condition: 2, index: 3, sourcetype: 3, lookup: 3, datamodel: 3, macro: 3, command: 3, ds: 4 + Math.min(n.depth || 0, D), viz: 5 + D, tab: 6 + D, dashboard: 7 + D })[n.kind] ?? 3;
  const colName = c => c === 0 ? 'Inputs & defaults' : c === 1 ? 'Tokens' : c === 2 ? 'Conditions' : c === 3 ? 'Sources, macros & commands' : c === 4 ? 'Searches' : c < 5 + D ? `Chain level ${c - 4}` : c === 5 + D ? 'Visualizations' : c === 6 + D ? 'Tabs' : 'Dashboard';
  const byCol = new Map();
  for (const id of ids) { const c = colOf(getNode(id)); if (!byCol.has(c)) byCol.set(c, []); byCol.get(c).push(id); }
  const colKeys = [...byCol.keys()].sort((a, b) => a - b);
  const cols = colKeys.map(k => byCol.get(k));
  const colIndex = new Map();
  cols.forEach((col, ci) => col.forEach(id => colIndex.set(id, ci)));
  const nbrs = new Map();
  for (const e of vEdges) {
    if (!nbrs.has(e.from)) nbrs.set(e.from, []); if (!nbrs.has(e.to)) nbrs.set(e.to, []);
    nbrs.get(e.from).push(e.to); nbrs.get(e.to).push(e.from);
  }
  const kindOrder = { input: 0, defaults: 1, index: 0, sourcetype: 1, lookup: 2, datamodel: 3, macro: 4, command: 5, group: 6 };
  cols.forEach(col => col.sort((a, b) => (kindOrder[getNode(a).kind] ?? 0) - (kindOrder[getNode(b).kind] ?? 0)));
  const pos = new Map();
  const setPos = col => col.forEach((id, i) => pos.set(id, i - col.length / 2));
  cols.forEach(setPos);
  for (let it = 0; it < 10; it++) {
    const seq = it % 2 ? [...cols.keys()].reverse() : [...cols.keys()];
    for (const ci of seq) {
      const col = cols[ci];
      const bc = new Map(col.map(id => {
        const v = (nbrs.get(id) || []).filter(x => colIndex.get(x) !== ci).map(x => pos.get(x));
        return [id, v.length ? v.reduce((a, b) => a + b, 0) / v.length : pos.get(id)];
      }));
      col.sort((a, b) => bc.get(a) - bc.get(b));
      setPos(col);
    }
  }
  const GAP = 10, COLW = 270, PADX = 24, TOP = 40;
  const maxRows = Math.max(1, ...cols.map(c => c.length));
  const P = new Map();
  cols.forEach((col, ci) => {
    const off = ((maxRows - col.length) * (GH + GAP)) / 2;
    col.forEach((id, i) => P.set(id, { x: PADX + ci * COLW, y: TOP + off + i * (GH + GAP) }));
  });
  const paths = new Map();
  for (const e of vEdges) {
    const a = P.get(e.from), b = P.get(e.to);
    if (!a || !b) continue;
    if (b.x > a.x) {
      const x1 = a.x + GW, y1 = a.y + GH / 2, x2 = b.x - 2, y2 = b.y + GH / 2, dx = (x2 - x1) / 2;
      paths.set(e, { d: `M${x1},${y1} C${x1 + dx},${y1} ${x2 - dx},${y2} ${x2},${y2}`, back: false });
    } else {
      const x1 = a.x, y1 = a.y + GH / 2, x2 = b.x + GW + 2, y2 = b.y + GH / 2, dx = Math.max(50, (x1 - x2) / 2);
      paths.set(e, { d: `M${x1},${y1} C${x1 - dx},${y1} ${x2 + dx},${y2} ${x2},${y2}`, back: true });
    }
  }
  return {
    P, paths, groups: [], headers: cols.map((col, ci) => ({ x: PADX + ci * COLW, y: 22, text: `${colName(colKeys[ci])} (${col.length})` })),
    width: PADX * 2 + (cols.length - 1) * COLW + GW, height: TOP + maxRows * (GH + GAP) + 20,
  };
}

/* ELK layered layout: right-angle edges, items grouped inside their tab. */
async function layoutElk(ids, vEdges, getNode) {
  await loadScriptOnce(ELK_LIB, () => typeof window.ELK === 'function');
  const elk = new window.ELK();
  const parentOf = new Map();
  for (const id of ids) {
    const n = getNode(id);
    if (n.kind !== 'viz' && n.kind !== 'input') continue;
    const tab = vEdges.find(e => e.rel === 'contains' && e.from === id && ids.has(e.to) && e.to.startsWith('tab:'))?.to;
    if (tab) parentOf.set(id, tab);
  }
  const leaf = id => ({ id, width: GW, height: GH });
  const children = [];
  for (const id of ids) {
    const n = getNode(id);
    if (n.kind === 'dashboard' || parentOf.has(id)) continue;
    const kids = n.kind === 'tab' ? [...ids].filter(x => parentOf.get(x) === id).map(leaf) : [];
    children.push(kids.length ? { id, layoutOptions: { 'elk.padding': '[top=34,left=12,bottom=12,right=12]' }, children: kids } : leaf(id));
  }
  const present = new Set(children.flatMap(c => [c.id, ...(c.children || []).map(k => k.id)]));
  const edges = vEdges.filter(e => present.has(e.from) && present.has(e.to) && !(e.rel === 'contains' && parentOf.get(e.from) === e.to))
    .map((e, i) => ({ id: 'e' + i, sources: [e.from], targets: [e.to], _e: e }));
  const graph = await elk.layout({
    id: '__root',
    layoutOptions: {
      'elk.algorithm': 'layered', 'elk.direction': 'RIGHT', 'elk.edgeRouting': 'ORTHOGONAL', 'elk.hierarchyHandling': 'INCLUDE_CHILDREN',
      'elk.layered.spacing.nodeNodeBetweenLayers': '56', 'elk.spacing.nodeNode': '14', 'elk.spacing.edgeEdge': '6', 'elk.spacing.edgeNode': '10',
      'elk.layered.crossingMinimization.strategy': 'LAYER_SWEEP', 'elk.padding': '[top=20,left=20,bottom=20,right=20]',
    },
    children, edges: edges.map(({ _e, ...rest }) => rest),
  });
  // Shapes come back relative to their parent, and each edge relative to its "container" node.
  const abs = new Map([['__root', { x: 0, y: 0 }]]);
  const P = new Map(), groups = [];
  const walkNodes = (node, ox, oy) => {
    for (const c of node.children || []) {
      const x = ox + c.x, y = oy + c.y;
      abs.set(c.id, { x, y });
      if (c.children?.length) { groups.push({ id: c.id, x, y, w: c.width, h: c.height }); walkNodes(c, x, y); }
      else P.set(c.id, { x, y });
    }
  };
  walkNodes(graph, 0, 0);
  const byId = new Map(edges.map(e => [e.id, e._e]));
  const paths = new Map();
  const collect = node => {
    for (const ed of node.edges || []) {
      const off = abs.get(ed.container || node.id) || { x: 0, y: 0 };
      const s = ed.sections?.[0];
      if (!s) continue;
      const pts = [s.startPoint, ...(s.bendPoints || []), s.endPoint].map(pt => `${(pt.x + off.x).toFixed(1)},${(pt.y + off.y).toFixed(1)}`);
      paths.set(byId.get(ed.id), { d: 'M' + pts.join(' L'), back: s.endPoint.x < s.startPoint.x });
    }
    for (const c of node.children || []) collect(c);
  };
  collect(graph);
  return { P, paths, groups, headers: [], width: graph.width, height: graph.height };
}

// The map as an SVG string (CSS classes; styles are inlined when exported).
function mapSvgString(S, L, { interactive = true } = {}) {
  const { G, ids, edges, getNode, cm, hubsOf } = S;
  const { P, paths } = L;
  let svg = `<svg class="graph" xmlns="http://www.w3.org/2000/svg" width="${Math.ceil(L.width)}" height="${Math.ceil(L.height)}" viewBox="0 0 ${Math.ceil(L.width)} ${Math.ceil(L.height)}" role="img" aria-label="Relationship map">
  <defs>${['data', 'token', 'layout', 'vis', 'spl'].map(g => `<marker id="ar-${g}" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path class="mk-${g}" d="M0,0 L10,5 L0,10 z"/></marker>`).join('')}</defs>`;
  for (const h of L.headers) svg += `<text class="colhead" x="${h.x}" y="${h.y}">${esc(h.text)}</text>`;
  for (const g of L.groups) {
    const n = getNode(g.id);
    svg += `<g class="ggroup" data-id="${esc(g.id)}"><rect x="${g.x}" y="${g.y}" width="${g.w}" height="${g.h}" rx="8"/><text x="${g.x + 12}" y="${g.y + 21}">${esc(n.global ? 'Global inputs' : 'Tab: ' + n.label)}</text></g>`;
  }
  for (const e of edges) {
    const pth = paths.get(e);
    if (!pth) continue;
    const g = REL[e.rel].group;
    svg += `<path class="gedge ${g}${pth.back ? ' back' : ''}${e.change ? ' chg-' + e.change : ''}" data-from="${esc(e.from)}" data-to="${esc(e.to)}" d="${pth.d}" marker-end="url(#ar-${g})"><title>${esc(getNode(e.from).label + ' → ' + REL[e.rel].fwd + ' → ' + getNode(e.to).label + (e.n > 1 ? ` (${e.n} links)` : e.detail ? ' (' + e.detail + ')' : '') + (e.change ? ` [${e.change} in B]` : ''))}</title></path>`;
  }
  for (const id of ids) {
    const n = getNode(id), p = P.get(id);
    if (!p) continue;
    const center = graphState.mode === 'focus' && id === graphState.center;
    const ends = graphState.mode === 'path' && (id === graphState.pathFrom || id === graphState.pathTo);
    const chg = G.status.get(id);
    const mem = cm.members.get(id) || [];
    const sub = mem.length && n.kind !== 'group' ? `${n.kind === 'tab' ? plural(mem.length, 'item') : '+' + plural(mem.length, 'chain')} folded in` : graphSub(n);
    const bad = n.kind !== 'group' && (n.status === 'Undefined' || (M.nodes.has(id) && issuesFor(id).some(i => i.severity === 'error')));
    let extra = '';
    const hubsHere = hubsOf.get(id) || [];
    if (hubsHere.length) {
      const t = gtrunc(G.nodes.get(hubsHere[0]).label, 16) + (hubsHere.length > 1 ? ` +${hubsHere.length - 1}` : '');
      const w = Math.min(GW - 30, t.length * 5.9 + 10);
      extra += `<g class="hubtag"><title>${esc('Uses hub token' + (hubsHere.length > 1 ? 's ' : ' ') + hubsHere.map(h => G.nodes.get(h).label).join(', '))}</title><rect x="${GW - w - 4}" y="-7" width="${w}" height="14" rx="7"/><text x="${GW - w / 2 - 4}" y="3.5" text-anchor="middle">${esc(t)}</text></g>`;
    }
    const tg = interactive && graphState.mode !== 'path' ? toggleState(G, id, mem) : null;
    if (tg && (tg.collapsed || n.kind === 'tab' || n.kind === 'ds' || id.startsWith('group:'))) extra += `<g class="gtoggle" data-toggle="${esc(tg.key)}" data-collapsed="${tg.collapsed}"><title>${tg.collapsed ? 'Expand' : 'Collapse'}</title><circle cx="${GW}" cy="${GH / 2}" r="8"/><text x="${GW}" y="${GH / 2 + 4}" text-anchor="middle">${tg.collapsed ? '+' : '−'}</text></g>`;
    svg += `<g class="gnode k-${n.kind}${bad ? ' undef' : ''}${center || ends ? ' center' : ''}${chg ? ' chg-' + chg : ''}" data-id="${esc(id)}" transform="translate(${p.x},${p.y})" tabindex="0">
      <title>${esc((KINDS[n.kind]?.label || 'Group') + ': ' + n.label + (n.label !== n.key && n.kind !== 'token' && n.kind !== 'group' ? ' [' + n.key + ']' : '') + (chg ? ` (${chg} in B)` : ''))}</title>
      <rect class="box" width="${GW}" height="${GH}" rx="6"/><rect class="bar" width="4" height="${GH}" rx="2"/>
      <text x="12" y="15">${esc(gtrunc(n.label, 28))}</text><text class="sub" x="12" y="29">${esc(gtrunc(sub, 32))}</text>${extra}</g>`;
  }
  return svg + '</svg>';
}

let lastMap = null; // { S, L } of the map on screen, for keyboard moves
async function drawGraph() {
  const wrap = $('#g-wrap');
  if (!wrap) return;
  const S = graphScene();
  let L;
  if (graphState.layout === 'elk') {
    wrap.innerHTML = '<p class="muted" style="padding:12px">Laying out the map…</p>';
    try { L = await layoutElk(S.ids, S.edges, S.getNode); }
    catch (e) {
      console.error(e);
      toast(`The ELK layout couldn't be loaded (${e.message}), so the map uses columns.`, 8000);
      graphState.layout = 'columns';
      const sel = $('#g-layout'); if (sel) sel.value = 'columns';
      L = layoutColumns(S.ids, S.edges, S.getNode);
    }
    if (!$('#g-wrap')) return; // the view changed while laying out
  } else L = layoutColumns(S.ids, S.edges, S.getNode);
  lastMap = { S, L };
  wrap.innerHTML = S.ids.size ? mapSvgString(S, L) : '<p class="muted" style="padding:12px">Nothing to show.</p>';
  const el = wrap.querySelector('svg');
  if (!el) return;
  el.dataset.w = L.width; el.dataset.h = L.height;
  applyZoom(el);
  const pick = id => {
    if (!M.nodes.has(id) && !S.G.nodes.has(id)) return;
    if (graphState.mode === 'focus') { graphState.center = id; graphState.selected = id; if (M.nodes.has(id)) openDrawer(id); render(); return; }
    graphState.selected = id; highlight(el); if (M.nodes.has(id)) openDrawer(id);
  };
  let drag = null;
  el.addEventListener('pointerdown', ev => {
    if (ev.button !== 0 || ev.target.closest('.gnode, .gtoggle')) return;
    drag = { x: ev.clientX, y: ev.clientY, sl: wrap.scrollLeft, st: wrap.scrollTop, moved: false };
    el.setPointerCapture(ev.pointerId);
  });
  el.addEventListener('pointermove', ev => {
    if (!drag) return;
    const dx = ev.clientX - drag.x, dy = ev.clientY - drag.y;
    if (Math.abs(dx) + Math.abs(dy) > 4) { drag.moved = true; el.classList.add('panning'); }
    wrap.scrollLeft = drag.sl - dx; wrap.scrollTop = drag.st - dy;
  });
  el.addEventListener('pointerup', () => { setTimeout(() => { drag = null; el.classList.remove('panning'); }, 0); });
  el.addEventListener('click', ev => {
    if (drag?.moved) return;
    const tg = ev.target.closest('.gtoggle');
    if (tg) { graphState.toggled.set(tg.dataset.toggle, tg.dataset.collapsed !== 'true'); drawGraph(); return; }
    const g = ev.target.closest('.gnode, .ggroup');
    if (!g) { if (graphState.mode === 'all') { graphState.selected = null; highlight(el); } return; }
    if (g.dataset.id.startsWith('group:')) { graphState.toggled.set(g.dataset.id, false); drawGraph(); return; }
    pick(g.dataset.id);
  });
  el.addEventListener('keydown', ev => {
    const g = ev.target.closest('.gnode');
    if (!g) return;
    if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); pick(g.dataset.id); return; }
    const next = neighbourFor(g.dataset.id, ev.key);
    if (next) { ev.preventDefault(); const t = el.querySelector(`.gnode[data-id="${CSS.escape(next)}"]`); t?.focus(); t?.scrollIntoView({ block: 'nearest', inline: 'nearest' }); }
  });
  wrap.onwheel = ev => {
    if (!ev.ctrlKey && !ev.metaKey) return;
    ev.preventDefault();
    const r = wrap.getBoundingClientRect();
    setZoom(graphState.zoom * Math.exp(-ev.deltaY * 0.002), { x: ev.clientX - r.left, y: ev.clientY - r.top });
  };
  highlight(el);
  const target = graphState.mode === 'focus' ? graphState.center : graphState.selected;
  const tp = target && (L.P.get(target) || L.P.get(S.cm.rep.get(target)));
  if (tp) wrap.scrollTo({ left: Math.max(0, tp.x * graphState.zoom - wrap.clientWidth / 2), top: Math.max(0, tp.y * graphState.zoom - wrap.clientHeight / 2) });
}
// Arrow keys: right = something it feeds, left = something feeding it, up/down = the next box in the column.
function neighbourFor(id, key) {
  if (!lastMap) return null;
  const { S, L } = lastMap, p = L.P.get(id);
  if (!p) return null;
  const nearest = list => list.filter(x => L.P.has(x)).sort((a, b) => Math.abs(L.P.get(a).y - p.y) - Math.abs(L.P.get(b).y - p.y))[0];
  if (key === 'ArrowRight') return nearest(S.edges.filter(e => e.from === id).map(e => e.to));
  if (key === 'ArrowLeft') return nearest(S.edges.filter(e => e.to === id).map(e => e.from));
  if (key === 'ArrowUp' || key === 'ArrowDown') {
    const same = [...L.P].filter(([x, q]) => x !== id && Math.abs(q.x - p.x) < 5 && (key === 'ArrowUp' ? q.y < p.y : q.y > p.y));
    same.sort((a, b) => Math.abs(a[1].y - p.y) - Math.abs(b[1].y - p.y));
    return same[0]?.[0] || null;
  }
  return null;
}
function applyZoom(el) {
  const w = +el.dataset.w, h = +el.dataset.h, z = graphState.zoom;
  el.setAttribute('width', Math.ceil(w * z)); el.setAttribute('height', Math.ceil(h * z));
  const lab = $('#g-zlabel'); if (lab) lab.textContent = Math.round(z * 100) + '%';
}
function setZoom(z, anchor) {
  const wrap = $('#g-wrap'), el = wrap?.querySelector('svg');
  if (!el) return;
  const old = graphState.zoom;
  z = Math.min(3, Math.max(0.15, z));
  const a = anchor || { x: wrap.clientWidth / 2, y: wrap.clientHeight / 2 };
  const cx = (wrap.scrollLeft + a.x) / old, cy = (wrap.scrollTop + a.y) / old;
  graphState.zoom = z;
  applyZoom(el);
  wrap.scrollLeft = cx * z - a.x; wrap.scrollTop = cy * z - a.y;
}
function fitGraph() {
  const wrap = $('#g-wrap'), el = wrap?.querySelector('svg');
  if (!el) return;
  const availH = Math.max(240, window.innerHeight - wrap.getBoundingClientRect().top - 24);
  setZoom(Math.min(1.5, (wrap.clientWidth - 8) / +el.dataset.w, availH / +el.dataset.h));
  wrap.scrollTo(0, 0);
}
function highlight(svg) {
  const sel = graphState.mode === 'all' ? graphState.selected : null;
  svg.classList.toggle('has-sel', !!sel);
  if (!sel || !lastMap) { svg.querySelectorAll('.dim,.sel').forEach(x => x.classList.remove('dim', 'sel')); return; }
  const E = lastMap.S.edges;
  const walk = up => { const seen = new Set(), st = [sel]; while (st.length) { const id = st.pop(); for (const e of E) { const [a, b] = up ? [e.to, e.from] : [e.from, e.to]; if (a === id && !seen.has(b)) { seen.add(b); st.push(b); } } } return seen; };
  const up = walk(true), down = walk(false), lin = new Set([sel, ...up, ...down]);
  svg.querySelectorAll('.gnode').forEach(g => { g.classList.toggle('dim', !lin.has(g.dataset.id)); g.classList.toggle('sel', g.dataset.id === sel); });
  svg.querySelectorAll('.gedge').forEach(p => {
    const f = p.dataset.from, t = p.dataset.to;
    const onUp = (up.has(f) || f === sel) && (up.has(t) || t === sel);
    const onDown = (down.has(f) || f === sel) && (down.has(t) || t === sel);
    p.classList.toggle('dim', !(onUp || onDown));
  });
}

/* ---------- Exporting graphs: inline the page's styles so the SVG stands alone ---------- */
const INLINE_PROPS = ['fill', 'fill-opacity', 'stroke', 'stroke-width', 'stroke-dasharray', 'stroke-opacity', 'opacity', 'font-family', 'font-size', 'font-weight', 'letter-spacing', 'text-transform', 'text-anchor'];
function exportableSvg(svgEl, bg) {
  if (!svgEl) return '';
  const clone = svgEl.cloneNode(true);
  const src = [svgEl, ...svgEl.querySelectorAll('*')], dst = [clone, ...clone.querySelectorAll('*')];
  src.forEach((el, i) => {
    const cs = getComputedStyle(el);
    const style = INLINE_PROPS.map(p => { const v = cs.getPropertyValue(p); return v && v !== 'normal' && v !== 'none' || p === 'fill' || p === 'stroke' ? `${p}:${v}` : ''; }).filter(Boolean).join(';');
    dst[i].setAttribute('style', style + (dst[i].getAttribute('style') ? ';' + dst[i].getAttribute('style') : ''));
    dst[i].removeAttribute('class'); dst[i].removeAttribute('tabindex');
  });
  clone.querySelectorAll('.gtoggle, [data-toggle]').forEach(x => x.remove());
  const w = svgEl.getAttribute('width'), h = svgEl.getAttribute('height');
  clone.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
  const bgc = bg || getComputedStyle(document.documentElement).getPropertyValue('--panel').trim() || '#ffffff';
  clone.insertAdjacentHTML('afterbegin', `<rect width="100%" height="100%" fill="${bgc}"/>`);
  clone.setAttribute('width', w); clone.setAttribute('height', h);
  return new XMLSerializer().serializeToString(clone);
}
async function downloadPng(svg, name) {
  const url = URL.createObjectURL(new Blob([svg], { type: 'image/svg+xml' }));
  try {
    const img = new Image();
    await new Promise((res, rej) => { img.onload = res; img.onerror = () => rej(new Error('The image could not be drawn.')); img.src = url; });
    const scale = Math.min(2, 16000 / Math.max(img.width, img.height));
    const c = document.createElement('canvas');
    c.width = Math.round(img.width * scale); c.height = Math.round(img.height * scale);
    const g = c.getContext('2d'); g.scale(scale, scale); g.drawImage(img, 0, 0);
    const blob = await new Promise(r => c.toBlob(r, 'image/png'));
    await download(name, blob, 'image/png');
  } catch (e) { toast(e.message, 6000); }
  finally { URL.revokeObjectURL(url); }
}
// A map drawn off-screen in the light palette, for reports: what feeds one panel.
function panelLineageSvg(vizId) {
  const saved = { ...graphState, collapse: { ...graphState.collapse }, toggled: new Map(graphState.toggled) };
  Object.assign(graphState, { mode: 'focus', center: vizId, depth: 'all', tokens: true, sources: true, commands: false, hubMin: 4, overlay: false, collapse: { tabs: false, chains: false, sources: false, commands: false }, toggled: new Map() });
  try {
    const S = graphScene();
    // Upstream only: keep the panel and what it depends on.
    const up = reach(S.G, vizId, true);
    S.ids = new Set([...S.ids].filter(id => id === vizId || up.has(id)));
    S.edges = S.edges.filter(e => S.ids.has(e.from) && S.ids.has(e.to));
    const L = layoutColumns(S.ids, S.edges, S.getNode);
    const host = document.createElement('div');
    host.className = 'force-light';
    host.style.cssText = 'position:absolute;left:-100000px;top:0;';
    host.innerHTML = mapSvgString(S, L, { interactive: false });
    document.body.appendChild(host);
    const out = exportableSvg(host.querySelector('svg'), '#ffffff');
    host.remove();
    return out;
  } finally { Object.assign(graphState, saved); }
}

/* ---------- Token matrix ---------- */
const matState = { cols: 'viz', rows: 'token', sort: 'def' };
// How a token reaches an item: direct use, through its search, through a condition, or set by it.
function tokenLinks(tokId, itemId) {
  const n = M.nodes.get(itemId), out = [];
  if (outs(itemId, ['drilldown-sets', 'smart-source']).some(e => e.to === tokId)) out.push('sets');
  if (outs(tokId, ['uses-token']).some(e => e.to === itemId)) out.push('direct');
  if (n.kind === 'viz') {
    const feeds = ins(itemId, ['feeds']).flatMap(e => M.nodes.get(e.from)?.lineage || []);
    if (feeds.some(d => directTokens(d).includes(tokId))) out.push('search');
    if (ins(itemId, ['visibility']).some(e => directTokens(e.from).includes(tokId))) out.push('condition');
  } else if (n.kind === 'ds') {
    if ((n.lineage || []).slice(0, -1).some(d => directTokens(d).includes(tokId))) out.push('search');
  }
  return out;
}
// For an input: how the tokens it sets reach the item.
function inputLinks(inputId, itemId) {
  const toks = outs(inputId, ['sets']).map(e => e.to);
  return uniq(toks.flatMap(t => tokenLinks(t, itemId)).filter(x => x !== 'sets'));
}
const MAT_SYMBOL = { direct: '●', search: '○', condition: '▲', sets: '◆' };
const MAT_TEXT = { direct: 'uses it directly (title, options or query)', search: 'uses it through its search', condition: 'is shown or hidden by a condition that uses it', sets: 'sets it (drilldown or search result)' };
function matrixColumns() {
  if (matState.cols === 'ds') return M.byKind('ds').map(n => ({ id: n.id, group: dsTypeLabel(n.type) }));
  const out = [];
  for (const t of mockTabs()) for (const it of t.items || []) if (it.id.startsWith('viz:')) out.push({ id: it.id, group: t.label });
  for (const v of M.byKind('viz')) if (!out.some(c => c.id === v.id)) out.push({ id: v.id, group: 'Not placed' });
  return out;
}
// Rows, columns and cells after sorting: by definition order, by use, or grouping similar ones together.
function matrixData() {
  const rows = matState.rows === 'input' ? M.byKind('input').filter(n => n.token) : M.byKind('token');
  let cols = matrixColumns();
  const link = matState.rows === 'input' ? inputLinks : tokenLinks;
  const cell = new Map();
  for (const r of rows) for (const c of cols) cell.set(r.id + '|' + c.id, link(r.id, c.id));
  const has = (r, c) => cell.get(r.id + '|' + c.id).length > 0;
  let R = [...rows];
  if (matState.sort !== 'def') {
    const colCount = c => R.filter(r => has(r, c)).length;
    const groupOrder = uniq(cols.map(c => c.group));
    cols = groupOrder.flatMap(g => cols.filter(c => c.group === g).sort((a, b) => colCount(b) - colCount(a)));
    const rowVec = r => cols.map(c => has(r, c) ? '1' : '0').join('');
    R.sort((a, b) => {
      const ca = cols.filter(c => has(a, c)).length, cb = cols.filter(c => has(b, c)).length;
      return matState.sort === 'used' ? cb - ca : (rowVec(b) > rowVec(a) ? 1 : rowVec(b) < rowVec(a) ? -1 : cb - ca);
    });
    if (matState.sort === 'group') {
      const colVec = c => R.map(r => has(r, c) ? '1' : '0').join('');
      cols = groupOrder.flatMap(g => cols.filter(c => c.group === g).sort((a, b) => colVec(b) > colVec(a) ? 1 : colVec(b) < colVec(a) ? -1 : 0));
    }
  }
  return { rows: R, cols, cell: (r, c) => cell.get(r.id + '|' + c.id) };
}
function viewTokenMatrix() {
  const { rows, cols, cell } = matrixData();
  if (!rows.length) return `<p class="muted">This dashboard has no ${matState.rows === 'input' ? 'inputs that set a token' : 'tokens'}.</p>`;
  const groups = [];
  for (const c of cols) { const g = groups[groups.length - 1]; if (g && g.name === c.group) g.n++; else groups.push({ name: c.group, n: 1 }); }
  const btn = (attr, k, label, cur) => `<button data-${attr}="${k}" aria-pressed="${cur === k}">${label}</button>`;
  const rowsLabel = matState.rows === 'input' ? 'Input' : 'Token';
  return `<div class="graph-controls">
    <div class="seg" role="group" aria-label="Rows">${btn('matrows', 'token', 'Tokens', matState.rows)}${btn('matrows', 'input', 'Inputs', matState.rows)}</div>
    <span>×</span>
    <div class="seg" role="group" aria-label="Columns">${btn('matcols', 'viz', 'Panels', matState.cols)}${btn('matcols', 'ds', 'Searches', matState.cols)}</div>
    <label>Order <select id="mat-sort"><option value="def" ${matState.sort === 'def' ? 'selected' : ''}>As defined</option><option value="used" ${matState.sort === 'used' ? 'selected' : ''}>Most used first</option><option value="group" ${matState.sort === 'group' ? 'selected' : ''}>Group similar together</option></select></label>
    <button class="btn small" id="mat-svg">Export SVG</button><button class="btn small" id="mat-png">Export PNG</button>
  </div>
  <div class="legend" style="margin-bottom:6px">${Object.entries(MAT_SYMBOL).filter(([k]) => matState.rows === 'token' || k !== 'sets').map(([k, s]) => `<span><b class="mat-${k}">${s}</b> ${esc(MAT_TEXT[k])}</span>`).join('')}</div>
  <p class="muted small" style="margin:0 0 8px">Each row is ${matState.rows === 'input' ? 'an input (through the tokens it sets)' : 'a token'}; each column a ${matState.cols === 'ds' ? 'data source' : 'panel, grouped by tab'}. Read across a row to see everything it changes. Click a row, column or mark for details.</p>
  <div class="tablewrap matrix"><table>
    <thead>
      <tr><th class="mat-corner" rowspan="2">${rowsLabel}</th><th rowspan="2">${matState.rows === 'input' ? 'Sets' : 'Set by'}</th>${groups.map(g => `<th class="mat-group" colspan="${g.n}">${esc(g.name)}</th>`).join('')}<th rowspan="2">Total</th></tr>
      <tr>${cols.map(c => `<th class="mat-col"><button class="mat-head" data-open="${esc(c.id)}" title="${esc(M.nodes.get(c.id).label)}"><span>${esc(gtrunc(M.nodes.get(c.id).label, 26))}</span></button></th>`).join('')}</tr>
    </thead>
    <tbody>${rows.map(r => {
      const row = cols.map(c => cell(r, c));
      const second = matState.rows === 'input' ? outs(r.id, ['sets']).map(e => M.nodes.get(e.to).label).join(', ') : ins(r.id, ['sets', 'drilldown-sets', 'default', 'smart-source']).map(e => M.nodes.get(e.from).label).join(', ');
      return `<tr class="filterable"><th scope="row">${chip(r.id)}</th><td class="small">${esc(second || '—')}</td>${row.map((x, i) => x.length
        ? `<td class="mat-cell"><button data-open="${esc(cols[i].id)}" title="${esc(`${M.nodes.get(cols[i].id).label} ${x.map(y => MAT_TEXT[y]).join(', and ')}`)}">${x.map(y => `<span class="mat-${y}">${MAT_SYMBOL[y]}</span>`).join('')}</button></td>`
        : '<td class="mat-cell"></td>').join('')}<td class="num">${row.filter(x => x.length).length}</td></tr>`;
    }).join('')}</tbody>
  </table></div>`;
}
// The matrix as a standalone SVG (for export).
function matrixSvg() {
  const { rows, cols, cell } = matrixData();
  const cs = getComputedStyle(document.documentElement), v = (n, d) => cs.getPropertyValue(n).trim() || d;
  const C = { bg: v('--panel', '#fff'), text: v('--text', '#1b1f24'), muted: v('--muted', '#5f6b7a'), line: v('--border', '#dde1e7'), direct: v('--k-token', '#b7791f'), search: v('--k-ds', '#2f6fde'), condition: v('--k-condition', '#c2417a'), sets: v('--k-viz', '#2e8b57') };
  const F = 'font-family="system-ui, -apple-system, Segoe UI, Roboto, sans-serif"';
  const LW = 230, CW = 26, RH = 24, HH = 170, PAD = 12;
  const W = PAD * 2 + LW + cols.length * CW + 40, H = PAD * 2 + HH + rows.length * RH + 30;
  let s = `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}"><rect width="100%" height="100%" fill="${C.bg}"/>`;
  cols.forEach((c, i) => {
    const x = PAD + LW + i * CW + CW / 2;
    s += `<text transform="translate(${x + 4},${PAD + HH - 6}) rotate(-60)" font-size="11" fill="${C.text}" ${F}>${esc(gtrunc(M.nodes.get(c.id).label, 30))}</text>`;
    s += `<line x1="${PAD + LW + i * CW}" y1="${PAD + HH}" x2="${PAD + LW + i * CW}" y2="${PAD + HH + rows.length * RH}" stroke="${C.line}"/>`;
  });
  rows.forEach((r, j) => {
    const y = PAD + HH + j * RH;
    s += `<line x1="${PAD}" y1="${y}" x2="${PAD + LW + cols.length * CW}" y2="${y}" stroke="${C.line}"/><text x="${PAD + 4}" y="${y + 16}" font-size="12" fill="${C.text}" ${F}>${esc(gtrunc(r.label, 34))}</text>`;
    cols.forEach((c, i) => {
      const x = cell(r, c);
      if (x.length) s += `<text x="${PAD + LW + i * CW + CW / 2}" y="${y + 17}" font-size="13" text-anchor="middle" ${F}>${x.map(k => `<tspan fill="${C[k]}">${MAT_SYMBOL[k]}</tspan>`).join('')}</text>`;
    });
  });
  s += `<text x="${PAD}" y="${H - 10}" font-size="10.5" fill="${C.muted}" ${F}>${esc(Object.entries(MAT_SYMBOL).map(([k, sym]) => sym + ' ' + MAT_TEXT[k]).join('   '))}</text>`;
  return s + '</svg>';
}

/* ---------- Sankey diagrams ---------- */
const flowState = { measure: 'panels', chains: false };
// Sources → base searches → (chain searches) → panels → tabs for this dashboard.
function sankeyData(opts = flowState) {
  const nodes = new Map(), links = new Map();
  const node = (id, col, label, kind) => { if (!nodes.has(id)) nodes.set(id, { id, col, label, kind, in: 0, out: 0, open: M.nodes.has(id) ? id : null }); return nodes.get(id); };
  const link = (a, b, v) => { const k = a + '\u0001' + b; links.set(k, { from: a, to: b, v: (links.get(k)?.v || 0) + v }); nodes.get(a).out += v; nodes.get(b).in += v; };
  const C = opts.chains ? 1 : 0;
  const rootValue = new Map();
  for (const v of M.byKind('viz')) {
    const feeds = ins(v.id, ['feeds']).map(e => M.nodes.get(e.from)).filter(Boolean);
    if (!feeds.length) continue;
    const weight = d => opts.measure === 'searches' ? (d.lineage || [d.id]).length : 1;
    node(v.id, 2 + C, v.label, 'viz');
    let total = 0;
    for (const d of feeds) {
      const w = weight(d) / feeds.length;
      total += w;
      const r = M.nodes.get(d.rootId) || d;
      node(r.id, 1, r.label, 'ds');
      if (C && d.id !== r.id) { node(d.id, 2, d.label, 'chain'); link(r.id, d.id, w); link(d.id, v.id, w); }
      else link(r.id, v.id, w);
      rootValue.set(r.id, (rootValue.get(r.id) || 0) + w);
    }
    const tabs = tabsOf(v.id).filter(t => t.startsWith('tab:'));
    if (!tabs.length) { node('tab:(none)', 3 + C, 'Not placed', 'tab'); link(v.id, 'tab:(none)', total); }
    for (const t of tabs) { node(t, 3 + C, M.nodes.get(t).label, 'tab'); link(v.id, t, total / tabs.length); }
  }
  for (const [rid, val] of rootValue) {
    const r = M.nodes.get(rid);
    const src = [];
    for (const x of r.eff_index || []) if (!x.excluded && !x.value.includes('$') && M.nodes.has('index:' + x.value)) src.push(['index:' + x.value, x.value, 'index']);
    for (const l of r.eff_lookups || []) if (l.mode === 'read' && M.nodes.has('lookup:' + l.name)) src.push(['lookup:' + l.name, l.name, 'lookup']);
    for (const d of r.eff_datamodels || []) if (M.nodes.has('datamodel:' + d.model)) src.push(['datamodel:' + d.model, d.model, 'datamodel']);
    const uniqSrc = [...new Map(src.map(s => [s[0], s])).values()];
    if (!uniqSrc.length) {
      const first = (r.sources?.commands || [])[0]?.name;
      uniqSrc.push(r.type === 'ds.savedSearch' ? ['src:saved', 'Saved searches (report)', 'other'] : NO_EVENT_TIME.has(first) ? ['src:gen', 'Generated (' + first + ')', 'other'] : ['src:none', 'No index named', 'other']);
    }
    for (const [id, label, kind] of uniqSrc) { node(id, 0, label, kind); link(id, rid, val / uniqSrc.length); }
  }
  const heads = C ? ['Sources', 'Base searches', 'Chain searches', 'Panels', 'Tabs'] : ['Sources', 'Base searches', 'Panels', 'Tabs'];
  return { nodes: [...nodes.values()], links: [...links.values()], heads, unit: opts.measure === 'searches' ? 'search step' : 'panel' };
}
// Sources (indexes, lookups, data models) → dashboards, across every loaded dashboard. Band = searches reading it.
function appSankeyData() {
  const nodes = new Map(), links = new Map();
  const node = (id, col, label, kind, dash) => { if (!nodes.has(id)) nodes.set(id, { id, col, label, kind, in: 0, out: 0, dash }); return nodes.get(id); };
  const link = (a, b, v) => { const k = a + '\u0001' + b; links.set(k, { from: a, to: b, v: (links.get(k)?.v || 0) + v }); nodes.get(a).out += v; nodes.get(b).in += v; };
  DASH.forEach((d, i) => {
    for (const n of d.model.byKind('ds')) {
      if (n.depth !== 0) continue;
      const src = [];
      for (const x of n.eff_index || []) if (!x.excluded && !x.value.includes('$')) src.push(['index:' + x.value, x.value, 'index']);
      for (const l of n.eff_lookups || []) if (l.mode === 'read' && !l.name.includes('$')) src.push(['lookup:' + l.name, l.name, 'lookup']);
      for (const m of n.eff_datamodels || []) src.push(['datamodel:' + m.model, m.model, 'datamodel']);
      for (const [sid, label, kind] of new Map(src.map(s => [s[0], s])).values()) {
        node(sid, 0, label, kind);
        node('dash:' + i, 1, d.model.title, 'tab', i);
        link(sid, 'dash:' + i, 1);
      }
    }
  });
  return { nodes: [...nodes.values()], links: [...links.values()], heads: ['Sources', 'Dashboards'], unit: 'base search' };
}
function sankeyRender(data, light = false, width = 1100) {
  const { nodes, links, heads, unit } = data;
  if (!links.length) return '';
  const cs = getComputedStyle(document.documentElement);
  const col = (v, d) => (light ? '' : cs.getPropertyValue(v).trim()) || d;
  const C = { text: col('--text', '#1b1f24'), muted: col('--muted', '#5f6b7a'),
    index: col('--k-index', '#9a5b22'), lookup: col('--k-lookup', '#1f7f9e'), datamodel: col('--k-datamodel', '#b0458f'), other: col('--k-defaults', '#7a7f87'),
    ds: col('--k-ds', '#2f6fde'), chain: col('--k-ds', '#2f6fde'), viz: col('--k-viz', '#2e8b57'), tab: col('--k-tab', '#6d4fd8') };
  const NC = heads.length, NW = 12, PAD = 10, LEFT = 8, LABELW = 210;
  const colX = heads.map((_, i) => LEFT + i * (width - LEFT - LABELW - NW) / (NC - 1));
  const cols = heads.map((_, c) => nodes.filter(n => n.col === c));
  const val = n => Math.max(n.in, n.out);
  cols[0].sort((a, b) => val(b) - val(a));
  const order = new Map();
  const setOrder = () => cols.forEach(c => c.forEach((n, i) => order.set(n.id, i)));
  setOrder();
  for (let it = 0; it < 4; it++) for (let c = 1; c < NC; c++) {
    const bc = n => { const ls = links.filter(l => l.to === n.id); const w = ls.reduce((s, l) => s + l.v, 0); return w ? ls.reduce((s, l) => s + order.get(l.from) * l.v, 0) / w : order.get(n.id); };
    cols[c].sort((a, b) => bc(a) - bc(b)); setOrder();
  }
  const rows = Math.max(...cols.map(c => c.length));
  const height = Math.max(320, rows * 30 + 40);
  const k = Math.min(...cols.filter(c => c.length).map(c => (height - 40 - (c.length - 1) * PAD) / c.reduce((s, n) => s + val(n), 0)));
  const pos = new Map();
  cols.forEach((c, ci) => {
    const total = c.reduce((s, n) => s + val(n) * k, 0) + (c.length - 1) * PAD;
    let y = 20 + (height - 40 - total) / 2;
    for (const n of c) { pos.set(n.id, { x: colX[ci], y, h: Math.max(2, val(n) * k) }); y += val(n) * k + PAD; }
  });
  const colorOf = n => C[n.kind] || C.other;
  const F = 'font-family="system-ui, -apple-system, Segoe UI, Roboto, sans-serif"';
  const outsL = new Map(), insL = new Map();
  for (const l of [...links].sort((a, b) => pos.get(a.to).y - pos.get(b.to).y)) (outsL.get(l.from) || outsL.set(l.from, []).get(l.from)).push(l);
  for (const l of [...links].sort((a, b) => pos.get(a.from).y - pos.get(b.from).y)) (insL.get(l.to) || insL.set(l.to, []).get(l.to)).push(l);
  const yOut = new Map(), yIn = new Map();
  for (const [id, ls] of outsL) { let y = pos.get(id).y; for (const l of ls) { yOut.set(l, y); y += l.v * k; } }
  for (const [id, ls] of insL) { let y = pos.get(id).y; for (const l of ls) { yIn.set(l, y); y += l.v * k; } }
  const byId = new Map(nodes.map(n => [n.id, n]));
  const fmtV = x => +x.toFixed(2);
  const units = v => (v === 1 ? unit : /(s|sh|ch)$/.test(unit) ? unit + 'es' : unit + 's');
  let out = '';
  for (const l of links) {
    const a = pos.get(l.from), b = pos.get(l.to), t = Math.max(1, l.v * k);
    const x1 = a.x + NW, x2 = b.x, xm = (x1 + x2) / 2, y1 = yOut.get(l), y2 = yIn.get(l);
    const nf = byId.get(l.from), nt = byId.get(l.to);
    out += `<path d="M${x1},${y1} C${xm},${y1} ${xm},${y2} ${x2},${y2} L${x2},${y2 + t} C${xm},${y2 + t} ${xm},${y1 + t} ${x1},${y1 + t} Z" fill="${colorOf(nf)}" fill-opacity="0.28"><title>${esc(`${nf.label} → ${nt.label}: ${fmtV(l.v)} ${units(l.v)}`)}</title></path>`;
  }
  for (const n of nodes) {
    const p = pos.get(n.id);
    const attrs = n.open ? `class="sk-node" data-open="${esc(n.open)}" tabindex="0"` : n.dash !== undefined ? `class="sk-node" data-dash="${n.dash}" tabindex="0"` : '';
    out += `<g ${attrs}><rect x="${p.x}" y="${p.y.toFixed(1)}" width="${NW}" height="${p.h.toFixed(1)}" fill="${colorOf(n)}" rx="2"/>`
      + `<text x="${p.x + NW + 6}" y="${(p.y + p.h / 2 + 4).toFixed(1)}" font-size="11.5" fill="${C.text}" ${F}>${esc(gtrunc(n.label, 30))}<tspan fill="${C.muted}"> ${fmtV(val(n))}</tspan></text>`
      + `<title>${esc(`${n.label}: ${fmtV(val(n))} ${units(val(n))}`)}</title></g>`;
  }
  const hd = heads.map((h, i) => `<text x="${colX[i]}" y="12" font-size="10.5" font-weight="600" fill="${C.muted}" ${F} letter-spacing=".05em">${h.toUpperCase()}</text>`).join('');
  return `<svg class="sankey" xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" role="img" aria-label="Sankey diagram">${light ? `<rect width="${width}" height="${height}" fill="#ffffff"/>` : ''}${hd}${out}</svg>`;
}
function sankeySvg(light = false, opts = flowState) { return sankeyRender(sankeyData(opts), light); }
function viewDataFlow() {
  const svg = sankeySvg(false);
  const noData = M.byKind('viz').filter(v => !ins(v.id, ['feeds']).length).length;
  return `<div class="graph-controls">
    <label>Band width <select id="flow-measure"><option value="panels" ${flowState.measure === 'panels' ? 'selected' : ''}>Panels</option><option value="searches" ${flowState.measure === 'searches' ? 'selected' : ''}>Search steps (base + chain searches per panel)</option></select></label>
    <label><input type="checkbox" id="flow-chains" ${flowState.chains ? 'checked' : ''}> Show chain searches as their own column</label>
    <button class="btn small" id="flow-svg">Export SVG</button><button class="btn small" id="flow-png">Export PNG</button>
  </div>
  <p class="muted small" style="margin:0 0 8px">Where each panel's data comes from: indexes, lookups and data models, through base searches${flowState.chains ? ' and chain searches' : ' (chain searches counted with their base)'}, to panels and tabs. Band width is the number of ${flowState.measure === 'searches' ? 'search steps behind the panels, a rough measure of search work' : 'panels; a panel fed by two sources counts half to each'}. Hover a band for numbers; click an item for details.</p>
  ${svg ? `<div class="graph-wrap sankey-wrap">${svg}</div>` : '<p class="muted">No panel in this dashboard gets data from a search.</p>'}
  ${noData ? `<p class="muted small">${plural(noData, 'panel')} with no data source (markdown, images and shapes) ${noData === 1 ? 'is' : 'are'} not shown.</p>` : ''}`;
}

/* ============================================================
   Detail drawer
   ============================================================ */
const drawerHistory = [];
function openDrawer(id, push = true) {
  const n = M.nodes.get(id);
  if (!n) return;
  if (push && drawerHistory[drawerHistory.length - 1] !== id) drawerHistory.push(id);
  $('#drawer-back').disabled = drawerHistory.length < 2;
  const kindLabel = n.kind === 'ds' ? dsTypeLabel(n.type) : n.kind === 'viz' ? 'Visualization · ' + n.type : n.kind === 'input' ? 'Input · ' + n.type : KINDS[n.kind].label;
  $('#drawer-kind').innerHTML = `${invNo(n.id) ? `<span class="badge" title="Inventory number">#${invNo(n.id)}</span> ` : ''}<span class="chip k-${n.kind}" style="cursor:default">${esc(kindLabel)}</span>`;
  $('#drawer-title').textContent = n.label;

  const props = [];
  const P = (k, v) => { if (v !== undefined && v !== '' && v !== null) props.push(`<dt>${esc(k)}</dt><dd>${v}</dd>`); };
  P('ID', `<code>${esc(n.key)}</code>`);
  if (n.kind === 'ds') {
    P('Name', esc(n.name)); P('Type', `<code>${esc(n.type)}</code>`);
    if (n.depth) P('Lineage', dsLineage(n.id));
    if (n.ref) P('Report', `<code>${esc(n.ref)}</code>${n.app ? ' in app <code>' + esc(n.app) + '</code>' : ''}`);
    P('Time range', timeRange(n));
    P('Refresh', n.refresh ? `<code>${esc(fmt(n.refresh))}</code> ${esc(n.refreshType || '')}` : '');
    P('Smart sources', n.enableSmartSources ? 'enabled' : '');
    P('Indexes', n.eff_index.length || n.type === 'ds.savedSearch' ? srcCell(n, 'index') : '<span class="muted">none named</span>');
    P('Sourcetypes', n.eff_sourcetype.length ? srcCell(n, 'sourcetype') : '<span class="muted">none named</span>');
    P('Lookups', n.eff_lookups.length ? lookupCell(n) : '');
    P('Data models', n.eff_datamodels.length ? dmCell(n) : '');
    P('Macros', n.eff_macros.length ? macroCell(n) : '');
    P('Commands', n.sources.commands.length ? pipeline(n, true) : '');
    P('Other sources', n.eff_other.map(o => `<code>${esc(o)}</code>`).join(' '));
  } else if (n.kind === 'input') {
    P('Title', esc(n.title)); P('Token', n.token ? chip('token:' + n.token) : '<span class="muted">none</span>');
    P('Default', n.defaultValue !== undefined ? `<code>${esc(fmt(n.defaultValue))}</code>` : '');
    if (n.items) P('Static options', n.items.slice(0, 30).map(i => `<code>${esc(fmt(i?.label ?? i))}${i?.value !== undefined && i.value !== i.label ? ' = ' + esc(fmt(i.value)) : ''}</code>`).join(' ') + (n.items.length > 30 ? ` … (${n.items.length})` : ''));
    P('Visibility', esc(n.visibility));
  } else if (n.kind === 'viz') {
    P('Title', esc(n.title)); P('Type', `<code>${esc(n.type)}</code>`);
    P('Drilldown', n.drilldowns.map(d => esc(d.text)).join('<br>'));
    P('Drilldown values', uniq(n.builtins).map(b => `<code>${esc(b)}</code>`).join(' '));
    P('Visibility', esc(n.visibility));
  } else if (n.kind === 'token') {
    P('Status', esc(n.status));
    P('Default value', (n.defaults || []).map(d => `<code>${esc(fmt(d.value))}</code> <span class="muted small">from</span> ${chip(d.from)}`).join('<br>'));
  } else if (n.kind === 'datamodel') {
    P('Datasets', [...n.datasets].map(d => `<code>${esc(d)}</code>`).join(' '));
    P('Constraints', n.config ? n.config.objects.map(o => `<div class="small"><b>${esc(o.name)}</b>${o.constraints.length ? `: <code>${esc(o.constraints.join(' '))}</code>` : ''}</div>`).join('') : '<span class="muted">Not loaded. Paste the data model JSON on the Splunk config page.</span>');
    P('Read by', chips(outs(n.id, ['datamodel-read']).map(e => [e.to, e.detail]), ''));
    P('Feeds visualizations', chips(dataDown(n.id).filter(x => x.startsWith('viz:')), ''));
  } else if (n.kind === 'macro') {
    P('Name', `<code>${esc(n.name)}</code>`); P('Arguments', String(n.arity));
    P('Calls as written', n.calls.map(c => `<code>\`${esc(c)}\`</code>`).join('<br>'));
    P('Definition', n.config ? `<code>${esc(n.config.definition)}</code>${n.config.args.length ? `<div class="muted small">arguments: ${esc(n.config.args.join(', '))}</div>` : ''}` : '<span class="muted">Not loaded. Paste macros.conf on the Splunk config page.</span>');
    P('Feeds visualizations', chips(dataDown(n.id).filter(x => x.startsWith('viz:')), ''));
  } else if (n.kind === 'command') {
    P('Category', esc(n.category)); P('Uses', String(n.uses));
  } else if (n.kind === 'lookup') {
    P('Access', [...n.access].sort().map(accessBadge).join(' '));
    P('Read by', chips(outs(n.id, ['lookup-read']).map(e => [e.to, e.detail]), ''));
    P('Written by', chips(ins(n.id, ['lookup-write']).map(e => [e.from, e.detail]), ''));
    P('Feeds visualizations', chips(dataDown(n.id).filter(x => x.startsWith('viz:')), ''));
  } else if (n.kind === 'index' || n.kind === 'sourcetype') {
    P('Feeds visualizations', chips(dataDown(n.id).filter(x => x.startsWith('viz:'))));
  } else if (n.kind === 'condition') {
    P('Name', esc(n.label)); P('Expression', `<code>${esc(n.value)}</code>`);
  } else if (n.kind === 'tab') {
    P('Layout type', esc(n.layoutType)); P('Items', String(ins(n.id, ['contains']).length));
  } else if (n.kind === 'dashboard') {
    P('Description', esc(n.description)); P('Source', esc(M.format)); P('Layout', esc(M.layoutSummary));
  }

  let html = `<dl class="meta-grid">${props.join('')}</dl>`;
  const iss = issuesFor(id);
  if (iss.length) html += `<h4>Issues</h4>` + iss.map(i => `<div style="margin:4px 0">${sevBadge(i.severity)} ${esc(i.message)}</div>`).join('');

  if (n.kind === 'ds') {
    if (n.type === 'ds.savedSearch') html += `<h4>Search</h4><pre>| savedsearch "${esc(n.ref)}"</pre>`;
    else if (n.query) html += `<h4>Query</h4><pre>${esc(n.query)}</pre>`;
    if (n.depth > 0) html += `<h4>Effective SPL (base + chain)</h4><pre>${esc(n.effectiveQuery)}</pre>`;
    if (n.expandedQuery) html += `<h4>Expanded SPL (macros, saved searches and data model constraints resolved, for analysis only)</h4><pre>${esc(n.expandedQuery)}</pre>`;
  }

  const groups = new Map();
  const add = (label, id2, detail) => { if (!groups.has(label)) groups.set(label, []); groups.get(label).push([id2, detail]); };
  for (const e of ins(id)) add(REL[e.rel].rev, e.from, e.rel === 'uses-token' ? '' : e.detail);
  for (const e of outs(id)) add(REL[e.rel].fwd, e.to, e.rel === 'uses-token' ? '' : e.detail);
  html += `<h4>Relationships</h4>` + (groups.size ? [...groups].map(([label, list]) => {
    const seen = new Set();
    const items = list.filter(([i, d]) => { const k = i + '|' + d; if (seen.has(k)) return false; seen.add(k); return true; });
    return `<div class="relgroup"><div class="rl">${esc(label)} (${uniq(items.map(x => x[0])).length})</div>${chips(items)}</div>`;
  }).join('') : '<p class="muted">No relationships.</p>');

  if (n.kind !== 'tab' && n.kind !== 'dashboard') {
    const up = [...closure(id, 'up')].filter(x => !x.startsWith('dashboard:') && !x.startsWith('tab:'));
    const down = [...closure(id, 'down')];
    if (up.length || down.length) {
      html += `<h4>Full lineage</h4>`;
      if (up.length) html += `<div class="relgroup"><div class="rl">Everything this depends on (${up.length})</div>${chips(up)}</div>`;
      if (down.length) html += `<div class="relgroup"><div class="rl">Everything that depends on this (${down.length})</div>${chips(down)}</div>`;
    }
  }

  const tokUse = n.kind === 'token' ? M.usages.filter(u => u.token === id) : M.usages.filter(u => u.node === id);
  if (tokUse.length) {
    html += `<h4>${n.kind === 'token' ? 'Where it is referenced' : 'Token references'}</h4>` +
      `<div class="tablewrap"><table><thead><tr><th>${n.kind === 'token' ? 'Item' : 'Token'}</th><th>Location</th><th>As written</th></tr></thead><tbody>` +
      tokUse.map(u => `<tr><td>${chip(n.kind === 'token' ? u.node : u.token)}</td><td><code>${esc(u.path)}</code></td><td><code>${esc(u.raw)}</code></td></tr>`).join('') + `</tbody></table></div>`;
  }

  html += `<div style="margin-top:14px"><button class="btn small" id="drawer-map">Show on relationship map</button></div>`;
  if (n.raw) html += `<details style="margin-top:14px"><summary>Definition JSON</summary><pre>${esc(JSON.stringify(n.raw, null, 2))}</pre></details>`;
  $('#drawer-body').innerHTML = html;
  $('#drawer-body').scrollTop = 0;
  $('#drawer-map').onclick = () => { graphState.selected = id; graphState.mode = 'focus'; graphState.center = id; graphState.focus = ''; if (!graphState.tokens && /^(token|input|defaults|condition):/.test(id)) graphState.tokens = true; if (/^(index|sourcetype|lookup|datamodel|macro):/.test(id)) graphState.sources = true; if (id.startsWith('command:')) graphState.commands = true; view = 'graph'; render(); };
  const d = $('#drawer');
  d.classList.add('open'); d.setAttribute('aria-hidden', 'false');
}
function closeDrawer() {
  const d = $('#drawer');
  d.classList.remove('open'); d.setAttribute('aria-hidden', 'true');
  drawerHistory.length = 0;
}

/* ============================================================
   Filtering and sorting
   ============================================================ */
function applyFilter() {
  const q = $('#filter').value.trim().toLowerCase();
  document.querySelectorAll('#view .filterable').forEach(el => { el.hidden = !!q && !el.textContent.toLowerCase().includes(q); });
  // keep tree parents visible if a descendant matches
  if (q) document.querySelectorAll('#view .tree li.filterable').forEach(li => { if (li.querySelector('li.filterable:not([hidden])')) li.hidden = false; });
}
function sortTable(th) {
  const table = th.closest('table'), tbody = table.tBodies[0];
  const idx = [...th.parentNode.children].indexOf(th);
  const dir = th.dataset.dir === 'asc' ? 'desc' : 'asc';
  th.parentNode.querySelectorAll('th').forEach(x => delete x.dataset.dir);
  th.dataset.dir = dir;
  const rows = [...tbody.rows];
  rows.sort((a, b) => {
    const r = (a.cells[idx]?.textContent || '').trim().localeCompare((b.cells[idx]?.textContent || '').trim(), undefined, { numeric: true, sensitivity: 'base' });
    return dir === 'asc' ? r : -r;
  });
  rows.forEach(r => tbody.appendChild(r));
}

/* ============================================================
   Exports
   ============================================================ */
function slug(s) { return String(s || 'dashboard').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'dashboard'; }
// Inside the claude.ai artifact viewer, files go through the viewer's save prompt;
// opened as a local file, fall back to a normal browser download.
const downloadsCap = (window.claude && typeof window.claude.use === 'function') ? window.claude.use('downloads').catch(() => null) : Promise.resolve(null);
async function download(name, data, type) {
  const cap = await downloadsCap;
  if (cap) {
    try { await cap.save({ filename: name, data }); }
    catch (e) { if (e && e.code !== 'declined') alert('Could not save the file: ' + (e.message || e.code || e)); }
    return;
  }
  const blob = data instanceof Blob ? data : new Blob([data], { type });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob); a.download = name;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
}
// Prefix cells that a spreadsheet would read as a formula.
const csvCell = v => { let s = String(v ?? ''); if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; return '"' + s.replace(/"/g, '""') + '"'; };
const csv = rows => rows.map(r => r.map(csvCell).join(',')).join('\r\n');
const ref = id => { const n = M.nodes.get(id); return n ? `${n.kind}:${n.kind === 'token' ? n.label : n.key}` : id; };
function itemDetails(n) {
  switch (n.kind) {
    case 'ds': return n.type === 'ds.savedSearch' ? `| savedsearch "${n.ref}"` : n.query;
    case 'input': return n.token ? `$${n.token}$ default=${fmt(n.defaultValue)}` : '';
    case 'viz': return n.drilldowns.map(d => d.text).join('; ');
    case 'token': return n.status + ((n.defaults || []).length ? ' default=' + n.defaults.map(d => fmt(d.value)).join(' | ') : '');
    case 'condition': return n.value;
    case 'tab': return n.layoutType;
    case 'lookup': return n.accessLabel;
    case 'datamodel': return [...n.datasets].join(', ');
    case 'macro': return n.calls.map(c => '`' + c + '`').join(' ');
    case 'command': return `${n.category}; ${n.uses} uses`;
    default: return n.description || '';
  }
}
function exportInventory() {
  const srcList = (n, f) => n.kind === 'ds' ? (n['eff_' + f] || []).map(v => (v.excluded ? 'NOT ' : '') + v.value).join('; ')
    : n.kind === 'viz' ? vizSources(n.id).filter(x => x.startsWith(f + ':')).map(x => x.slice(f.length + 1)).join('; ') : '';
  const lkList = n => n.kind === 'ds' ? (n.eff_lookups || []).map(l => `${l.mode}:${l.name}`).join('; ')
    : n.kind === 'viz' ? vizSources(n.id).filter(x => x.startsWith('lookup:')).map(x => 'read:' + x.slice(7)).join('; ')
    : n.kind === 'lookup' ? n.accessLabel : '';
  const dmList = n => n.kind === 'ds' ? uniq((n.eff_datamodels || []).map(x => x.model + (x.dataset ? '.' + x.dataset : ''))).join('; ')
    : n.kind === 'viz' ? vizSources(n.id).filter(x => x.startsWith('datamodel:')).map(x => x.slice(10)).join('; ') : '';
  const mcList = n => n.kind === 'ds' ? uniq((n.eff_macros || []).map(x => x.key)).join('; ')
    : n.kind === 'viz' ? vizSources(n.id).filter(x => x.startsWith('macro:')).map(x => x.slice(6)).join('; ') : '';
  const cmdList = n => n.kind === 'ds' ? (n.sources?.commands || []).map(c => c.sub ? `[${c.name}]` : c.name).join(' | ') : n.kind === 'command' ? n.category : '';
  const rows = [['#', 'Kind', 'ID', 'Name / title', 'Type', 'Placed on', 'Data sources', 'Indexes', 'Sourcetypes', 'Lookups', 'Data models', 'Macros', 'Commands', 'Tokens used', 'Tokens set', 'Details', 'Upstream', 'Downstream', 'Issues']];
  // Numbered items first, in inventory order, then the rest (the dashboard itself).
  for (const n of [...invItems(), ...[...M.nodes.values()].filter(x => !invNo(x.id))]) {
    rows.push([
      invNo(n.id), KINDS[n.kind].label, n.kind === 'token' ? n.label : n.key, n.label,
      n.kind === 'ds' ? dsTypeLabel(n.type) : (n.type || n.layoutType || n.status || ''),
      tabsOf(n.id).map(t => M.nodes.get(t).label).join('; '),
      ins(n.id, ['feeds', 'populates', 'extends']).map(e => e.from.slice(3)).join('; '),
      srcList(n, 'index'), srcList(n, 'sourcetype'), lkList(n), dmList(n), mcList(n), cmdList(n),
      directTokens(n.id).map(t => M.nodes.get(t).label).join(' '),
      outs(n.id, ['sets', 'drilldown-sets', 'default', 'smart-source']).map(e => M.nodes.get(e.to).label).join(' '),
      itemDetails(n),
      ins(n.id).map(e => `${REL[e.rel].rev}: ${ref(e.from)}`).join('; '),
      outs(n.id).map(e => `${REL[e.rel].fwd}: ${ref(e.to)}`).join('; '),
      issuesFor(n.id).map(i => `[${i.severity}] ${i.message}`).join(' '),
    ]);
  }
  download(slug(M.title) + '-inventory.csv', '﻿' + csv(rows), 'text/csv;charset=utf-8');
}
function exportRelationships() {
  const rows = [['From kind', 'From ID', 'From name', 'Relationship', 'To kind', 'To ID', 'To name', 'Detail']];
  for (const e of M.edges) {
    const a = M.nodes.get(e.from), b = M.nodes.get(e.to);
    rows.push([KINDS[a.kind].label, a.kind === 'token' ? a.label : a.key, a.label, REL[e.rel].fwd, KINDS[b.kind].label, b.kind === 'token' ? b.label : b.key, b.label, e.detail]);
  }
  download(slug(M.title) + '-relationships.csv', '﻿' + csv(rows), 'text/csv;charset=utf-8');
}
function exportJson() {
  const items = [...M.nodes.values()].map(n => {
    const { raw, _warned, ...rest } = n;
    return rest;
  });
  const out = {
    dashboard: { title: M.title, description: M.description, source: M.format, layout: M.layoutSummary },
    items, relationships: M.edges.map(e => ({ ...e, label: REL[e.rel].fwd })), tokenReferences: M.usages, issues: M.issues
  };
  download(slug(M.title) + '-inventory.json', JSON.stringify(out, null, 2), 'application/json');
}
function exportMarkdown() {
  const c = s => String(s ?? '').replace(/\|/g, '\\|').replace(/\n/g, ' ');
  const t = (head, rows) => rows.length ? `| ${head.join(' | ')} |\n| ${head.map(() => '---').join(' | ')} |\n` + rows.map(r => `| ${r.map(c).join(' | ')} |`).join('\n') + '\n' : '_None._\n';
  const lbl = id => M.nodes.get(id)?.label ?? id;
  const L = ids => ids.map(lbl).join(', ');
  let md = `# ${M.title}\n\n${M.description ? M.description + '\n\n' : ''}`;
  md += `- Source: ${M.format}\n- Layout: ${M.layoutSummary}\n- Generated: ${new Date().toISOString().slice(0, 16).replace('T', ' ')}\n\n`;
  md += `## Summary\n\n` + t(['Item', 'Count'], [['Tabs', M.byKind('tab').filter(x => !x.global).length], ['Inputs', M.byKind('input').length], ['Data sources', M.byKind('ds').length],
    ['…searches', M.byKind('ds').filter(n => n.type === 'ds.search').length], ['…chain searches', M.byKind('ds').filter(n => n.type === 'ds.chain').length],
    ['…saved searches', M.byKind('ds').filter(n => n.type === 'ds.savedSearch').length], ['Visualizations', M.byKind('viz').length], ['Tokens', M.byKind('token').length],
    ['Relationships', M.edges.length], ['Issues', M.issues.length]]);
  md += `\n## Tabs\n\n`;
  for (const tab of M.byKind('tab').sort((a, b) => a.order - b.order)) {
    md += `### ${tab.label}\n\n`;
    md += t(['Item', 'Kind', 'Type', 'Data source lineage', 'Driven by tokens'], ins(tab.id, ['contains']).map(e => {
      const n = M.nodes.get(e.from);
      return [n.label, KINDS[n.kind].label, shortType(n.type), n.kind === 'viz' ? ins(n.id, ['feeds']).map(x => M.nodes.get(x.from).lineage.map(lbl).join(' › ')).join('; ') : '', L(tokensAffecting(n.id))];
    })) + '\n';
  }
  md += `## Inputs\n\n` + t(['Input', 'ID', 'Type', 'Token', 'Default', 'Options from', 'Placed on'], M.byKind('input').map(n => [n.label, n.key, shortType(n.type), n.token ? '$' + n.token + '$' : '', fmt(n.defaultValue), L(ins(n.id, ['populates']).map(e => e.from)), L(tabsOf(n.id))]));
  const vals = (n, f) => (n['eff_' + f] || []).map(v => (v.excluded ? 'NOT ' : '') + v.value).join(', ');
  md += `\n## Data sources\n\n` + t(['Data source', 'ID', 'Type', 'Base search', 'Indexes', 'Sourcetypes', 'Lookups', 'Other sources', 'Time range', 'Used by', 'Tokens'], M.byKind('ds').map(n => [n.label, n.key, dsTypeLabel(n.type), n.extend, vals(n, 'index'), vals(n, 'sourcetype'), (n.eff_lookups || []).map(l => `${l.name} (${l.mode})`).join(', '), n.eff_other.join(', '), n.earliest ? `${n.earliest.v} → ${n.latest.v}` : '', L(outs(n.id, ['feeds', 'populates', 'extends']).map(e => e.to)), L(directTokens(n.id))]));
  if (M.byKind('datamodel').length) md += `\n## Data models\n\n` + t(['Data model', 'Datasets', 'Read by', 'Feeds visualizations'], M.byKind('datamodel').map(n => [n.label, [...n.datasets].join(', '), outs(n.id, ['datamodel-read']).map(e => `${lbl(e.to)} (${e.detail})`).join(', '), L(dataDown(n.id).filter(x => x.startsWith('viz:')))]));
  if (M.byKind('macro').length) md += `\n## Macros\n\n` + t(['Macro', 'Arguments', 'Calls as written', 'Used by'], M.byKind('macro').map(n => [n.key, n.arity, n.calls.map(c => '`' + c + '`').join(' '), L(outs(n.id, ['macro-used']).map(e => e.to))]));
  md += `\n## SPL commands\n\n` + t(['Command', 'Category', 'Uses', 'Used by'], M.byKind('command').sort((a, b) => b.uses - a.uses).map(n => [n.label, n.category, n.uses, outs(n.id, ['command-used']).map(e => lbl(e.to) + (e.detail ? ` (${e.detail})` : '')).join(', ')]));
  md += `\n### Pipelines\n\n` + t(['Data source', 'Pipeline'], M.byKind('ds').map(n => [n.label, (n.sources?.commands || []).map(c => c.sub ? `[${c.name}]` : c.name).join(' → ')]));
  if (M.byKind('lookup').length) md += `\n## Lookups\n\n` + t(['Lookup', 'Access', 'Read by', 'Written by', 'Feeds visualizations'], M.byKind('lookup').map(n => [n.label, n.accessLabel, outs(n.id, ['lookup-read']).map(e => `${lbl(e.to)} (${e.detail})`).join(', '), ins(n.id, ['lookup-write']).map(e => `${lbl(e.from)} (${e.detail})`).join(', '), L(dataDown(n.id).filter(x => x.startsWith('viz:')))]));
  md += `\n## Indexes & sourcetypes\n\n` + t(['Name', 'Kind', 'Read directly by', 'Feeds visualizations'], [...M.byKind('index'), ...M.byKind('sourcetype')].map(n => [n.label, KINDS[n.kind].label, outs(n.id, ['searches']).map(e => lbl(e.to) + (e.detail ? ` (${e.detail})` : '')).join(', '), L(dataDown(n.id).filter(x => x.startsWith('viz:')))]));
  md += `\n### Queries\n\n`;
  for (const n of M.byKind('ds')) md += `**${n.label}** (\`${n.key}\`, ${dsTypeLabel(n.type)})\n\n\`\`\`spl\n${n.type === 'ds.savedSearch' ? `| savedsearch "${n.ref}"` : n.effectiveQuery || n.query}\n\`\`\`\n\n`;
  md += `## Visualizations\n\n` + t(['Visualization', 'ID', 'Type', 'Placed on', 'Data source', 'Tokens used', 'Sets tokens', 'Drilldown'], M.byKind('viz').map(n => [n.label, n.key, shortType(n.type), L(tabsOf(n.id)), L(ins(n.id, ['feeds']).map(e => e.from)), L(directTokens(n.id)), L(outs(n.id, ['drilldown-sets']).map(e => e.to)), n.drilldowns.map(d => d.text).join('; ')]));
  md += `\n## Tokens\n\n` + t(['Token', 'Status', 'Set by', 'Default', 'Used by'], M.byKind('token').map(n => [n.label, n.status, L(ins(n.id, ['sets', 'drilldown-sets', 'default', 'smart-source']).map(e => e.from)), (n.defaults || []).map(d => fmt(d.value)).join(', '), L(uniq(outs(n.id, ['uses-token']).map(e => e.to)))]));
  if (M.byKind('condition').length) md += `\n## Visibility conditions\n\n` + t(['Condition', 'Expression', 'Controls'], M.byKind('condition').map(n => [n.label, n.value, L(outs(n.id, ['visibility']).map(e => e.to))]));
  md += `\n## Issues\n\n` + t(['Severity', 'Item', 'Issue'], M.issues.map(i => [i.severity, lbl(i.ref), i.message]));
  download(slug(M.title) + '-inventory.md', md, 'text/markdown;charset=utf-8');
}

/* ============================================================
   Full report (PDF or Markdown)
   One list of blocks describes the report; each format renders it.
   Blocks: h1 h2 h3 h4 p list code table img
   ============================================================ */
function reportBlocks(format) {
  const B = [];
  let sec = 0;
  const h1 = text => B.push({ t: 'h1', text });
  const h2 = text => B.push({ t: 'h2', text: `${++sec}. ${text}` });
  const h3 = text => B.push({ t: 'h3', text });
  const h4 = text => B.push({ t: 'h4', text });
  const p = text => B.push({ t: 'p', text });
  const code = (text, lang = 'spl') => B.push({ t: 'code', text: String(text ?? ''), lang });
  const tbl = (head, rows) => B.push({ t: 'table', head, rows: rows.map(r => r.map(c => c == null ? '' : String(c))) });
  const lbl = id => M.nodes.get(id)?.label ?? id;
  const num = id => invNo(id) ? '#' + invNo(id) : '';
  const L = ids => uniq(ids).map(lbl).join(', ');
  const vals = (n, f) => (n['eff_' + f] || []).map(v => (v.excluded ? 'NOT ' : '') + v.value + (v.inherited ? ' (from base)' : '') + (v.via ? ` (${v.via})` : '')).join(', ');
  const lineage = n => ins(n.id, ['feeds']).map(e => M.nodes.get(e.from).lineage.map(lbl).join(' > ')).join('; ');
  const sev = s => M.issues.filter(i => i.severity === s).length;
  const tabs = mockTabs();

  h1(M.title);
  if (M.description) p(M.description);
  tbl(['Field', 'Value'], [
    ['Source', M.format], ['Layout', M.layoutSummary], ['Generated', new Date().toISOString().slice(0, 16).replace('T', ' ') + ' UTC'],
    ['Items', invItems().length], ['Relationships', M.edges.length],
    ['Issues', `${plural(sev('error'), 'error')}, ${plural(sev('warning'), 'warning')}, ${plural(sev('info'), 'note')}`],
    ['Splunk config', hasConfig() ? `${plural(CONFIG.macros.size, 'macro')}, ${plural(CONFIG.saved.size, 'saved search', 'saved searches')}, ${plural(CONFIG.datamodels.size, 'data model')} (expanded)` : 'not loaded'],
  ]);
  if ((M.src.repairs || []).length || (M.src.notes || []).length) B.push({ t: 'list', items: [...(M.src.repairs || []).map(r => ({ text: 'Repaired while loading: ' + r })), ...(M.src.notes || []).map(r => ({ text: r }))] });

  B.push({ t: 'toc' });

  h2('Summary');
  const ds = M.byKind('ds');
  tbl(['Item', 'Count', 'Detail'], [
    ['Tabs', tabs.length, tabs.map(t => t.label).join(', ')],
    ['Inputs', M.byKind('input').length, uniq(M.byKind('input').map(n => shortType(n.type))).join(', ')],
    ['Data sources', ds.length, `${plural(ds.filter(n => n.type === 'ds.search').length, 'search', 'searches')}, ${plural(ds.filter(n => n.type === 'ds.chain').length, 'chain search', 'chain searches')}, ${plural(ds.filter(n => n.type === 'ds.savedSearch').length, 'saved search', 'saved searches')}`],
    ['Visualizations', M.byKind('viz').length, uniq(M.byKind('viz').map(n => shortType(n.type))).join(', ')],
    ['Tokens', M.byKind('token').length, `${M.byKind('token').filter(t => t.status === 'Defined').length} defined, ${M.byKind('token').filter(t => t.status === 'Undefined').length} undefined`],
    ['Visibility conditions', M.byKind('condition').length, ''],
    ['Indexes', M.byKind('index').length, L(M.byKind('index').map(n => n.id))],
    ['Sourcetypes', M.byKind('sourcetype').length, L(M.byKind('sourcetype').map(n => n.id))],
    ['Lookups', M.byKind('lookup').length, M.byKind('lookup').map(n => `${n.label} (${n.accessLabel})`).join(', ')],
    ['Data models', M.byKind('datamodel').length, L(M.byKind('datamodel').map(n => n.id))],
    ['Macros', M.byKind('macro').length, M.byKind('macro').map(n => n.key).join(', ')],
    ['SPL commands', M.byKind('command').length, M.byKind('command').sort((a, b) => b.uses - a.uses).map(n => n.label).join(', ')],
  ]);

  h2('Issues');
  if (!M.issues.length) p('No issues found.');
  else tbl(['Severity', '#', 'Item', 'Issue', 'Automatic fix'], M.issues.map(i => [i.severity, num(i.ref), lbl(i.ref), i.message, i.fix?.label || '']));

  h2('Recommendations');
  const recs = recommendations();
  if (!recs.length) p('No recommendations: nothing matched the optimisation and best-practice checks.');
  else {
    p('Suggested improvements for speed, maintenance and safety. Nothing here is broken; check each against how the dashboard is used.');
    tbl(['Impact', 'Category', 'Recommendation', 'Applies to'], recs.map(r => [r.impact, r.category, r.title, r.items.map(id => `${num(id)} ${lbl(id)}`.trim()).join(', ')]));
    recs.forEach((r, k) => {
      h4(`${k + 1}. ${r.title} (${r.impact} impact, ${r.category})`);
      p(r.why);
      p('What to do: ' + r.how);
      if (r.example) code(r.example);
      p('Applies to: ' + r.items.map(id => `${num(id)} ${lbl(id)}`.trim()).join(', '));
    });
  }

  const cs = compatSummary();
  if (cs.rows.length) {
    h2('Splunk version compatibility');
    p(`This dashboard needs Splunk Enterprise ${cs.needs} or later, because it uses ${cs.why.join(', ')}. Minimum versions are approximate.` + (compatState.version ? ` Checked against ${compatState.version === 'cloud' ? 'Splunk Cloud Platform' : 'Splunk Enterprise ' + compatState.version}: ${cs.unsupported.length ? plural(cs.unsupported.length, 'feature') + ' not supported.' : 'everything is supported.'}` : ''));
    tbl(['Feature', 'Needs', 'Used by', 'On the chosen version'], cs.rows.map(r => [r.feature, r.min + (r.edited ? ' (corrected)' : ''), r.used.map(id => `${num(id)} ${lbl(id)}`.trim()).join(', '),
      !compatState.version ? '' : compatState.version === 'cloud' || cmpVer(r.min, compatState.version) <= 0 ? 'supported' : 'NOT supported']));
  }

  h2('Layout');
  const global = M.nodes.get('tab:__global__');
  if (global) {
    h3('Global inputs (all tabs)');
    tbl(['#', 'Input', 'ID', 'Type', 'Token', 'Default'], (global.items || []).map(i => M.nodes.get(i.id)).filter(Boolean)
      .map(n => [num(n.id), n.label, n.key, shortType(n.type), n.token ? '$' + n.token + '$' : '', fmt(n.defaultValue)]));
  }
  for (const t of tabs) {
    h3(`${t.label} (${t.key}, ${t.layoutType || 'canvas'} layout)`);
    if ((format === 'pdf' || format === 'html') && (t.items || []).length) B.push({ t: 'img', svg: mockupSvg(t.id, true), caption: `Mockup of "${t.label}". Positions from the layout; charts are placeholders.` });
    tbl(['#', 'Item', 'Kind', 'Type', 'Position (x, y, w x h)', 'Data source lineage'], (t.items || []).map(i => {
      const n = M.nodes.get(i.id), ps = i.position;
      return [num(n.id), n.label, KINDS[n.kind].label, shortType(n.type), ps && ps.x !== undefined ? `${ps.x}, ${ps.y}, ${ps.w} x ${ps.h}` : '', n.kind === 'viz' ? lineage(n) : (n.token ? 'sets $' + n.token + '$' : '')];
    }));
  }

  h2('Inventory');
  p('Every item, numbered in inventory order. The numbers match the rest of this report and the Inventory page.');
  tbl(['#', 'Item', 'Kind', 'ID', 'Type', 'Placed on', 'Depends on', 'Used by'], invItems().map(n => [
    num(n.id), n.label, KINDS[n.kind].label, n.kind === 'token' ? n.label : n.key, invType(n),
    L(tabsOf(n.id).filter(x => x.startsWith('tab:'))),
    L(ins(n.id).filter(e => e.rel !== 'contains').map(e => e.from)), L(outs(n.id).filter(e => e.rel !== 'contains').map(e => e.to)),
  ]));

  h2('Inputs');
  tbl(['#', 'Input', 'ID', 'Type', 'Token', 'Default', 'Options', 'Placed on', 'Uses tokens', 'Visibility'], M.byKind('input').map(n => [
    num(n.id), n.label, n.key, shortType(n.type), n.token ? '$' + n.token + '$' : '(none)', fmt(n.defaultValue),
    [L(ins(n.id, ['populates']).map(e => e.from)), n.items ? `${n.items.length} static` : ''].filter(Boolean).join('; '),
    L(tabsOf(n.id)), L(directTokens(n.id)), n.visibility || '',
  ]));

  h2('Data sources and searches');
  h3('Search lineage');
  const items = [];
  const walkTree = (id, depth, seen) => {
    if (seen.has(id)) return;
    seen = new Set(seen).add(id);
    const n = M.nodes.get(id);
    const cons = outs(id, ['feeds', 'populates']).map(e => lbl(e.to));
    items.push({ depth, text: `${num(id)} ${n.label} (${dsTypeLabel(n.type)})${cons.length ? ' -> ' + cons.join(', ') : ''}` });
    for (const e of outs(id, ['extends'])) walkTree(e.to, depth + 1, seen);
  };
  for (const n of ds.filter(n => n.depth === 0 || n.cycle)) walkTree(n.id, 0, new Set());
  if (items.length) B.push({ t: 'list', items }); else p('No data sources.');
  h3('All data sources');
  tbl(['#', 'Data source', 'ID', 'Type', 'Base search', 'Time range', 'Refresh', 'Used by', 'Uses tokens'], ds.map(n => [
    num(n.id), n.label, n.key, dsTypeLabel(n.type), n.extend ? lbl('ds:' + n.extend) : '',
    n.earliest ? `${n.earliest.v} -> ${n.latest.v}${n.earliest.src ? ' (' + n.earliest.src + ')' : ''}` : '', n.refresh ? fmt(n.refresh) : '',
    L(outs(n.id, ['feeds', 'populates', 'extends']).map(e => e.to)), L(directTokens(n.id)),
  ]));
  h3('What each search reads');
  tbl(['#', 'Data source', 'Indexes', 'Sourcetypes', 'Lookups', 'Data models', 'Macros', 'Other'], ds.map(n => [
    num(n.id), n.label, vals(n, 'index'), vals(n, 'sourcetype'),
    (n.eff_lookups || []).map(l => `${l.name} (${l.mode})`).join(', '), uniq((n.eff_datamodels || []).map(d => d.model + (d.dataset ? '.' + d.dataset : ''))).join(', '),
    uniq((n.eff_macros || []).map(m => m.key)).join(', '), (n.eff_other || []).join(', '),
  ]));
  h3('SPL');
  for (const n of ds) {
    h4(`${num(n.id)} ${n.label} (${n.key}, ${dsTypeLabel(n.type)})`);
    code(n.type === 'ds.savedSearch' ? `| savedsearch "${n.ref}"` : n.query || '(empty)');
    if (n.depth > 0) { p('Effective SPL (base and chain together):'); code(n.effectiveQuery); }
    if (n.expandedQuery) { p('Expanded SPL (macros, saved searches and data model constraints resolved, for analysis):'); code(n.expandedQuery); }
  }

  h2('Indexes, sourcetypes, lookups, data models and macros');
  h3('Indexes and sourcetypes');
  tbl(['#', 'Name', 'Kind', 'Read directly by', 'Feeds visualizations'], [...M.byKind('index'), ...M.byKind('sourcetype')].map(n => [
    num(n.id), n.label, KINDS[n.kind].label, outs(n.id, ['searches']).map(e => lbl(e.to) + (e.detail ? ` (${e.detail})` : '')).join(', '), L(dataDown(n.id).filter(x => x.startsWith('viz:')))]));
  h3('Lookups');
  tbl(['#', 'Lookup', 'Access', 'Read by', 'Written by', 'Feeds visualizations'], M.byKind('lookup').map(n => [
    num(n.id), n.label, n.accessLabel, outs(n.id, ['lookup-read']).map(e => `${lbl(e.to)} (${e.detail})`).join(', '),
    ins(n.id, ['lookup-write']).map(e => `${lbl(e.from)} (${e.detail})`).join(', '), L(dataDown(n.id).filter(x => x.startsWith('viz:')))]));
  h3('Data models');
  tbl(['#', 'Data model', 'Datasets', 'Read by', 'Constraints'], M.byKind('datamodel').map(n => [
    num(n.id), n.label, [...n.datasets].join(', '), outs(n.id, ['datamodel-read']).map(e => `${lbl(e.to)} (${e.detail})`).join(', '),
    n.config ? n.config.objects.map(o => `${o.name}: ${o.constraints.join(' ') || '-'}`).join('; ') : 'not loaded']));
  h3('Macros');
  tbl(['#', 'Macro', 'Arguments', 'Calls as written', 'Definition', 'Used by'], M.byKind('macro').map(n => [
    num(n.id), n.key, n.arity, n.calls.map(c => '`' + c + '`').join(' '), n.config ? n.config.definition : 'not loaded', L(outs(n.id, ['macro-used']).map(e => e.to))]));

  h2('SPL commands');
  tbl(['#', 'Command', 'Category', 'Uses', 'Used by'], M.byKind('command').sort((a, b) => b.uses - a.uses).map(n => [
    num(n.id), n.label, n.category, n.uses, outs(n.id, ['command-used']).map(e => lbl(e.to) + (e.detail ? ` (${e.detail})` : '')).join(', ')]));
  h3('Pipeline of each search');
  tbl(['#', 'Data source', 'Pipeline'], ds.map(n => [num(n.id), n.label, (n.sources?.commands || []).map(c => (c.sub ? `[${c.name}]` : c.name) + (c.implicit && c.name === 'search' ? ' (implicit)' : '')).join(' | ')]));

  h2('Visualizations');
  tbl(['#', 'Visualization', 'ID', 'Type', 'Placed on', 'Data source lineage', 'Reads from', 'Uses tokens', 'Sets tokens', 'Drilldown', 'Visibility'], M.byKind('viz').map(n => [
    num(n.id), n.label, n.key, shortType(n.type), L(tabsOf(n.id)), lineage(n), L(vizSources(n.id)), L(directTokens(n.id)),
    L(outs(n.id, ['drilldown-sets']).map(e => e.to)), n.drilldowns.map(d => d.text).join('; '), n.visibility || '']));

  if (format === 'pdf' || format === 'html') {
    const fed = M.byKind('viz').filter(v => ins(v.id, ['feeds']).length);
    if (fed.length) {
      h2('Panel lineage maps');
      p(`What feeds each panel: its searches, sources, and the inputs and tokens that change it. Tokens used by four or more items are shown as badges.${fed.length > 40 ? ' The first 40 panels are shown.' : ''}`);
      for (const v of fed.slice(0, 40)) { h3(`${num(v.id)} ${v.label}`.trim()); B.push({ t: 'img', svg: panelLineageSvg(v.id), caption: '' }); }
    }
  }
  const outLinks = dashLinks(CUR_I);
  if (outLinks.length) {
    h2('Links to other dashboards');
    tbl(['#', 'Panel', 'Opens', 'Loaded here', 'Passes tokens'], outLinks.map(l => [num(l.viz.id), l.viz.label, targetLabel(l.target), l.to >= 0 ? DASH[l.to].model.title : 'no', l.target.tokens.map(t => `${t.token}=${t.value}`).join(', ')]));
  }

  h2('Tokens');
  tbl(['#', 'Token', 'Status', 'Set by', 'Default', 'Used by'], M.byKind('token').map(t => [
    num(t.id), t.label, t.status, ins(t.id, ['sets', 'drilldown-sets', 'default', 'smart-source']).map(e => `${lbl(e.from)} (${REL[e.rel].rev.toLowerCase()})`).join(', '),
    (t.defaults || []).map(d => fmt(d.value)).join(', '), L(outs(t.id, ['uses-token']).map(e => e.to))]));
  const savedCols = matState.cols, savedRows = matState.rows, savedSort = matState.sort;
  Object.assign(matState, { cols: 'viz', rows: 'token', sort: 'def' });
  const mcols = matrixColumns();
  Object.assign(matState, { cols: savedCols, rows: savedRows, sort: savedSort });
  if (M.byKind('token').length && mcols.length && mcols.length <= 24) {
    h3('Token matrix (tokens x panels)');
    p('D = uses it directly, S = through its search, C = through a visibility condition, set = sets it.');
    const abbr = { direct: 'D', search: 'S', condition: 'C', sets: 'set' };
    tbl(['Token', ...mcols.map(c => `${num(c.id)} ${lbl(c.id)}`.trim())], M.byKind('token').map(t => [t.label, ...mcols.map(c => tokenLinks(t.id, c.id).map(x => abbr[x]).join(' '))]));
  }
  h3('Where each token is referenced');
  tbl(['Token', 'Item', 'Location', 'As written'], M.usages.map(u => [lbl(u.token), `${num(u.node)} ${lbl(u.node)}`.trim(), u.path, u.raw]));

  if (M.byKind('condition').length) {
    h2('Visibility conditions');
    tbl(['#', 'Condition', 'ID', 'Expression', 'Uses tokens', 'Controls'], M.byKind('condition').map(n => [
      num(n.id), n.label, n.key, n.value, L(directTokens(n.id)), outs(n.id, ['visibility']).map(e => `${lbl(e.to)} (${e.detail})`).join(', ')]));
  }

  h2('Relationships');
  if (format === 'pdf' || format === 'html') {
    const sk = sankeySvg(true);
    if (sk) B.push({ t: 'img', svg: sk, caption: 'Data flow: sources -> base searches -> panels -> tabs. Band width is the number of panels.' });
  }
  p('Every connection, in the direction data and token values flow.');
  tbl(['From', 'Relationship', 'To', 'Detail'], M.edges.map(e => [
    `${num(e.from)} ${lbl(e.from)} (${KINDS[M.nodes.get(e.from).kind].label})`.trim(), REL[e.rel].fwd, `${num(e.to)} ${lbl(e.to)} (${KINDS[M.nodes.get(e.to).kind].label})`.trim(), e.detail]));

  if (hasConfig()) {
    h2('Splunk configuration used');
    tbl(['Macro', 'Arguments', 'Definition'], [...CONFIG.macros.values()].map(m => [m.key, m.args.join(', '), m.definition]));
    tbl(['Saved search', 'Search', 'Time range', 'Schedule'], [...CONFIG.saved.values()].map(s => [s.name, s.search, `${s.earliest || '...'} -> ${s.latest || 'now'}`, s.cron]));
    tbl(['Data model', 'Datasets and constraints'], [...CONFIG.datamodels.values()].map(d => [d.name, d.objects.map(o => `${o.name}: ${o.constraints.join(' ') || '-'}`).join('; ')]));
  }

  h2('Appendix: dashboard definition');
  p(M.src.classic ? 'Converted from Classic Simple XML to the Studio model.' : 'The definition as loaded, after any repairs.');
  code(JSON.stringify(stripInternal(structuredClone(M.src.def)), null, 2), 'json');
  return B;
}

/* ---------- Markdown ---------- */
function blocksToMarkdown(B) {
  const cell = s => String(s ?? '').replace(/\|/g, '\\|').replace(/\r?\n/g, '<br>');
  const anchor = s => s.toLowerCase().replace(/[^\w\s-]/g, '').trim().replace(/\s+/g, '-');
  const out = [];
  for (const b of B) {
    switch (b.t) {
      case 'toc': out.push('## Contents\n\n' + B.filter(x => x.t === 'h2').map(x => `- [${x.text}](#${anchor(x.text)})`).join('\n') + '\n'); break;
      case 'h1': out.push(`# ${b.text}\n`); break;
      case 'h2': out.push(`## ${b.text}\n`); break;
      case 'h3': out.push(`### ${b.text}\n`); break;
      case 'h4': out.push(`#### ${b.text}\n`); break;
      case 'p': out.push(b.text + '\n'); break;
      case 'list': out.push(b.items.map(it => '  '.repeat(it.depth || 0) + '- ' + it.text).join('\n') + '\n'); break;
      case 'code': {
        let fence = '```';
        while (b.text.includes(fence)) fence += '`';
        out.push(`${fence}${b.lang || ''}\n${b.text}\n${fence}\n`);
        break;
      }
      case 'table':
        out.push(b.rows.length ? `| ${b.head.map(cell).join(' | ')} |\n| ${b.head.map(() => '---').join(' | ')} |\n` + b.rows.map(r => `| ${r.map(cell).join(' | ')} |`).join('\n') + '\n' : '_None._\n');
        break;
      case 'img': out.push(`_${b.caption} The mockup image is in the PDF report and under Export → Mockup._\n`); break;
    }
  }
  return out.join('\n');
}
async function exportReportMd() {
  try { download(slug(M.title) + '-report.md', blocksToMarkdown(reportBlocks('md')), 'text/markdown;charset=utf-8'); }
  catch (e) { console.error(e); toast('The report could not be built: ' + e.message); }
}

/* ---------- PDF ---------- */
const PDF_LIBS = [libUrl('https://cdn.jsdelivr.net/npm/jspdf@4.2.1/dist/jspdf.umd.min.js', 'lib/jspdf.umd.min.js'), libUrl('https://cdn.jsdelivr.net/npm/jspdf-autotable@5.0.9/dist/jspdf.plugin.autotable.min.js', 'lib/jspdf.plugin.autotable.min.js')];
let pdfLibPromise = null;
function loadPdfLib() {
  if (window.jspdf?.jsPDF?.API?.autoTable) return Promise.resolve(window.jspdf.jsPDF);
  pdfLibPromise ||= (async () => {
    for (const src of PDF_LIBS) {
      await new Promise((res, rej) => {
        const s = document.createElement('script');
        const timer = setTimeout(() => rej(new Error('timed out')), 20000);
        s.src = src; s.async = true;
        s.onload = () => { clearTimeout(timer); res(); };
        s.onerror = () => { clearTimeout(timer); rej(new Error('blocked or offline')); };
        document.head.appendChild(s);
      });
    }
    if (!window.jspdf?.jsPDF?.API?.autoTable) throw new Error('the PDF library did not initialise');
    return window.jspdf.jsPDF;
  })().catch(e => { pdfLibPromise = null; throw e; });
  return pdfLibPromise;
}
// The built-in PDF fonts cover Latin-1 only; spell out the few symbols this page uses outside it.
const PDF_MAP = { '→': '->', '←': '<-', '↔': '<->', '≥': '>=', '≤': '<=', '≠': '!=', '…': '...', '“': '"', '”': '"', '‘': "'", '’': "'", '—': '-', '–': '-', '›': '>', '‹': '<', '•': '-', '✓': 'v', '✕': 'x', '▾': 'v', '🕑': '' };
const pdfSafe = s => String(s ?? '').replace(/[^\x09\x0A\x0D\x20-\x7E\xA0-\xFF]/gu, ch => PDF_MAP[ch] ?? '?');
// SVG → JPEG data URL on white, for embedding in the PDF.
async function svgToJpeg(svg, scale = 2) {
  const url = URL.createObjectURL(new Blob([svg], { type: 'image/svg+xml' }));
  try {
    const img = new Image();
    await new Promise((res, rej) => { img.onload = res; img.onerror = () => rej(new Error('image')); img.src = url; });
    const c = document.createElement('canvas');
    c.width = img.width * scale; c.height = img.height * scale;
    const g = c.getContext('2d');
    g.fillStyle = '#ffffff'; g.fillRect(0, 0, c.width, c.height);
    g.scale(scale, scale); g.drawImage(img, 0, 0);
    return { url: c.toDataURL('image/jpeg', 0.92), w: img.width, h: img.height };
  } finally { URL.revokeObjectURL(url); }
}
async function blocksToPdf(B, jsPDF) {
  const doc = new jsPDF({ orientation: 'landscape', unit: 'pt', format: 'a4', compress: true });
  const PW = doc.internal.pageSize.getWidth(), PH = doc.internal.pageSize.getHeight(), MG = 36, W = PW - 2 * MG, BOTTOM = PH - MG - 12;
  const INK = [27, 31, 36], MUTED = [95, 107, 122], ACCENT = [47, 111, 222], LINE = [221, 225, 231];
  let y = MG;
  const ensure = h => { if (y + h > BOTTOM) { doc.addPage(); y = MG; } };
  const text = (s, size, style = 'normal', color = INK, after = 4, font = 'helvetica') => {
    doc.setFont(font, style); doc.setFontSize(size); doc.setTextColor(...color);
    for (const line of doc.splitTextToSize(pdfSafe(s), W)) { ensure(size * 1.3); doc.text(line, MG, y + size); y += size * 1.3; }
    y += after;
  };
  doc.setProperties({ title: pdfSafe(M.title + ' - dashboard report'), subject: 'Splunk dashboard inventory report', creator: 'Studio Dashboard Inventory' });
  // Draw the images first so their size is known: a heading then stays on the same page as its image.
  const imgs = new Map();
  for (const b of B) if (b.t === 'img') {
    const im = await svgToJpeg(b.svg);
    const r = im.h / im.w, maxH = BOTTOM - MG - 40;
    let w = W, h = w * r;
    if (h > maxH) { h = maxH; w = h / r; }
    imgs.set(b, { ...im, w, h });
  }
  const sections = []; // [{ text, page }] for the contents
  let toc = null;
  for (let bi = 0; bi < B.length; bi++) {
    const b = B[bi], next = B[bi + 1];
    switch (b.t) {
      case 'h1': text(b.text, 20, 'bold', INK, 6); break;
      case 'toc': // space for the contents, filled in once page numbers are known
        toc = { page: doc.getNumberOfPages(), y: y + 6 };
        y += 36 + B.filter(x => x.t === 'h2').length * 15;
        break;
      case 'h2':
        if (y > MG + 120) { doc.addPage(); y = MG; } else y += 10;
        sections.push({ text: b.text, page: doc.getNumberOfPages() });
        doc.outline.add(null, pdfSafe(b.text), { pageNumber: doc.getNumberOfPages() });
        text(b.text, 15, 'bold', ACCENT, 2);
        doc.setDrawColor(...LINE); doc.setLineWidth(0.8); doc.line(MG, y, MG + W, y); y += 10;
        break;
      case 'h3': y += 4; ensure(next?.t === 'img' ? imgs.get(next).h + 44 : 60); text(b.text, 12, 'bold', INK, 4); break;
      case 'h4': ensure(40); text(b.text, 9.5, 'bold', INK, 3); break;
      case 'p': text(b.text, 9.5, 'normal', INK, 5); break;
      case 'list':
        doc.setFont('helvetica', 'normal'); doc.setFontSize(9); doc.setTextColor(...INK);
        for (const it of b.items) {
          const ind = (it.depth || 0) * 14;
          doc.splitTextToSize(pdfSafe(it.text), W - ind - 10).forEach((l, k) => { ensure(12); doc.text((k ? '   ' : '- ') + l, MG + ind, y + 9); y += 12; });
        }
        y += 5;
        break;
      case 'code': {
        doc.setFont('courier', 'normal'); doc.setFontSize(7.5);
        const lines = doc.splitTextToSize(pdfSafe(b.text), W - 12);
        for (const l of lines) { ensure(10); doc.setFillColor(243, 245, 248); doc.rect(MG, y, W, 10, 'F'); doc.setTextColor(...INK); doc.text(l, MG + 6, y + 7.5); y += 10; }
        y += 8;
        break;
      }
      case 'table':
        if (!b.rows.length) { text('None.', 9, 'italic', MUTED, 6); break; }
        ensure(40);
        doc.autoTable({
          head: [b.head.map(pdfSafe)], body: b.rows.map(r => r.map(pdfSafe)), startY: y,
          margin: { left: MG, right: MG, top: MG, bottom: MG + 12 }, theme: 'grid', rowPageBreak: 'auto',
          styles: { font: 'helvetica', fontSize: 7.5, cellPadding: 3, overflow: 'linebreak', valign: 'top', lineColor: LINE, lineWidth: 0.5, textColor: INK },
          headStyles: { fillColor: [241, 243, 246], textColor: INK, fontStyle: 'bold' },
          columnStyles: b.head[0] === '#' ? { 0: { cellWidth: 26, textColor: MUTED } } : {},
        });
        y = doc.lastAutoTable.finalY + 12;
        break;
      case 'img': {
        const im = imgs.get(b), w = im.w, h = im.h;
        ensure(h + 18);
        doc.setDrawColor(...LINE); doc.rect(MG - 0.5, y - 0.5, w + 1, h + 1);
        doc.addImage(im.url, 'JPEG', MG, y, w, h);
        y += h + 6;
        if (b.caption) text(b.caption, 8, 'italic', MUTED, 8);
        break;
      }
    }
  }
  if (toc) {
    doc.setPage(toc.page);
    let ty = toc.y;
    doc.setFont('helvetica', 'bold'); doc.setFontSize(13); doc.setTextColor(...INK);
    doc.text('Contents', MG, ty + 13); ty += 24;
    doc.setFontSize(10);
    for (const sct of sections) {
      doc.setFont('helvetica', 'normal'); doc.setTextColor(...ACCENT);
      doc.text(pdfSafe(sct.text), MG + 4, ty + 10);
      doc.setTextColor(...MUTED);
      doc.text(String(sct.page), MG + Math.min(W, 420), ty + 10, { align: 'right' });
      doc.link(MG, ty, Math.min(W, 420), 14, { pageNumber: sct.page });
      ty += 15;
    }
  }
  const n = doc.getNumberOfPages();
  for (let i = 1; i <= n; i++) {
    doc.setPage(i); doc.setFont('helvetica', 'normal'); doc.setFontSize(8); doc.setTextColor(...MUTED);
    doc.text(pdfSafe(M.title), MG, PH - 18);
    doc.text(`Page ${i} of ${n}`, PW - MG, PH - 18, { align: 'right' });
  }
  return doc.output('blob');
}
/* ---------- HTML fallback (print to PDF) ---------- */
function blocksToHtml(B) {
  const body = B.map(b => {
    switch (b.t) {
      case 'h1': return `<h1>${esc(b.text)}</h1>`;
      case 'h2': return `<h2>${esc(b.text)}</h2>`;
      case 'h3': return `<h3>${esc(b.text)}</h3>`;
      case 'h4': return `<h4>${esc(b.text)}</h4>`;
      case 'p': return `<p>${esc(b.text)}</p>`;
      case 'list': return `<ul>${b.items.map(it => `<li style="margin-left:${(it.depth || 0) * 18}px">${esc(it.text)}</li>`).join('')}</ul>`;
      case 'code': return `<pre>${esc(b.text)}</pre>`;
      case 'table': return b.rows.length ? `<table><thead><tr>${b.head.map(h => `<th>${esc(h)}</th>`).join('')}</tr></thead><tbody>${b.rows.map(r => `<tr>${r.map(c => `<td>${esc(c)}</td>`).join('')}</tr>`).join('')}</tbody></table>` : '<p class="m">None.</p>';
      case 'img': return `<figure>${b.svg}<figcaption>${esc(b.caption || '')}</figcaption></figure>`;
      default: return '';
    }
  }).join('\n');
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(M.title)} · report</title>
<style>body{font:12px/1.45 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;color:#1b1f24;background:#fff;margin:24px auto;max-width:1100px;padding:0 16px}
h1{font-size:22px}h2{font-size:16px;color:#2f6fde;border-bottom:1px solid #dde1e7;padding-bottom:3px;margin-top:28px}h3{font-size:13.5px;margin:18px 0 6px}h4{font-size:12px;margin:12px 0 4px}
table{border-collapse:collapse;width:100%;margin:4px 0 12px}th,td{border:1px solid #dde1e7;padding:3px 6px;text-align:left;vertical-align:top;overflow-wrap:anywhere}th{background:#f1f3f6}
pre{background:#f3f5f8;padding:8px;white-space:pre-wrap;word-break:break-word;font:11px ui-monospace,Menlo,Consolas,monospace}figure{margin:6px 0 12px}figure svg{width:100%;height:auto;border:1px solid #dde1e7}figcaption,.m{color:#5f6b7a;font-size:11px}
.noprint{margin:10px 0}@media print{.noprint{display:none}body{margin:0;max-width:none}h2{break-before:page}table,figure{break-inside:auto}tr{break-inside:avoid}}</style></head>
<body><div class="noprint"><button onclick="window.print()">Print or save as PDF</button></div>${body}</body></html>`;
}
let pdfBusy = false;
async function exportReportPdf() {
  if (pdfBusy) return;
  pdfBusy = true;
  toast('Building the PDF report…', 0);
  try {
    let jsPDF;
    try { jsPDF = await loadPdfLib(); }
    catch (e) {
      download(slug(M.title) + '-report.html', blocksToHtml(reportBlocks('html')), 'text/html;charset=utf-8');
      toast(`The PDF library couldn't be loaded (${e.message}), so the full report was saved as an HTML file instead. Open it and choose Print, then Save as PDF.`, 12000);
      return;
    }
    const blob = await blocksToPdf(reportBlocks('pdf'), jsPDF);
    await download(slug(M.title) + '-report.pdf', blob, 'application/pdf');
    toast('');
  } catch (e) {
    console.error(e);
    toast('The PDF report could not be built: ' + e.message, 10000);
  } finally { pdfBusy = false; }
}
// A small status message at the bottom of the page. ms = 0 keeps it until replaced; '' hides it.
function toast(msg, ms = 6000) {
  let el = document.getElementById('toast');
  if (!el) { el = document.createElement('div'); el.id = 'toast'; el.setAttribute('role', 'status'); document.body.appendChild(el); }
  clearTimeout(el._t);
  el.textContent = msg; el.hidden = !msg;
  if (msg && ms) el._t = setTimeout(() => { el.hidden = true; }, ms);
}

/* ============================================================
   Shared helpers: load a library from jsDelivr once
   ============================================================ */
const scriptPromises = new Map();
function loadScriptOnce(src, ready) {
  if (ready()) return Promise.resolve();
  if (!scriptPromises.has(src)) scriptPromises.set(src, new Promise((res, rej) => {
    const s = document.createElement('script');
    const timer = setTimeout(() => rej(new Error('timed out')), 20000);
    s.src = src; s.async = true;
    s.onload = () => { clearTimeout(timer); ready() ? res() : rej(new Error('the library did not initialise')); };
    s.onerror = () => { clearTimeout(timer); rej(new Error('blocked or offline')); };
    document.head.appendChild(s);
  }).catch(e => { scriptPromises.delete(src); throw e; }));
  return scriptPromises.get(src);
}

/* ============================================================
   Drilldown links between dashboards
   ============================================================ */
const NOT_DASHBOARDS = new Set(['search', 'report', 'reports', 'alert', 'alerts', 'datasets', 'dashboards', 'data_model_editor', 'job_manager', 'pivot', 'analytics_workspace']);
// "/app/<app>/<dashboard>?form.tok=$value$" → { app, dashboard, tokens }
function dashFromUrl(url) {
  const m = String(url || '').match(/\/app\/([^/?#\s"]+)\/([^/?#\s"]+)(\?[^#\s"]*)?/);
  if (!m || NOT_DASHBOARDS.has(m[2].toLowerCase())) return null;
  let tokens = [];
  try { tokens = [...new URLSearchParams(m[3] || '').entries()].map(([k, v]) => ({ token: k.replace(/^form\./, ''), value: v })); } catch { /* keep none */ }
  return { app: m[1], dashboard: m[2], tokens };
}
// Names a loaded dashboard could be linked by: its view name (REST entry or file name) and its title.
function dashKeys(d) {
  const stem = String(d.src.name || '').split(/[\\/]/).pop().replace(/\.(json|xml|txt)$/i, '').replace(/ #\d+$/, '');
  return uniq([stem, slug(stem), slug(d.model.title), d.model.title].filter(Boolean).map(s => s.toLowerCase()));
}
function resolveDash(target) {
  const t = String(target.dashboard || '').toLowerCase();
  if (!t) return -1;
  return DASH.findIndex(d => dashKeys(d).includes(t) || dashKeys(d).includes(slug(t)));
}
// Every "link to dashboard" drilldown in the loaded dashboards (or only in `onlyIndex`).
function dashLinks(onlyIndex) {
  const out = [];
  DASH.forEach((d, i) => {
    if (onlyIndex !== undefined && i !== onlyIndex) return;
    for (const v of d.model.byKind('viz')) for (const dd of v.drilldowns || []) {
      if (!dd.target) continue;
      out.push({ from: i, viz: v, target: dd.target, kind: dd.type, to: resolveDash(dd.target) });
    }
  });
  return out;
}
const targetLabel = t => `${t.app ? t.app + '/' : ''}${t.dashboard}`;
function linksTable(links, showFrom) {
  return table([
    ...(showFrom ? [{ h: 'From dashboard', f: l => `<button class="chip k-tab" data-dash="${l.from}">${esc(DASH[l.from].model.title)}</button>` }] : []),
    { h: 'Panel', f: l => l.from === CUR_I ? chip(l.viz.id) : esc(l.viz.label) },
    { h: 'Opens', f: l => l.to >= 0 ? `<button class="chip k-tab" data-dash="${l.to}">${esc(DASH[l.to].model.title)}</button> <span class="muted small">${esc(targetLabel(l.target))}</span>` : `<code>${esc(targetLabel(l.target))}</code> <span class="badge sev-info">not loaded</span>` },
    { h: 'Passes tokens', f: l => l.target.tokens.length ? l.target.tokens.map(t => `<code>${esc(t.token)}=${esc(t.value)}</code>`).join(' ') : '<span class="muted">—</span>' },
    { h: 'Received as', f: l => {
      if (l.to < 0 || !l.target.tokens.length) return '<span class="muted">—</span>';
      const m = DASH[l.to].model;
      return l.target.tokens.map(t => m.nodes.has('token:' + t.token) ? `<code>$${esc(t.token)}$</code> ✓` : `<code>$${esc(t.token)}$</code> <span class="badge sev-warning" title="The target dashboard never uses this token">unused there</span>`).join(' ');
    } },
  ], links);
}
// Columns by link depth; a dashboard links rightwards to the dashboards it opens.
function dashMapSvg(links) {
  const nodes = new Map(); // key → { key, label, sub, dash }
  DASH.forEach((d, i) => nodes.set('d' + i, { key: 'd' + i, label: d.model.title, sub: plural(d.model.byKind('viz').length, 'panel'), dash: i }));
  const edges = new Map();
  for (const l of links) {
    const to = l.to >= 0 ? 'd' + l.to : 'x:' + targetLabel(l.target).toLowerCase();
    if (!nodes.has(to)) nodes.set(to, { key: to, label: l.target.dashboard, sub: (l.target.app ? l.target.app + ' · ' : '') + 'not loaded', dash: -1 });
    const k = 'd' + l.from + '\u0001' + to;
    edges.set(k, { from: 'd' + l.from, to, n: (edges.get(k)?.n || 0) + 1 });
  }
  const E = [...edges.values()];
  const layer = new Map([...nodes.keys()].map(k => [k, 0]));
  for (let it = 0; it < nodes.size; it++) for (const e of E) if (e.from !== e.to && layer.get(e.to) < layer.get(e.from) + 1 && layer.get(e.from) + 1 < nodes.size) layer.set(e.to, layer.get(e.from) + 1);
  const cols = [];
  for (const [k, l] of layer) (cols[l] ||= []).push(k);
  const W = 210, H = 44, CW = 290, GAP = 16, PAD = 20;
  const maxRows = Math.max(1, ...cols.map(c => c?.length || 0));
  const P = new Map();
  cols.forEach((c, ci) => (c || []).forEach((k, ri) => P.set(k, { x: PAD + ci * CW, y: PAD + 56 + ri * (H + GAP) + ((maxRows - c.length) * (H + GAP)) / 2 })));
  const width = PAD * 2 + (cols.length - 1) * CW + W, height = PAD * 2 + 112 + maxRows * (H + GAP); // room for arcs above and below
  const trunc = (s, n) => (s = String(s)).length > n ? s.slice(0, n - 1) + '…' : s;
  let svg = `<svg class="graph" xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" role="img" aria-label="Map of drilldown links between dashboards"><defs><marker id="ar-dl" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path class="mk-data" d="M0,0 L10,5 L0,10 z"/></marker></defs>`;
  for (const e of E) {
    const a = P.get(e.from), b = P.get(e.to);
    let d;
    if (e.from === e.to) d = `M${a.x + W - 30},${a.y} C${a.x + W - 30},${a.y - 26} ${a.x + W + 20},${a.y - 26} ${a.x + W},${a.y + 10}`;
    // Forward links leave from the upper part of a box and back links from the lower part, so a pair of
    // dashboards that open each other shows two separate arrows. Links that skip a column arc over the boxes between.
    else if (b.x > a.x) {
      const x1 = a.x + W, y1 = a.y + H * 0.35, x2 = b.x - 2, y2 = b.y + H * 0.35, dx = (x2 - x1) / 2;
      d = b.x - a.x > CW + 1 ? `M${x1},${y1} C${x1 + 70},${y1 - H - 20} ${x2 - 70},${y2 - H - 20} ${x2},${y2}` : `M${x1},${y1} C${x1 + dx},${y1} ${x2 - dx},${y2} ${x2},${y2}`;
    } else {
      const x1 = a.x, y1 = a.y + H * 0.7, x2 = b.x + W + 2, y2 = b.y + H * 0.7, dx = Math.max(50, (x1 - x2) / 2);
      d = `M${x1},${y1} C${x1 - dx},${y1 + H} ${x2 + dx},${y2 + H} ${x2},${y2}`;
    }
    svg += `<path class="gedge data${b.x <= a.x && e.from !== e.to ? ' back' : ''}" d="${d}" marker-end="url(#ar-dl)"><title>${esc(nodes.get(e.from).label + ' opens ' + nodes.get(e.to).label + ' (' + plural(e.n, 'link') + ')')}</title></path>`;
    if (e.n > 1 && e.from !== e.to) svg += `<text class="colhead" x="${((a.x + W + b.x) / 2).toFixed(0)}" y="${((a.y + b.y) / 2 + H / 2 - 4).toFixed(0)}">×${e.n}</text>`;
  }
  for (const [k, nd] of nodes) {
    const p = P.get(k);
    svg += `<g class="gnode k-tab${nd.dash < 0 ? ' undef' : ''}" transform="translate(${p.x},${p.y})" ${nd.dash >= 0 ? `data-dash="${nd.dash}"` : ''} tabindex="0"><title>${esc(nd.label)}</title><rect class="box" width="${W}" height="${H}" rx="6"/><rect class="bar" width="4" height="${H}" rx="2"/><text x="12" y="17">${esc(trunc(nd.label, 30))}</text><text class="sub" x="12" y="32">${esc(trunc(nd.sub, 34))}</text></g>`;
  }
  return svg + '</svg>';
}
function viewDashLinksSection() {
  const links = dashLinks();
  const linked = new Set(links.flatMap(l => [l.from, l.to]).filter(i => i >= 0));
  return `<div class="section-title">Drilldowns between dashboards</div>
  <p class="muted small" style="margin:0 0 6px">Which dashboards open which, through "link to dashboard" drilldowns and links to <code>/app/&lt;app&gt;/&lt;dashboard&gt;</code>. Targets are matched to loaded dashboards by view name (the file or REST name) or title. Click a loaded dashboard to open it.</p>
  ${links.length ? `<div class="graph-wrap" style="max-height:420px;margin-bottom:10px">${dashMapSvg(links)}</div>${linksTable(links, true)}
    ${DASH.length - linked.size > 0 ? `<p class="muted small">${plural(DASH.length - linked.size, 'loaded dashboard')} neither link${DASH.length - linked.size === 1 ? 's' : ''} to nor ${DASH.length - linked.size === 1 ? 'is' : 'are'} linked from another: ${esc(DASH.filter((d, i) => !linked.has(i)).map(d => d.model.title).join(', '))}.</p>` : ''}`
    : '<p class="muted">No drilldown in the loaded dashboards opens another dashboard.</p>'}`;
}

/* ============================================================
   Shareable links
   ============================================================ */
const PAGES_URL = 'https://adamliq.github.io/splunkdashboard-breakdown/';
// Inside the claude.ai viewer or a local file the address can't be shared, so links point at the public site.
function shareBase() {
  if (SPLUNK?.page) return location.origin + SPLUNK.page;
  try { if (/^https?:$/.test(location.protocol) && window.top === window && !window.claude) return location.origin + location.pathname; } catch { /* cross-origin frame */ }
  return PAGES_URL;
}
const toB64url = bytes => { let s = ''; for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000)); return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); };
const fromB64url = s => { const b = atob(s.replace(/-/g, '+').replace(/_/g, '/')); const out = new Uint8Array(b.length); for (let i = 0; i < b.length; i++) out[i] = b.charCodeAt(i); return out; };
async function deflateText(str) {
  const stream = new Blob([str]).stream().pipeThrough(new CompressionStream('deflate-raw'));
  return toB64url(new Uint8Array(await new Response(stream).arrayBuffer()));
}
async function inflateText(b64) {
  const stream = new Blob([fromB64url(b64)]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
  return new Response(stream).text();
}
function shareSource() {
  const s = M.src;
  return s.classic && s.xmlText ? s.xmlText : JSON.stringify(stripInternal(structuredClone(s.def)));
}
async function buildShareLink(withConfig) {
  const payload = { v: 1, n: M.src.name || '', s: shareSource() };
  if (withConfig && hasConfig()) payload.c = { conf: CONFIG.conf, dm: CONFIG.dm };
  return shareBase() + '#d=' + await deflateText(JSON.stringify(payload));
}
async function openShareDialog() {
  const dlg = $('#share-dlg');
  if (typeof CompressionStream === 'undefined') { toast('This browser can\'t make share links (it has no CompressionStream). Use a current Chrome, Edge, Firefox or Safari.', 8000); return; }
  $('#share-config-row').hidden = !hasConfig();
  dlg.showModal();
  await refreshShareLink();
}
async function refreshShareLink() {
  const out = $('#share-link'), info = $('#share-info');
  out.value = 'Building the link…';
  try {
    const link = await buildShareLink($('#share-config').checked);
    out.value = link;
    const warn = link.length > 30000 ? ' This is a very long link: some chat and email apps cut long links off, so test it before relying on it.' : link.length > 8000 ? ' Some apps shorten or cut long links; if it doesn\'t open, send the file instead.' : '';
    info.textContent = `${link.length.toLocaleString()} characters.${warn}`;
  } catch (e) { out.value = ''; info.textContent = 'The link could not be built: ' + e.message; }
}
async function copyShareLink() {
  const out = $('#share-link');
  try { await navigator.clipboard.writeText(out.value); toast('Link copied.', 3000); }
  catch { out.focus(); out.select(); toast('Copying was blocked here. The link is selected: press Ctrl+C (or ⌘C) to copy it.', 6000); }
}
// Open a dashboard from a share link (#d=…) when the page loads or the fragment changes.
async function loadFromHash() {
  const m = location.hash.match(/[#&]d=([A-Za-z0-9_-]+)/);
  if (!m) return false;
  try {
    if (typeof DecompressionStream === 'undefined') throw new Error('this browser can\'t read share links; use a current Chrome, Edge, Firefox or Safari');
    let payload;
    try { payload = JSON.parse(await inflateText(m[1])); } catch { throw new Error('the link is damaged or incomplete'); }
    if (!payload || typeof payload.s !== 'string') throw new Error('the link holds no dashboard');
    if (payload.c) { $('#ldr-conf').value = payload.c.conf || ''; $('#ldr-dm').value = payload.c.dm || ''; }
    applyConfig(payload.c?.conf || '', payload.c?.dm || '');
    $('#source').value = payload.s;
    loadDashboards([{ name: payload.n || 'shared link', text: payload.s }]);
    if (!$('#app').hidden) toast('Opened from a shared link.', 4000);
    return true;
  } catch (e) {
    const err = $('#load-error');
    err.textContent = 'This shared link could not be opened: ' + e.message + '. It may have been cut short when it was copied; ask for the link again, or for the dashboard file.';
    err.hidden = false;
    return false;
  }
}

/* ============================================================
   Excel workbook: a small built-in .xlsx writer (no library needed)
   ============================================================ */
const CRC_TABLE = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
function crc32(bytes) { let c = 0xFFFFFFFF; for (let i = 0; i < bytes.length; i++) c = CRC_TABLE[(c ^ bytes[i]) & 0xFF] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; }
async function deflateRawBytes(bytes) {
  if (typeof CompressionStream === 'undefined') return null;
  try { return new Uint8Array(await new Response(new Blob([bytes]).stream().pipeThrough(new CompressionStream('deflate-raw'))).arrayBuffer()); } catch { return null; }
}
// files: [{ name, text }] → ZIP bytes (deflated where the browser can, otherwise stored).
async function zipFiles(files) {
  const enc = new TextEncoder(), parts = [], central = [];
  const now = new Date();
  const time = (now.getHours() << 11) | (now.getMinutes() << 5) | (now.getSeconds() >> 1);
  const date = ((now.getFullYear() - 1980) << 9) | ((now.getMonth() + 1) << 5) | now.getDate();
  let offset = 0;
  for (const f of files) {
    const name = enc.encode(f.name), data = enc.encode(f.text), crc = crc32(data);
    const comp = await deflateRawBytes(data);
    const method = comp && comp.length < data.length ? 8 : 0, body = method ? comp : data;
    const lh = new DataView(new ArrayBuffer(30));
    lh.setUint32(0, 0x04034b50, true); lh.setUint16(4, 20, true); lh.setUint16(6, 0x0800, true); lh.setUint16(8, method, true);
    lh.setUint16(10, time, true); lh.setUint16(12, date, true); lh.setUint32(14, crc, true); lh.setUint32(18, body.length, true);
    lh.setUint32(22, data.length, true); lh.setUint16(26, name.length, true); lh.setUint16(28, 0, true);
    parts.push(new Uint8Array(lh.buffer), name, body);
    const ch = new DataView(new ArrayBuffer(46));
    ch.setUint32(0, 0x02014b50, true); ch.setUint16(4, 20, true); ch.setUint16(6, 20, true); ch.setUint16(8, 0x0800, true); ch.setUint16(10, method, true);
    ch.setUint16(12, time, true); ch.setUint16(14, date, true); ch.setUint32(16, crc, true); ch.setUint32(20, body.length, true); ch.setUint32(24, data.length, true);
    ch.setUint16(28, name.length, true); ch.setUint32(42, offset, true);
    central.push(new Uint8Array(ch.buffer), name);
    offset += 30 + name.length + body.length;
  }
  const cdSize = central.reduce((s, x) => s + x.length, 0);
  const end = new DataView(new ArrayBuffer(22));
  end.setUint32(0, 0x06054b50, true); end.setUint16(8, files.length, true); end.setUint16(10, files.length, true);
  end.setUint32(12, cdSize, true); end.setUint32(16, offset, true);
  return [...parts, ...central, new Uint8Array(end.buffer)];
}
// XML text: escape, and drop characters XML can't hold.
const xmlEsc = s => String(s ?? '').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F￾￿]/g, '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const xlsxCol = i => { let s = ''; i++; while (i) { const m = (i - 1) % 26; s = String.fromCharCode(65 + m) + s; i = Math.floor((i - 1) / 26); } return s; };
const XML_HEAD = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n';
function sheetXml(sh) {
  const rows = [sh.head, ...sh.rows];
  const widths = sh.head.map((h, i) => Math.min(60, Math.max(String(h).length + 2, ...rows.slice(1, 200).map(r => String(r[i] ?? '').split('\n')[0].length + 1))));
  const lastCol = xlsxCol(Math.max(0, sh.head.length - 1)), lastRow = rows.length;
  const cell = (v, r, c, hdr) => {
    if (v === '' || v === null || v === undefined) return '';
    const ref = xlsxCol(c) + r, st = hdr ? ' s="1"' : '';
    return typeof v === 'number' && isFinite(v) ? `<c r="${ref}"${st}><v>${v}</v></c>` : `<c r="${ref}" t="inlineStr"${st}><is><t xml:space="preserve">${xmlEsc(v)}</t></is></c>`;
  };
  return XML_HEAD + '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
    + `<dimension ref="A1:${lastCol}${lastRow}"/><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>`
    + `<sheetFormatPr defaultRowHeight="15"/><cols>${widths.map((w, i) => `<col min="${i + 1}" max="${i + 1}" width="${w}" customWidth="1"/>`).join('')}</cols>`
    + `<sheetData>${rows.map((r, ri) => `<row r="${ri + 1}">${r.map((v, ci) => cell(v, ri + 1, ci, ri === 0)).join('')}</row>`).join('')}</sheetData>`
    + (sh.rows.length ? `<autoFilter ref="A1:${lastCol}${lastRow}"/>` : '') + '</worksheet>';
}
async function writeXlsx(sheets, title) {
  const n = sheets.length;
  const filters = sheets.map((s, i) => s.rows.length ? `<definedName name="_xlnm._FilterDatabase" localSheetId="${i}" hidden="1">'${xmlEsc(s.name.replace(/'/g, "''"))}'!$A$1:$${xlsxCol(s.head.length - 1)}$${s.rows.length + 1}</definedName>` : '').join('');
  const files = [
    { name: '[Content_Types].xml', text: XML_HEAD + '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
      + sheets.map((_, i) => `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join('')
      + '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/></Types>' },
    { name: '_rels/.rels', text: XML_HEAD + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/></Relationships>' },
    { name: 'docProps/core.xml', text: XML_HEAD + `<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>${xmlEsc(title)}</dc:title><dc:creator>Studio Dashboard Inventory</dc:creator><dcterms:created xsi:type="dcterms:W3CDTF">${new Date().toISOString().replace(/\.\d+Z$/, 'Z')}</dcterms:created></cp:coreProperties>` },
    { name: 'xl/workbook.xml', text: XML_HEAD + '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>'
      + sheets.map((s, i) => `<sheet name="${xmlEsc(s.name)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join('') + '</sheets>' + (filters ? `<definedNames>${filters}</definedNames>` : '') + '</workbook>' },
    { name: 'xl/_rels/workbook.xml.rels', text: XML_HEAD + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
      + sheets.map((_, i) => `<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`).join('')
      + `<Relationship Id="rId${n + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>` },
    { name: 'xl/styles.xml', text: XML_HEAD + '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts><fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>' },
    ...sheets.map((s, i) => ({ name: `xl/worksheets/sheet${i + 1}.xml`, text: sheetXml(s) })),
  ];
  return new Blob(await zipFiles(files), { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
}
// A sheet with a safe, unique name; numeric-looking cells become numbers, "#12" in a "#" column becomes 12.
function makeSheet(name, head, rows, used) {
  let base = String(name).replace(/[\[\]:*?/\\]/g, ' ').replace(/^\d+\.\s*/, '').trim().slice(0, 28) || 'Sheet';
  let nm = base, k = 2;
  while (used.has(nm.toLowerCase())) nm = `${base.slice(0, 26)} ${k++}`;
  used.add(nm.toLowerCase());
  const clip = v => { const s = String(v ?? ''); return s.length > 32000 ? s.slice(0, 31990) + ' …(cut)' : s; };
  return {
    name: nm, head: head.map(String),
    rows: rows.map(r => r.map((c, i) => {
      const s = clip(c);
      if (head[i] === '#' && /^#\d+$/.test(s)) return +s.slice(1);
      if (/^-?\d+(\.\d+)?$/.test(s) && s.length < 15 && !/^0\d/.test(s)) return +s;
      return s;
    })),
  };
}
function sheetsForDashboard() {
  const out = [], used = new Set();
  let h2 = 'About', h3 = '';
  for (const b of reportBlocks('xlsx')) {
    if (b.t === 'h2') { h2 = b.text.replace(/^\d+\.\s*/, ''); h3 = ''; }
    else if (b.t === 'h3') h3 = b.text.replace(/\s*\(.*$/, '');
    else if (b.t === 'table' && b.rows.length) out.push(makeSheet(h3 && h2 !== 'Layout' ? h3 : h2 === 'Layout' && h3 ? 'Layout ' + h3 : h2, b.head, b.rows, used));
  }
  out.push(makeSheet('SPL', ['#', 'Data source', 'ID', 'Type', 'Query', 'Effective SPL (base and chain)', 'Expanded SPL'],
    M.byKind('ds').map(n => ['#' + invNo(n.id), n.label, n.key, dsTypeLabel(n.type), n.type === 'ds.savedSearch' ? `| savedsearch "${n.ref}"` : n.query, n.depth > 0 ? n.effectiveQuery : '', n.expandedQuery || '']), used));
  return out;
}
function sheetsForApp() {
  const out = [], used = new Set();
  const sev = (m, s) => m.issues.filter(i => i.severity === s).length;
  out.push(makeSheet('Dashboards', ['Dashboard', 'Source', 'Format', 'Tabs', 'Panels', 'Searches', 'Inputs', 'Tokens', 'Errors', 'Warnings', 'Recommendations'],
    DASH.map(d => { const m = d.model, prev = M; M = m; const recs = recommendations().length; M = prev; return [m.title, d.src.name || '', m.format, m.byKind('tab').filter(t => !t.global).length, m.byKind('viz').length, m.byKind('ds').length, m.byKind('input').length, m.byKind('token').length, sev(m, 'error'), sev(m, 'warning'), recs]; }), used));
  const shared = sharedItems();
  out.push(makeSheet('Shared items', ['Kind', 'Name', 'Dashboards', 'Used by'], shared.map(r => [r.kind, r.name, r.uses.size, [...r.uses].map(([i, d]) => DASH[i].model.title + (d.size ? ` (${[...d].join(', ')})` : '')).join('; ')]), used));
  out.push(makeSheet('Shared by dashboard', ['Dashboard', 'Kind', 'Name', 'Detail'], shared.flatMap(r => [...r.uses].map(([i, d]) => [DASH[i].model.title, r.kind, r.name, [...d].join('; ')])), used));
  out.push(makeSheet('Dashboard links', ['From dashboard', 'Panel', 'Opens', 'Loaded', 'Passes tokens'], dashLinks().map(l => [DASH[l.from].model.title, l.viz.label, targetLabel(l.target), l.to >= 0 ? DASH[l.to].model.title : 'not loaded', l.target.tokens.map(t => `${t.token}=${t.value}`).join(', ')]), used));
  return out;
}
let xlsxBusy = false;
async function exportXlsx(app = false) {
  if (xlsxBusy) return;
  xlsxBusy = true;
  toast('Building the Excel workbook…', 0);
  try {
    const blob = await writeXlsx(app ? sheetsForApp() : sheetsForDashboard(), app ? 'App inventory' : M.title + ' - dashboard inventory');
    await download((app ? 'app' : slug(M.title)) + '-inventory.xlsx', blob, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    toast('');
  } catch (e) { console.error(e); toast('The workbook could not be built: ' + e.message, 10000); }
  finally { xlsxBusy = false; }
}

/* ============================================================
   Loading and wiring
   ============================================================ */
let DASH = [];        // every loaded dashboard: [{ src, model }]
let CUR_I = 0;        // the one shown
let LOAD_ERRORS = []; // sources that failed while others loaded
// files: [{ name, text }]. Each may hold one dashboard or many (REST list, JSON array).
function loadDashboards(files) {
  const err = $('#load-error');
  err.hidden = true;
  const ok = [], errors = [];
  for (const f of files) {
    try {
      for (const s of parseSources(f.text, f.name)) {
        if (s.error) errors.push(`${s.name || f.name || 'dashboard'}: ${s.error}`);
        else ok.push(s);
      }
    } catch (e) { errors.push((files.length > 1 ? (f.name || 'pasted text') + ': ' : '') + e.message); }
  }
  const built = [];
  for (const s of ok) {
    try { built.push({ src: s, model: buildModel(s) }); }
    catch (e) { errors.push(`${s.name || s.def?.title || 'dashboard'}: could not be analysed (${e.message}).`); console.error(e); }
  }
  if (!built.length) { err.textContent = errors.join('\n') || 'No dashboard was found.'; err.hidden = false; return; }
  DASH = built; LOAD_ERRORS = errors;
  $('#loader').hidden = true; $('#app').hidden = false; $('#btn-new').hidden = false;
  COMPARE = null;
  selectDash(0, built.length > 1 ? 'app' : 'overview');
  window.scrollTo(0, 0);
}
function selectDash(i, v = 'overview') {
  CUR_I = i; M = DASH[i].model;
  FIX_SEL = new Set();
  mockState.tab = null; mockState.values = null;
  graphState.focus = ''; graphState.selected = null; graphState.center = null; graphState.pathFrom = null; graphState.pathTo = null; graphState.toggled.clear(); graphState.overlay = false;
  invState.kind = '';
  if (COMPARE && v !== 'compare') COMPARE = null;
  view = v;
  $('#filter').value = '';
  closeDrawer();
  const sw = $('#dash-switch');
  sw.hidden = DASH.length < 2;
  sw.innerHTML = DASH.map((d, k) => `<option value="${k}" ${k === i ? 'selected' : ''}>${esc(d.model.title)}</option>`).join('');
  $('#dash-title').textContent = DASH.length > 1 ? '' : M.title;
  document.title = M.title + ' · Studio Dashboard Inventory';
  render();
}
async function filesToList(fileList) { return Promise.all([...fileList].map(async f => ({ name: f.name, text: await f.text() }))); }
function analyzeLoader() {
  applyConfig($('#ldr-conf').value, $('#ldr-dm').value);
  loadDashboards([{ name: '', text: $('#source').value }]);
}

$('#btn-analyze').onclick = analyzeLoader;
$('#btn-sample').onclick = () => { $('#source').value = $('#sample').textContent.trim(); analyzeLoader(); };
$('#file').onchange = async e => {
  const list = await filesToList(e.target.files);
  e.target.value = '';
  if (!list.length) return;
  if (list.length === 1) $('#source').value = list[0].text;
  applyConfig($('#ldr-conf').value, $('#ldr-dm').value);
  loadDashboards(list);
};
$('#ldr-cfg-file').onchange = async e => {
  for (const f of e.target.files) {
    const t = await f.text();
    const box = /\.json$/i.test(f.name) || /^\s*[{[]/.test(t) ? $('#ldr-dm') : $('#ldr-conf');
    box.value = (box.value ? box.value + '\n' : '') + t;
  }
  e.target.value = '';
  $('#ldr-config').open = true;
};
$('#ldr-cfg-sample').onclick = () => { $('#ldr-conf').value = $('#sample-conf').textContent.trim(); $('#ldr-dm').value = $('#sample-dm').textContent.trim(); };
const srcBox = $('#source');
srcBox.addEventListener('dragover', e => { e.preventDefault(); srcBox.classList.add('dragover'); });
srcBox.addEventListener('dragleave', () => srcBox.classList.remove('dragover'));
srcBox.addEventListener('drop', async e => {
  e.preventDefault(); srcBox.classList.remove('dragover');
  const list = await filesToList(e.dataTransfer.files);
  if (!list.length) return;
  if (list.length === 1) srcBox.value = list[0].text;
  applyConfig($('#ldr-conf').value, $('#ldr-dm').value);
  loadDashboards(list);
});
$('#btn-new').onclick = () => {
  closeDrawer();
  $('#app').hidden = true; $('#loader').hidden = false; $('#btn-new').hidden = true; $('#dash-switch').hidden = true;
  $('#dash-title').textContent = ''; document.title = 'Studio Dashboard Inventory';
  $('#ldr-conf').value = CONFIG.conf; $('#ldr-dm').value = CONFIG.dm;
};
$('#dash-switch').onchange = e => selectDash(+e.target.value, view === 'app' ? 'overview' : view);
$('#filter').addEventListener('input', applyFilter);

// Export menu
const exportMenu = $('#export-menu');
$('#btn-export').onclick = e => { e.stopPropagation(); exportMenu.hidden = !exportMenu.hidden; $('#btn-export').setAttribute('aria-expanded', String(!exportMenu.hidden)); };
exportMenu.addEventListener('click', () => { exportMenu.hidden = true; $('#btn-export').setAttribute('aria-expanded', 'false'); });
$('#btn-export-summary').onclick = exportSummary;
$('#btn-export-md').onclick = exportReportMd;
$('#btn-export-pdf').onclick = exportReportPdf;
$('#btn-export-inv').onclick = exportInventory;
$('#btn-export-rel').onclick = exportRelationships;
$('#btn-export-json').onclick = exportJson;
$('#btn-export-def').onclick = downloadDefinition;
$('#btn-export-svg').onclick = () => { if (!mockState.tab) mockState.tab = mockTabs()[0]?.id; download(mockFileName('svg'), mockupSvg(), 'image/svg+xml'); };
$('#btn-export-png').onclick = () => { if (!mockState.tab) mockState.tab = mockTabs()[0]?.id; exportMockupPng(); };
$('#btn-export-xlsx').onclick = () => exportXlsx(false);
$('#btn-share').onclick = openShareDialog;
$('#share-config').onchange = refreshShareLink;
$('#share-copy').onclick = copyShareLink;
$('#share-close').onclick = () => $('#share-dlg').close();
window.addEventListener('hashchange', loadFromHash);
initSplunkLoader();
loadFromHash();
function updateSplunkButton() {
  const b = $('#sp-load'), n = splunkState.selected.size;
  if (b) { b.disabled = !n; b.textContent = n ? `Load ${plural(n, 'dashboard')}` : 'Choose dashboards to load'; }
}
document.addEventListener('input', e => {
  if (e.target.id !== 'sp-filter') return;
  const q = e.target.value.trim().toLowerCase();
  document.querySelectorAll('#splunk-loader .sp-item').forEach(el => { el.hidden = !!q && !el.textContent.toLowerCase().includes(q); });
});

$('#drawer-close').onclick = closeDrawer;
$('#drawer-back').onclick = () => { if (drawerHistory.length > 1) { drawerHistory.pop(); openDrawer(drawerHistory[drawerHistory.length - 1], false); } };
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') { closeDrawer(); exportMenu.hidden = true; }
  if (e.key === 'Enter' && e.target.matches?.('input[data-mock-token]')) onMockChange(e.target);
});
document.addEventListener('change', async e => {
  const t = e.target;
  if (t.id === 'mock-sub') { mockState.substitute = t.checked; render(); return; }
  if (t.id === 'mock-hidden') { mockState.showHidden = t.checked; render(); return; }
  if (t.id === 'mock-names') { mockState.showNames = t.checked; render(); return; }
  if (t.dataset?.fix !== undefined) { const k = +t.dataset.fix; if (t.checked) FIX_SEL.add(k); else FIX_SEL.delete(k); render(); return; }
  if (t.id === 'mat-sort') { matState.sort = t.value; render(); return; }
  if (t.id === 'sp-app') { splunkState.app = t.value; loadSplunkViews(); return; }
  if (t.dataset?.spview) { if (t.checked) splunkState.selected.add(t.dataset.spview); else splunkState.selected.delete(t.dataset.spview); updateSplunkButton(); return; }
  if (t.id === 'compat-version') { compatState.version = t.value; saveCompat(); render(); return; }
  if (t.dataset?.compatMin) { const f = COMPAT_FEATURES.find(x => x.key === t.dataset.compatMin); if (t.value === f.min) delete compatState.overrides[f.key]; else compatState.overrides[f.key] = t.value; saveCompat(); render(); return; }
  if (t.id === 'flow-measure') { flowState.measure = t.value; render(); return; }
  if (t.id === 'flow-chains') { flowState.chains = t.checked; render(); return; }
  if (t.id === 'cmp-pick' && t.value !== '') { COMPARE = { model: DASH[+t.value].model, label: DASH[+t.value].model.title }; render(); return; }
  if (t.id === 'cmp-file' && t.files[0]) { const f = t.files[0]; startCompare(await f.text(), f.name); return; }
  if (t.id === 'cfg-file' && t.files.length) { const c = await readConfigFiles(t.files); setConfig(c.conf, c.dm); return; }
  if (t.closest?.('[data-mock-token]')) onMockChange(t);
});
document.addEventListener('click', e => {
  if (!e.target.closest('.menu')) { exportMenu.hidden = true; $('#btn-export').setAttribute('aria-expanded', 'false'); }
  const id = e.target.closest('[id]')?.id;
  const actions = {
    'mock-reset': () => { resetMockValues(); render(); },
    'mock-svg': () => download(mockFileName('svg'), mockupSvg(), 'image/svg+xml'),
    'mock-png': exportMockupPng,
    'sp-load': loadFromSplunk,
    'sp-all': () => { document.querySelectorAll('#splunk-loader .sp-item:not([hidden]) input[data-spview]').forEach(c => { c.checked = true; splunkState.selected.add(c.dataset.spview); }); updateSplunkButton(); },
    'sp-none': () => { splunkState.selected.clear(); document.querySelectorAll('#splunk-loader input[data-spview]').forEach(c => { c.checked = false; }); updateSplunkButton(); },
    'compat-reset': () => { compatState.overrides = {}; saveCompat(); render(); },
    'fix-all': () => { M.issues.forEach((x, k) => { if (x.fix) FIX_SEL.add(k); }); render(); },
    'fix-none': () => { FIX_SEL.clear(); render(); },
    'fix-download': downloadDefinition,
    'fix-load': loadFixed,
    'app-csv': exportAppCsv,
    'app-xlsx': () => exportXlsx(true),
    'mat-svg': () => download(slug(M.title) + '-token-matrix.svg', matrixSvg(), 'image/svg+xml'),
    'mat-png': () => downloadPng(matrixSvg(), slug(M.title) + '-token-matrix.png'),
    'flow-svg': () => download(slug(M.title) + '-data-flow.svg', sankeySvg(false), 'image/svg+xml'),
    'flow-png': () => downloadPng(sankeySvg(false), slug(M.title) + '-data-flow.png'),
    'cmp-map': () => { graphState.overlay = true; graphState.mode = 'all'; view = 'graph'; render(); window.scrollTo(0, 0); },
    'inv-csv': exportInventory,
    'cmp-run': () => startCompare($('#cmp-source').value, 'version B'),
    'cmp-clear': () => { COMPARE = null; render(); },
    'cmp-md': exportDiffMd,
    'cfg-apply': () => setConfig($('#cfg-conf').value, $('#cfg-dm').value),
    'cfg-sample': () => setConfig($('#sample-conf').textContent.trim(), $('#sample-dm').textContent.trim()),
    'cfg-clear': () => setConfig('', ''),
  };
  if (actions[id] && e.target.closest('button')) { actions[id](); return; }
  const v = e.target.closest('[data-view]');
  if (v) { view = v.dataset.view; render(); window.scrollTo(0, 0); return; }
  const mr = e.target.closest('[data-matrows]');
  if (mr) { matState.rows = mr.dataset.matrows; render(); return; }
  const mc = e.target.closest('[data-matcols]');
  if (mc) { matState.cols = mc.dataset.matcols; render(); return; }
  const ik = e.target.closest('[data-invkind]');
  if (ik) { invState.kind = ik.dataset.invkind; render(); return; }
  const dsh = e.target.closest('[data-dash]');
  if (dsh) { selectDash(+dsh.dataset.dash, 'overview'); window.scrollTo(0, 0); return; }
  const mt = e.target.closest('[data-mocktab]');
  if (mt) { mockState.tab = mt.dataset.mocktab; render(); return; }
  const op = e.target.closest('[data-open]');
  if (op) { openDrawer(op.dataset.open); return; }
  const c = e.target.closest('.chip[data-id], .mock-item[data-id]');
  if (c) { openDrawer(c.dataset.id); return; }
  const th = e.target.closest('#view th');
  if (th) sortTable(th);
});
